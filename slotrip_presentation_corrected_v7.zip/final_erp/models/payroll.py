from dataclasses import dataclass, field


@dataclass
class PayrollEntry:
    entry_id: int | None = None
    run_id: int | None = None
    employee_id: int | None = None
    employee_name: str = ""
    location_id: int | None = None
    location_name: str = ""
    hours_worked: float = 0.0
    hourly_rate: float = 0.0
    gross_pay: float = 0.0


@dataclass
class PayrollRun:
    run_id: int | None = None
    period_start: str = ""
    period_end: str = ""
    run_date: str = ""
    total_amount: float = 0.0
    status: str = "Draft"
    created_by: int | None = None
    created_by_name: str = ""
    entries: list[PayrollEntry] = field(default_factory=list)
