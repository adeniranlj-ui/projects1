from dataclasses import dataclass


@dataclass
class Customer:
    customer_id: int | None = None
    customer_name: str = ""
    reward_points: int = 0
    is_discount_eligible: int = 0
    active: int = 1


@dataclass
class CustomerSalesSummary:
    customer_id: int | None = None
    customer_name: str = ""
    sales_count: int = 0
    total_sales: float = 0.0
    most_recent_sale_date: str | None = None
