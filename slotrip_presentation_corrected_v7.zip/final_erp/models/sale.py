from dataclasses import dataclass, field


@dataclass
class SaleLineItem:
    sale_line_item_id: int | None = None
    sale_id: int | None = None
    product_id: int | None = None
    product_name: str = ""
    quantity: int = 0
    unit_price: float = 0.0
    line_total: float = 0.0


@dataclass
class Sale:
    sale_id: int | None = None
    sale_date: str = ""
    location_id: int | None = None
    location_name: str = ""
    customer_id: int | None = None
    customer_name: str = "Walk-In"
    employee_id: int | None = None
    employee_name: str = ""
    subtotal: float = 0.0
    discount_amount: float = 0.0
    grand_total: float = 0.0
    line_items: list[SaleLineItem] = field(default_factory=list)
