from dataclasses import dataclass


@dataclass
class LedgerEntry:
    ledger_entry_id: int | None = None
    entry_date: str = ""
    entry_type: str = "Income"
    source_type: str = "manual"
    source_record_id: int | None = None
    amount: float = 0.0
    description: str = ""
    related_sale_id: int | None = None
    related_po_id: int | None = None
    running_balance: float = 0.0
