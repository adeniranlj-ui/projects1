from dataclasses import dataclass


@dataclass
class Inventory:
    inventory_id: int | None = None
    product_id: int | None = None
    product_name: str = ""
    location_id: int | None = None
    location_name: str = ""
    quantity: int = 0
    reorder_point: int = 0
