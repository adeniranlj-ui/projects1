from dataclasses import dataclass


@dataclass
class Location:
    location_id: int | None = None
    location_name: str = ""
