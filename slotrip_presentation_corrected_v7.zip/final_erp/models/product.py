from dataclasses import dataclass


@dataclass
class Product:
    product_id: int | None = None
    product_name: str = ""
    sku: str = ""
    category: str = ""
    unit_cost: float = 0.0
    unit_price: float = 0.0
    reorder_point: int = 0
    default_supplier_id: int | None = None
    supplier_name: str = ""
    active: int = 1
