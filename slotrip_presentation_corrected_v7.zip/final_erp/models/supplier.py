from dataclasses import dataclass


@dataclass
class Supplier:
    supplier_id: int | None = None
    supplier_name: str = ""
    category: str = ""
    active: int = 1
    ban_reason: str | None = None
    banned_at: str | None = None
    reactivated_at: str | None = None
