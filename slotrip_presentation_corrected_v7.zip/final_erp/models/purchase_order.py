from dataclasses import dataclass, field


@dataclass
class POLineItem:
    po_line_item_id: int | None = None
    po_id: int | None = None
    product_id: int | None = None
    product_name: str = ""
    quantity: int = 0
    unit_cost: float = 0.0
    line_total: float = 0.0


@dataclass
class PurchaseOrder:
    po_id: int | None = None
    supplier_id: int | None = None
    supplier_name: str = ""
    location_id: int | None = None
    location_name: str = ""
    status: str = "Drafted"
    created_date: str = ""
    sent_date: str | None = None
    received_date: str | None = None
    po_total: float = 0.0
    line_items: list[POLineItem] = field(default_factory=list)
