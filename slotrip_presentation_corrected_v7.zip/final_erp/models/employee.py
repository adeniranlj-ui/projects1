from dataclasses import dataclass


@dataclass
class Employee:
    employee_id: int | None = None
    employee_name: str = ""
    username: str = ""
    password_hash: str = ""
    role: str = "Staff"
    location_id: int | None = None
    location_name: str = ""
    hourly_wage: float = 15.0
    active: int = 1
