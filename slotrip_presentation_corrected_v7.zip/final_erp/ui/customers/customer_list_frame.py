from tkinter import messagebox, ttk

from services import customer_service
from ui.customers.customer_form_frame import CustomerFormFrame


class CustomerListFrame(ttk.Frame):
    def __init__(self, parent, navigate):
        super().__init__(parent)
        self.customers = []
        self.summary_rows = []
        ttk.Label(self, text="Customers", font=("Arial", 16, "bold")).pack(anchor="w")
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        left = ttk.Frame(body)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))

        ttk.Label(left, text="Customer List", font=("Arial", 11, "bold")).pack(anchor="w")
        self.tree = ttk.Treeview(left, columns=("name", "active"), show="headings", height=9)
        self.tree.heading("name", text="Name", anchor="w")
        self.tree.heading("active", text="Active", anchor="w")
        self.tree.column("name", anchor="w")
        self.tree.column("active", anchor="w")
        self.tree.pack(fill="both", expand=True, pady=(0, 8))

        summary_header = ttk.Frame(left)
        summary_header.pack(fill="x")
        ttk.Label(summary_header, text="Repeat Customer Sales Totals", font=("Arial", 11, "bold")).pack(side="left")
        ttk.Button(summary_header, text="Refresh Totals", command=self.load_customers).pack(side="right")
        self.summary_tree = ttk.Treeview(
            left,
            columns=("name", "sales", "total", "recent"),
            show="headings",
            height=8,
        )
        for col, text in [("name", "Customer"), ("sales", "Sales"), ("total", "Total Sales"), ("recent", "Most Recent Sale")]:
            self.summary_tree.heading(col, text=text, anchor="w")
            self.summary_tree.column(col, anchor="w")
        self.summary_tree.pack(fill="both", expand=True)

        self.form = CustomerFormFrame(body, self.load_customers)
        self.form.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.load_customers()

    def load_customers(self) -> None:
        try:
            self.customers = customer_service.get_all_customers()
            for row in self.tree.get_children():
                self.tree.delete(row)
            for customer in self.customers:
                self.tree.insert("", "end", iid=str(customer.customer_id), values=(customer.customer_name, customer.active))

            self.summary_rows = customer_service.get_customer_sales_summary(repeat_only=True)
            for row in self.summary_tree.get_children():
                self.summary_tree.delete(row)
            for item in self.summary_rows:
                self.summary_tree.insert(
                    "",
                    "end",
                    values=(item.customer_name, item.sales_count, f"${item.total_sales:.2f}", item.most_recent_sale_date or "None"),
                )
        except Exception:
            messagebox.showerror("Customer Error", "Customers could not be loaded. Please try again.")

    def on_select(self, event=None) -> None:
        selection = self.tree.selection()
        if selection:
            customer_id = int(selection[0])
            for customer in self.customers:
                if customer.customer_id == customer_id:
                    self.form.populate_form(customer)
