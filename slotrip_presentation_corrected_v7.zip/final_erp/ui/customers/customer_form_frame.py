import tkinter as tk
from tkinter import messagebox, ttk

from services import customer_service


class CustomerFormFrame(ttk.LabelFrame):
    def __init__(self, parent, on_saved):
        super().__init__(parent, text="Customer Form", padding=8)
        self.on_saved = on_saved
        self.customer_id = None
        self.name_var = tk.StringVar()
        self.active_var = tk.IntVar(value=1)
        self.reward_points_var = tk.StringVar(value="0")
        self.discount_eligible_var = tk.IntVar(value=0)
        ttk.Label(self, text="Name").grid(row=0, column=0, sticky="w")
        ttk.Entry(self, textvariable=self.name_var).grid(row=0, column=1, sticky="ew")
        ttk.Label(self, text="Reward Points").grid(row=1, column=0, sticky="w")
        ttk.Entry(self, textvariable=self.reward_points_var, width=8).grid(row=1, column=1, sticky="w")
        ttk.Checkbutton(self, text="Discount Eligible (10%)", variable=self.discount_eligible_var).grid(row=2, column=1, sticky="w")
        ttk.Checkbutton(self, text="Active", variable=self.active_var).grid(row=3, column=1, sticky="w")
        ttk.Button(self, text="New", command=self.clear_form).grid(row=4, column=0, pady=8)
        ttk.Button(self, text="Save", command=self.save).grid(row=4, column=1, pady=8)
        ttk.Button(self, text="Deactivate", command=self.deactivate).grid(row=5, column=0, columnspan=2, sticky="ew")
        self.columnconfigure(1, weight=1)

    def populate_form(self, customer) -> None:
        self.customer_id = customer.customer_id
        self.name_var.set(customer.customer_name)
        self.reward_points_var.set(str(getattr(customer, "reward_points", 0)))
        self.discount_eligible_var.set(getattr(customer, "is_discount_eligible", 0))
        self.active_var.set(customer.active)

    def clear_form(self) -> None:
        self.customer_id = None
        self.name_var.set("")
        self.reward_points_var.set("0")
        self.discount_eligible_var.set(0)
        self.active_var.set(1)

    def save(self) -> None:
        try:
            data = {
                "customer_name": self.name_var.get(),
                "active": self.active_var.get(),
                "reward_points": self.reward_points_var.get(),
                "is_discount_eligible": self.discount_eligible_var.get(),
            }
            if self.customer_id:
                customer_service.update_customer(self.customer_id, data)
            else:
                customer_service.create_customer(data)
            self.clear_form()
            self.on_saved()
            messagebox.showinfo("Customer Saved", "Customer saved successfully.")
        except ValueError as error:
            messagebox.showerror("Customer Error", str(error))
        except Exception:
            messagebox.showerror("Customer Error", "The customer could not be saved. Please check the information and try again.")

    def deactivate(self) -> None:
        try:
            if not self.customer_id:
                messagebox.showinfo("Customer", "Select a customer first.")
                return
            customer_service.deactivate_customer(self.customer_id)
            self.clear_form()
            self.on_saved()
            messagebox.showinfo("Customer Deactivated", "Customer deactivated successfully.")
        except ValueError as error:
            messagebox.showerror("Customer Error", str(error))
        except Exception:
            messagebox.showerror("Customer Error", "The customer could not be deactivated. Please try again.")
