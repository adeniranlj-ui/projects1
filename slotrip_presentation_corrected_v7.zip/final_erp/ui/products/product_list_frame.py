from tkinter import messagebox, ttk

from services import product_service
from ui.products.product_form_frame import ProductFormFrame


class ProductListFrame(ttk.Frame):
    def __init__(self, parent, navigate):
        super().__init__(parent)
        self.products = []
        self._build_layout()
        self.load_products()

    def _build_layout(self) -> None:
        ttk.Label(self, text="Products", font=("Arial", 16, "bold")).pack(anchor="w")
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(body, columns=("sku", "name", "category", "price", "active"), show="headings")
        for col, text in [("sku", "SKU"), ("name", "Name"), ("category", "Category"), ("price", "Price"), ("active", "Active")]:
            self.tree.heading(col, text=text, anchor="w")
            self.tree.column(col, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True, padx=(0, 8))
        self.form = ProductFormFrame(body, self.load_products)
        self.form.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

    def load_products(self) -> None:
        try:
            self.products = product_service.get_all_products()
            for row in self.tree.get_children():
                self.tree.delete(row)
            for product in self.products:
                self.tree.insert("", "end", iid=str(product.product_id), values=(product.sku, product.product_name, product.category, f"${product.unit_price:.2f}", product.active))
        except Exception as error:
            messagebox.showerror("Product Error", "Products could not be loaded. Please try again.")

    def on_select(self, event=None) -> None:
        selection = self.tree.selection()
        if not selection:
            return
        product_id = int(selection[0])
        for product in self.products:
            if product.product_id == product_id:
                self.form.populate_form(product)
                return
