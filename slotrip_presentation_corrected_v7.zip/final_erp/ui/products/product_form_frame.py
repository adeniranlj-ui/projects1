import tkinter as tk
from tkinter import messagebox, ttk

from services import product_service, supplier_service


class ProductFormFrame(ttk.LabelFrame):
    def __init__(self, parent, on_saved):
        super().__init__(parent, text="Product Form", padding=8)
        self.on_saved = on_saved
        self.selected_product_id = None
        self.vars = {
            name: tk.StringVar()
            for name in ["product_name", "sku", "category", "unit_cost", "unit_price", "reorder_point"]
        }
        self.supplier_var = tk.StringVar()
        self.sku_entry = None
        self.unit_cost_entry = None
        self.supplier_combo = None
        self._build_layout()
        self.load_suppliers()

    def _build_layout(self) -> None:
        fields = [
            ("Name", "product_name"),
            ("SKU", "sku"),
            ("Category", "category"),
            ("Unit Cost", "unit_cost"),
            ("Unit Price", "unit_price"),
            ("Reorder Point", "reorder_point"),
        ]
        for index, (label, key) in enumerate(fields):
            ttk.Label(self, text=label).grid(row=index, column=0, sticky="w", pady=2)
            entry = ttk.Entry(self, textvariable=self.vars[key])
            entry.grid(row=index, column=1, sticky="ew", pady=2)
            if key == "sku":
                self.sku_entry = entry
            if key == "unit_cost":
                self.unit_cost_entry = entry

        ttk.Label(self, text="Supplier").grid(row=6, column=0, sticky="w", pady=2)
        self.supplier_combo = ttk.Combobox(self, textvariable=self.supplier_var, state="readonly")
        self.supplier_combo.grid(row=6, column=1, sticky="ew", pady=2)
        ttk.Button(self, text="New", command=self.clear_form).grid(row=7, column=0, pady=8)
        ttk.Button(self, text="Save", command=self.save).grid(row=7, column=1, pady=8)
        ttk.Button(self, text="Deactivate", command=self.deactivate).grid(row=8, column=0, columnspan=2, sticky="ew")
        self.columnconfigure(1, weight=1)

    def load_suppliers(self) -> None:
        try:
            self.suppliers = supplier_service.get_active_suppliers()
            self.supplier_combo["values"] = [
                f"{supplier.supplier_id}: {supplier.supplier_name}" for supplier in self.suppliers
            ]
        except Exception:
            messagebox.showerror("Supplier Error", "Suppliers could not be loaded. Please try again.")

    def _set_edit_state(self, editing: bool) -> None:
        sku_state = "disabled" if editing else "normal"
        cost_state = "disabled" if editing else "normal"
        supplier_state = "disabled" if editing else "readonly"
        if self.sku_entry is not None:
            self.sku_entry.config(state=sku_state)
        if self.unit_cost_entry is not None:
            self.unit_cost_entry.config(state=cost_state)
        if self.supplier_combo is not None:
            self.supplier_combo.config(state=supplier_state)

    def populate_form(self, product) -> None:
        self.selected_product_id = product.product_id
        self.vars["product_name"].set(product.product_name)
        self.vars["sku"].set(product.sku)
        self.vars["category"].set(product.category)
        self.vars["unit_cost"].set(str(product.unit_cost))
        self.vars["unit_price"].set(str(product.unit_price))
        self.vars["reorder_point"].set(str(product.reorder_point))
        self.supplier_var.set(f"{product.default_supplier_id}: {product.supplier_name}")
        self._set_edit_state(True)

    def clear_form(self) -> None:
        self.selected_product_id = None
        self._set_edit_state(False)
        for var in self.vars.values():
            var.set("")
        self.supplier_var.set("")

    def _supplier_id_from_combo(self) -> int | None:
        value = self.supplier_var.get()
        if not value or ":" not in value:
            return None
        try:
            return int(value.split(":")[0])
        except ValueError:
            raise ValueError("Please select a valid supplier.") from None

    def save(self) -> None:
        try:
            supplier_id = self._supplier_id_from_combo()
            data = {key: var.get() for key, var in self.vars.items()}
            data["default_supplier_id"] = supplier_id
            if self.selected_product_id:
                product_service.update_product(self.selected_product_id, data)
            else:
                product_service.create_product(data)
            self.clear_form()
            self.on_saved()
            messagebox.showinfo("Product Saved", "Product saved successfully.")
        except ValueError as error:
            messagebox.showerror("Product Error", str(error))
        except Exception:
            messagebox.showerror("Product Error", "The product could not be saved. Please check the information and try again.")

    def deactivate(self) -> None:
        try:
            if self.selected_product_id:
                product_service.deactivate_product(self.selected_product_id)
                self.clear_form()
                self.on_saved()
                messagebox.showinfo("Product Deactivated", "Product deactivated successfully.")
        except ValueError as error:
            messagebox.showerror("Product Error", str(error))
        except Exception:
            messagebox.showerror("Product Error", "The product could not be deactivated. Please try again.")
