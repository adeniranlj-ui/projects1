from tkinter import messagebox, ttk

from services import purchase_order_service
from ui.purchase_orders.po_form_frame import POFormFrame


class POListFrame(ttk.Frame):
    def __init__(self, parent, navigate):
        super().__init__(parent)
        self.orders = []
        ttk.Label(self, text="Purchase Orders", font=("Arial", 16, "bold")).pack(anchor="w")
        ttk.Label(
            self,
            text="Drafted = ready to send | Sent = waiting on supplier | Received = inventory added and ledger expense posted | Cancelled = closed",
        ).pack(anchor="w", pady=(0, 8))

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        left = ttk.Frame(body)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))

        tree_frame = ttk.Frame(left)
        tree_frame.pack(fill="both", expand=True)

        self.tree = ttk.Treeview(
            tree_frame,
            columns=("supplier", "location", "status", "created", "sent", "received", "total"),
            show="headings",
            selectmode="browse",
        )
        for col, text, width in [
            ("supplier", "Supplier", 170),
            ("location", "Location", 130),
            ("status", "Status", 95),
            ("created", "Created Date", 145),
            ("sent", "Sent Date", 145),
            ("received", "Received Date", 145),
            ("total", "Total", 95),
        ]:
            self.tree.heading(col, text=text, anchor="w")
            self.tree.column(col, anchor="w", width=width, minwidth=width)

        yscroll = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.pack(side="top", fill="both", expand=True)
        yscroll.pack(side="right", fill="y")
        xscroll.pack(side="bottom", fill="x")

        self.tree.tag_configure("drafted", foreground="#475569")
        self.tree.tag_configure("sent", foreground="#d97706")
        self.tree.tag_configure("received", foreground="#15803d")
        self.tree.tag_configure("cancelled", foreground="#dc2626")

        buttons = ttk.Frame(left)
        buttons.pack(fill="x", pady=5)
        ttk.Button(buttons, text="Mark Sent", command=self.mark_sent_selected).pack(side="left", padx=2)
        ttk.Button(buttons, text="Receive Selected", command=self.receive_selected).pack(side="left", padx=2)
        ttk.Button(buttons, text="Cancel Selected", command=self.cancel_selected).pack(side="left", padx=2)

        self.form = POFormFrame(body, self.load_orders)
        self.form.pack(side="right", fill="y")
        self.load_orders()

    def _display_status(self, order) -> str:
        if order.status == "Drafted" and order.sent_date:
            return "Sent"
        return order.status

    def _fmt_date(self, value: str | None) -> str:
        return value if value else "-"

    def load_orders(self) -> None:
        try:
            self.orders = purchase_order_service.get_purchase_orders({})
            for row in self.tree.get_children():
                self.tree.delete(row)
            for order in self.orders:
                display_status = self._display_status(order)
                self.tree.insert(
                    "",
                    "end",
                    iid=str(order.po_id),
                    values=(
                        order.supplier_name,
                        order.location_name,
                        display_status,
                        self._fmt_date(order.created_date),
                        self._fmt_date(order.sent_date),
                        self._fmt_date(order.received_date),
                        f"${order.po_total:,.2f}",
                    ),
                    tags=(display_status.lower(),),
                )
        except Exception:
            messagebox.showerror("Purchase Order Error", "Purchase orders could not be loaded. Please try again.")

    def _selected_po_id(self) -> int | None:
        selection = self.tree.selection()
        return int(selection[0]) if selection else None

    def mark_sent_selected(self) -> None:
        try:
            po_id = self._selected_po_id()
            if po_id is None:
                messagebox.showinfo("Purchase Order", "Select a purchase order first.")
                return
            purchase_order_service.mark_purchase_order_sent(po_id)
            self.load_orders()
            messagebox.showinfo("Purchase Order Sent", "Purchase order marked as sent.")
        except ValueError as error:
            messagebox.showerror("Send Error", str(error))
        except Exception:
            messagebox.showerror("Send Error", "The purchase order could not be marked as sent. Please try again.")

    def receive_selected(self) -> None:
        try:
            po_id = self._selected_po_id()
            if po_id is None:
                messagebox.showinfo("Purchase Order", "Select a purchase order first.")
                return
            purchase_order_service.receive_purchase_order(po_id)
            self.load_orders()
            messagebox.showinfo("Purchase Order Received", "Purchase order received and expense posted successfully.")
        except ValueError as error:
            messagebox.showerror("Receive Error", str(error))
        except Exception:
            messagebox.showerror("Receive Error", "The purchase order could not be received. Please try again.")

    def cancel_selected(self) -> None:
        try:
            po_id = self._selected_po_id()
            if po_id is None:
                messagebox.showinfo("Purchase Order", "Select a purchase order first.")
                return
            purchase_order_service.cancel_purchase_order(po_id)
            self.load_orders()
            messagebox.showinfo("Purchase Order Cancelled", "Purchase order cancelled successfully.")
        except ValueError as error:
            messagebox.showerror("Cancel Error", str(error))
        except Exception:
            messagebox.showerror("Cancel Error", "The purchase order could not be cancelled. Please try again.")
