import tkinter as tk
from tkinter import messagebox, ttk

from services import location_service, product_service, purchase_order_service, supplier_service


class POFormFrame(ttk.LabelFrame):
    def __init__(self, parent, on_saved):
        super().__init__(parent, text="Purchase Order Form", padding=8)
        self.on_saved = on_saved
        self.line_items = []
        self.supplier_var = tk.StringVar()
        self.location_var = tk.StringVar()
        self.product_var = tk.StringVar()
        self.quantity_var = tk.StringVar()
        self._build_layout()
        self.load_dropdowns()

    def _build_layout(self) -> None:
        labels = ["Supplier", "Location", "Product", "Quantity"]
        vars_ = [self.supplier_var, self.location_var, self.product_var, self.quantity_var]
        self.combos = []
        for index, label in enumerate(labels):
            ttk.Label(self, text=label).grid(row=index, column=0, sticky="w", pady=2)
            if label == "Quantity":
                ttk.Entry(self, textvariable=vars_[index]).grid(row=index, column=1, sticky="ew", pady=2)
            else:
                combo = ttk.Combobox(self, textvariable=vars_[index], state="readonly")
                combo.grid(row=index, column=1, sticky="ew", pady=2)
                self.combos.append(combo)
        ttk.Button(self, text="Add Line", command=self.add_line_item).grid(row=4, column=0, pady=6)
        ttk.Button(self, text="Create PO", command=self.create_po).grid(row=4, column=1, pady=6)
        self.line_tree = ttk.Treeview(self, columns=("product", "qty"), show="headings", height=5)
        self.line_tree.heading("product", text="Product", anchor="w")
        self.line_tree.column("product", anchor="w")
        self.line_tree.heading("qty", text="Qty", anchor="w")
        self.line_tree.column("qty", anchor="w")
        self.line_tree.grid(row=5, column=0, columnspan=2, sticky="nsew")
        self.columnconfigure(1, weight=1)

    def load_dropdowns(self) -> None:
        try:
            self.suppliers = supplier_service.get_active_suppliers()
            self.locations = location_service.get_all_locations()
            self.products = product_service.get_active_products()
            self.combos[0]["values"] = [f"{supplier.supplier_id}: {supplier.supplier_name}" for supplier in self.suppliers]
            self.combos[1]["values"] = [f"{location.location_id}: {location.location_name}" for location in self.locations]
            self.combos[2]["values"] = [f"{product.product_id}: {product.product_name}" for product in self.products]
        except Exception:
            messagebox.showerror("Purchase Order Error", "Purchase order dropdowns could not be loaded. Please try again.")

    def _id_from_combo(self, value: str, field_name: str) -> int:
        if not value or ":" not in value:
            raise ValueError(f"Please select a {field_name}.")
        try:
            return int(value.split(":")[0])
        except ValueError:
            raise ValueError(f"Please select a valid {field_name}.") from None

    def add_line_item(self) -> None:
        try:
            product_id = self._id_from_combo(self.product_var.get(), "product")
            try:
                quantity = int(self.quantity_var.get().strip())
            except ValueError:
                raise ValueError("Please enter a valid whole number for quantity.") from None
            if quantity <= 0:
                raise ValueError("Quantity must be greater than zero.")
            product = next(item for item in self.products if item.product_id == product_id)
            self.line_items.append({"product_id": product_id, "quantity": quantity, "unit_cost": product.unit_cost})
            self.line_tree.insert("", "end", values=(product.product_name, quantity))
            self.quantity_var.set("")
        except ValueError as error:
            messagebox.showerror("Purchase Order Error", str(error))
        except Exception:
            messagebox.showerror("Purchase Order Error", "The line item could not be added. Please check the information and try again.")

    def create_po(self) -> None:
        try:
            purchase_order_service.create_purchase_order(
                self._id_from_combo(self.supplier_var.get(), "supplier"),
                self._id_from_combo(self.location_var.get(), "location"),
                self.line_items,
            )
            self.line_items.clear()
            for row in self.line_tree.get_children():
                self.line_tree.delete(row)
            self.on_saved()
            messagebox.showinfo("Purchase Order Saved", "Purchase order saved successfully.")
        except ValueError as error:
            messagebox.showerror("Purchase Order Error", str(error))
        except Exception:
            messagebox.showerror("Purchase Order Error", "The purchase order could not be saved. Please check the information and try again.")
