import tkinter as tk
from tkinter import messagebox, ttk

from services import inventory_service, simulation_service


class SimulationFrame(ttk.Frame):
    def __init__(self, parent, navigate):
        super().__init__(parent)
        self.navigate = navigate
        self.run_choice = tk.StringVar(value="1")
        self.custom_days_var = tk.StringVar()
        self._build_layout()
        self.load_inventory_summary()

    def _build_layout(self) -> None:
        ttk.Label(self, text="Simulation Runner", font=("Arial", 16, "bold")).pack(anchor="w")
        ttk.Label(
            self,
            text=(
                "Append realistic simulated business data without overwriting prior simulation runs. "
                "Low-stock items are automatically reordered and received during simulation."
            ),
        ).pack(anchor="w", pady=(0, 10))

        controls = ttk.LabelFrame(self, text="How much data should be added?", padding=8)
        controls.pack(fill="x", pady=(0, 10))
        choices = [
            ("Run simulation for 1 day", "1"),
            ("Run simulation for 1 week", "7"),
            ("Run simulation for 1 month", "30"),
            ("Run custom number of days", "custom"),
        ]
        for index, (label, value) in enumerate(choices):
            ttk.Radiobutton(controls, text=label, variable=self.run_choice, value=value).grid(row=index, column=0, sticky="w", pady=2)
        ttk.Label(controls, text="Custom days").grid(row=3, column=1, sticky="w", padx=(18, 4))
        ttk.Entry(controls, textvariable=self.custom_days_var, width=10).grid(row=3, column=2, sticky="w")
        ttk.Button(controls, text="Run Simulation", command=self.run_simulation).grid(row=4, column=0, sticky="w", pady=(8, 0))

        self.inventory_label = ttk.Label(self, text="Current inventory summary")
        self.inventory_label.pack(anchor="w")
        self.inventory_tree = ttk.Treeview(self, columns=("location", "product", "quantity"), show="headings", height=8)
        for col, text in [("location", "Location"), ("product", "Product"), ("quantity", "Qty")]:
            self.inventory_tree.heading(col, text=text, anchor="w")
            self.inventory_tree.column(col, anchor="w")
        self.inventory_tree.pack(fill="x", pady=5)
        self.status_label = ttk.Label(self, text="Ready")
        self.status_label.pack(anchor="w", pady=5)
        self.result_label = ttk.Label(self, justify="left")
        self.result_label.pack(anchor="w", pady=10)
        ttk.Button(self, text="View Sales History", command=lambda: self.navigate("sales_history")).pack(anchor="w", pady=2)
        ttk.Button(self, text="View Ledger", command=lambda: self.navigate("ledger")).pack(anchor="w", pady=2)

    def load_inventory_summary(self) -> None:
        try:
            for row in self.inventory_tree.get_children():
                self.inventory_tree.delete(row)
            for item in inventory_service.get_inventory_summary():
                self.inventory_tree.insert("", "end", values=(item.location_name, item.product_name, item.quantity))
        except Exception:
            messagebox.showerror("Simulation Error", "Inventory summary could not be loaded. Please try again.")

    def _selected_days(self) -> int:
        choice = self.run_choice.get()
        if choice == "custom":
            try:
                days = int(self.custom_days_var.get().strip())
            except ValueError:
                raise ValueError("Please enter a valid whole number for custom days.") from None
            if days <= 0:
                raise ValueError("Custom days must be greater than zero.")
            return days
        return int(choice)

    def run_simulation(self) -> None:
        try:
            days = self._selected_days()
            self.status_label.config(text="Simulation running...")
            self.update_idletasks()
            result = simulation_service.run_simulation_days(days)
            message = (
                f"Simulation complete. Added {result['days_added']} new simulated days, "
                f"{result['sales_posted']} sales, {result['pos_processed']} purchase orders auto-received, "
                f"and {result['shifts_logged']} shifts."
            )
            if result["days_skipped"]:
                message += f" Skipped {result['days_skipped']} days because they were already simulated."
            if result["warnings"]:
                shown_warnings = "\n".join(result["warnings"][:6])
                if len(result["warnings"]) > 6:
                    shown_warnings += "\nAdditional warnings were hidden to keep this message readable."
                message += f"\n\nWarnings:\n{shown_warnings}"
            self.result_label.config(text=message)
            self.status_label.config(text="Complete")
            self.load_inventory_summary()
            messagebox.showinfo("Simulation Complete", message)
        except ValueError as error:
            self.status_label.config(text="Ready")
            messagebox.showerror("Simulation Error", str(error))
        except Exception:
            self.status_label.config(text="Failed")
            messagebox.showerror("Simulation Error", "Simulation could not be completed. Please try again.")
