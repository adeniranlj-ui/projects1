import tkinter as tk
from tkinter import ttk


class LedgerEntryFormFrame(ttk.LabelFrame):
    def __init__(self, parent):
        super().__init__(parent, text="Ledger Entry Details", padding=8)
        self.text_var = tk.StringVar(value="Select a ledger entry to view details.")
        ttk.Label(self, textvariable=self.text_var, justify="left").pack(anchor="w")

    def show_entry(self, entry) -> None:
        self.text_var.set(
            f"Entry ID: {entry.ledger_entry_id}\n"
            f"Date: {entry.entry_date}\n"
            f"Type: {entry.entry_type}\n"
            f"Source Type: {entry.source_type}\n"
            f"Source Record ID: {entry.source_record_id}\n"
            f"Amount: ${entry.amount:.2f}\n"
            f"Running Balance: ${entry.running_balance:.2f}\n"
            f"Description: {entry.description}\n"
            f"Sale ID: {entry.related_sale_id}\n"
            f"PO ID: {entry.related_po_id}"
        )
