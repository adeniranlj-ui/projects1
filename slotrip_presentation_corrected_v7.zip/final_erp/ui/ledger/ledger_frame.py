import tkinter as tk
from tkinter import messagebox, ttk

from services import ledger_service
from ui.ledger.ledger_entry_form_frame import LedgerEntryFormFrame
from ui.theme import COLORS


class LedgerFrame(ttk.Frame):
    def __init__(self, parent, navigate):
        super().__init__(parent)
        self.entries = []
        self.total_income_value = None
        self.total_expense_value = None
        self.net_total_value = None
        self.entry_count_value = None
        self._build_layout()
        self.load_entries()

    def _build_layout(self) -> None:
        ttk.Label(self, text="Ledger", font=("Arial", 16, "bold")).pack(anchor="w")
        ttk.Label(
            self,
            text="Sales post as income. Received purchase orders and payroll post as expenses. Net balance = income minus expenses.",
            foreground=COLORS["muted"],
        ).pack(anchor="w", pady=(2, 8))

        summary_row = ttk.Frame(self)
        summary_row.pack(fill="x", pady=(0, 10))
        for column in range(4):
            summary_row.columnconfigure(column, weight=1)

        self.total_income_value = self._summary_card(summary_row, "TOTAL INCOME", "$0.00", 0)
        self.total_expense_value = self._summary_card(summary_row, "TOTAL EXPENSES", "$0.00", 1)
        self.net_total_value = self._summary_card(summary_row, "NET LEDGER BALANCE", "$0.00", 2)
        self.entry_count_value = self._summary_card(summary_row, "LEDGER ENTRIES", "0", 3)

        ttk.Button(self, text="Refresh", command=self.load_entries).pack(anchor="w", pady=(0, 8))

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(
            body,
            columns=("date", "type", "source", "income", "expense", "balance", "description"),
            show="headings",
        )
        headings = [
            ("date", "Date", 150),
            ("type", "Type", 90),
            ("source", "Source", 120),
            ("income", "Income", 95),
            ("expense", "Expense", 95),
            ("balance", "Balance", 100),
            ("description", "Description", 280),
        ]
        for col, text, width in headings:
            self.tree.heading(col, text=text, anchor="w")
            self.tree.column(col, width=width, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True, padx=(0, 8))

        self.detail = LedgerEntryFormFrame(body)
        self.detail.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.show_details)

    def _summary_card(self, parent, title: str, value: str, column: int):
        card = tk.Frame(parent, bg=COLORS["panel"], padx=14, pady=10, highlightbackground="#e5e7eb", highlightthickness=1)
        card.grid(row=0, column=column, sticky="nsew", padx=(0 if column == 0 else 6, 0 if column == 3 else 6))
        tk.Label(card, text=title, bg=COLORS["panel"], fg=COLORS["muted"], font=("Segoe UI", 9, "bold")).pack(anchor="w")
        value_label = tk.Label(card, text=value, bg=COLORS["panel"], fg=COLORS["text"], font=("Segoe UI", 16, "bold"))
        value_label.pack(anchor="w", pady=(4, 0))
        return value_label

    def _money(self, amount: float) -> str:
        return f"${amount:,.2f}"

    def load_entries(self) -> None:
        try:
            summary = ledger_service.get_ledger_summary({})
            self.total_income_value.config(text=self._money(summary["total_income"]))
            self.total_expense_value.config(text=self._money(summary["total_expense"]))
            self.net_total_value.config(text=self._money(summary["net_total"]))
            self.entry_count_value.config(text=str(summary["entry_count"]))

            self.entries = ledger_service.get_ledger_entries({})
            for row in self.tree.get_children():
                self.tree.delete(row)
            for entry in self.entries:
                income_amount = self._money(entry.amount) if entry.entry_type == "Income" else ""
                expense_amount = self._money(entry.amount) if entry.entry_type == "Expense" else ""
                self.tree.insert(
                    "",
                    "end",
                    iid=str(entry.ledger_entry_id),
                    values=(
                        entry.entry_date,
                        entry.entry_type,
                        entry.source_type,
                        income_amount,
                        expense_amount,
                        self._money(entry.running_balance),
                        entry.description,
                    ),
                )
        except Exception:
            messagebox.showerror("Ledger Error", "Ledger entries could not be loaded. Please try again.")

    def show_details(self, event=None) -> None:
        selection = self.tree.selection()
        if not selection:
            return
        entry_id = int(selection[0])
        for entry in self.entries:
            if entry.ledger_entry_id == entry_id:
                self.detail.show_entry(entry)
                return
