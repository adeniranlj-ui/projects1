from tkinter import messagebox, ttk

from services import supplier_service
from ui.suppliers.supplier_form_frame import SupplierFormFrame


class SupplierListFrame(ttk.Frame):
    def __init__(self, parent, navigate):
        super().__init__(parent)
        self.suppliers = []
        ttk.Label(self, text="Suppliers", font=("Arial", 16, "bold")).pack(anchor="w")
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(body, columns=("name", "category", "active", "ban_reason"), show="headings")
        for col, text in [("name", "Name"), ("category", "Category"), ("active", "Active"), ("ban_reason", "Ban Reason")]:
            self.tree.heading(col, text=text, anchor="w")
            self.tree.column(col, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True, padx=(0, 8))
        self.form = SupplierFormFrame(body, self.load_suppliers)
        self.form.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.load_suppliers()

    def load_suppliers(self) -> None:
        try:
            self.suppliers = supplier_service.get_all_suppliers()
            for row in self.tree.get_children():
                self.tree.delete(row)
            for supplier in self.suppliers:
                self.tree.insert(
                    "",
                    "end",
                    iid=str(supplier.supplier_id),
                    values=(supplier.supplier_name, supplier.category, supplier.active, supplier.ban_reason or ""),
                )
        except Exception:
            messagebox.showerror("Supplier Error", "Suppliers could not be loaded. Please try again.")

    def on_select(self, event=None) -> None:
        selection = self.tree.selection()
        if selection:
            supplier_id = int(selection[0])
            for supplier in self.suppliers:
                if supplier.supplier_id == supplier_id:
                    self.form.populate_form(supplier)
