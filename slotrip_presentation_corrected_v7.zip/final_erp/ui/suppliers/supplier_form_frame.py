import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

from services import supplier_service


class SupplierFormFrame(ttk.LabelFrame):
    def __init__(self, parent, on_saved):
        super().__init__(parent, text="Supplier Form", padding=8)
        self.on_saved = on_saved
        self.supplier_id = None
        self.current_supplier = None
        self.name_var = tk.StringVar()
        self.category_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Active")
        ttk.Label(self, text="Name").grid(row=0, column=0, sticky="w")
        ttk.Entry(self, textvariable=self.name_var).grid(row=0, column=1, sticky="ew")
        ttk.Label(self, text="Category").grid(row=1, column=0, sticky="w")
        ttk.Entry(self, textvariable=self.category_var).grid(row=1, column=1, sticky="ew")
        ttk.Label(self, text="Status").grid(row=2, column=0, sticky="w")
        ttk.Label(self, textvariable=self.status_var).grid(row=2, column=1, sticky="w")
        ttk.Button(self, text="New", command=self.clear_form).grid(row=3, column=0, pady=8)
        ttk.Button(self, text="Save", command=self.save).grid(row=3, column=1, pady=8)
        ttk.Button(self, text="Ban Supplier", command=self.ban_supplier).grid(row=4, column=0, columnspan=2, sticky="ew", pady=(4, 0))
        ttk.Button(self, text="Reactivate Supplier", command=self.reactivate_supplier).grid(row=5, column=0, columnspan=2, sticky="ew", pady=(4, 0))
        self.columnconfigure(1, weight=1)

    def populate_form(self, supplier) -> None:
        self.current_supplier = supplier
        self.supplier_id = supplier.supplier_id
        self.name_var.set(supplier.supplier_name)
        self.category_var.set(supplier.category)
        self.status_var.set("Active" if supplier.active == 1 else "Banned/Inactive")

    def clear_form(self) -> None:
        self.current_supplier = None
        self.supplier_id = None
        self.name_var.set("")
        self.category_var.set("")
        self.status_var.set("Active")

    def save(self) -> None:
        try:
            data = {
                "supplier_name": self.name_var.get(),
                "category": self.category_var.get(),
            }
            if self.supplier_id:
                supplier_service.update_supplier(self.supplier_id, data)
            else:
                supplier_service.create_supplier(data)
            self.clear_form()
            self.on_saved()
            messagebox.showinfo("Supplier Saved", "Supplier saved successfully.")
        except ValueError as error:
            messagebox.showerror("Supplier Error", str(error))
        except Exception:
            messagebox.showerror("Supplier Error", "The supplier could not be saved. Please check the information and try again.")

    def ban_supplier(self) -> None:
        try:
            if not self.supplier_id:
                messagebox.showinfo("Supplier", "Select a supplier first.")
                return
            reason = simpledialog.askstring("Ban Supplier", "Enter the reason this supplier is banned:", parent=self)
            if reason is None:
                return
            supplier_service.ban_supplier(self.supplier_id, reason)
            self.clear_form()
            self.on_saved()
            messagebox.showinfo("Supplier Banned", "Supplier banned and deactivated successfully.")
        except ValueError as error:
            messagebox.showerror("Supplier Error", str(error))
        except Exception:
            messagebox.showerror("Supplier Error", "The supplier could not be banned. Please try again.")

    def reactivate_supplier(self) -> None:
        try:
            if not self.supplier_id or self.current_supplier is None:
                messagebox.showinfo("Supplier", "Select a supplier first.")
                return
            reason = self.current_supplier.ban_reason or "No ban reason was recorded."
            if not messagebox.askyesno(
                "Reactivate Supplier",
                f"This supplier was banned for this reason:\n\n{reason}\n\nReactivate this supplier?",
            ):
                return
            supplier_service.reactivate_supplier(self.supplier_id)
            self.clear_form()
            self.on_saved()
            messagebox.showinfo("Supplier Reactivated", "Supplier reactivated successfully.")
        except ValueError as error:
            messagebox.showerror("Supplier Error", str(error))
        except Exception:
            messagebox.showerror("Supplier Error", "The supplier could not be reactivated. Please try again.")
