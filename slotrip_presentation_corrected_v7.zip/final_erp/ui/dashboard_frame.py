from datetime import date
from tkinter import messagebox, ttk

from bootstrap import session
from services import dashboard_service


class DashboardFrame(ttk.Frame):
    def __init__(self, parent, navigate):
        super().__init__(parent)
        self.navigate = navigate
        self.card_values = {}
        self.low_stock = None
        self.po_tree = None
        self.customer_tree = None
        self._build_layout()
        self.load_dashboard()

    def _build_layout(self) -> None:
        header = ttk.Frame(self)
        header.pack(fill="x", pady=(0, 14))
        ttk.Label(header, text="Dashboard", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="A business snapshot of sales, purchasing, inventory, payroll, ledger, and customers.",
            style="Subtitle.TLabel",
        ).pack(anchor="w", pady=(2, 0))

        card_row = ttk.Frame(self)
        card_row.pack(fill="x", pady=(0, 10))
        for col in range(4):
            card_row.columnconfigure(col, weight=1)

        cards = [
            ("today_sales", "TODAY'S SALES", "$0.00", 0, 0),
            ("mtd_sales", "MONTH-TO-DATE SALES", "$0.00", 0, 1),
            ("income", "MONTH INCOME", "$0.00", 0, 2),
            ("expenses", "MONTH EXPENSES", "$0.00", 0, 3),
            ("net", "NET LEDGER BALANCE", "$0.00", 1, 0),
            ("open_pos", "OPEN PURCHASE ORDERS", "0", 1, 1),
            ("low_stock", "LOW STOCK ALERTS", "0", 1, 2),
            ("repeat_customers", "REPEAT CUSTOMERS", "0", 1, 3),
        ]
        for key, title, value, row, col in cards:
            self.card_values[key] = self._create_card(card_row, title, value, row, col)

        action_row = ttk.Frame(self)
        action_row.pack(fill="x", pady=(0, 12))
        ttk.Button(action_row, text="Refresh Dashboard", style="Primary.TButton", command=self.load_dashboard).pack(side="left")
        if session.is_admin():
            ttk.Button(action_row, text="Run Simulation", style="Accent.TButton", command=lambda: self.navigate("simulation")).pack(side="left", padx=8)

        detail = ttk.Frame(self)
        detail.pack(fill="both", expand=True)
        detail.columnconfigure(0, weight=2)
        detail.columnconfigure(1, weight=1)
        detail.rowconfigure(0, weight=2)
        detail.rowconfigure(1, weight=1)

        low_panel = ttk.Frame(detail, padding=8, style="Panel.TFrame")
        low_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 8), pady=(0, 8))
        ttk.Label(low_panel, text="Inventory Items Needing Attention", font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(0, 6))
        self.low_stock = ttk.Treeview(
            low_panel,
            columns=("location", "product", "quantity", "reorder"),
            show="headings",
            height=10,
        )
        for col, text, width in [
            ("location", "Location", 150),
            ("product", "Product", 220),
            ("quantity", "Qty Available", 120),
            ("reorder", "Reorder Point", 120),
        ]:
            self.low_stock.heading(col, text=text, anchor="w")
            self.low_stock.column(col, anchor="w", width=width)
        self.low_stock.pack(fill="both", expand=True)

        po_panel = ttk.Frame(detail, padding=8, style="Panel.TFrame")
        po_panel.grid(row=0, column=1, sticky="nsew", pady=(0, 8))
        ttk.Label(po_panel, text="Recent Purchase Orders", font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(0, 6))
        self.po_tree = ttk.Treeview(
            po_panel,
            columns=("supplier", "status", "received", "total"),
            show="headings",
            height=10,
        )
        for col, text, width in [
            ("supplier", "Supplier", 140),
            ("status", "Status", 90),
            ("received", "Received", 120),
            ("total", "Total", 90),
        ]:
            self.po_tree.heading(col, text=text, anchor="w")
            self.po_tree.column(col, anchor="w", width=width)
        self.po_tree.pack(fill="both", expand=True)
        self.po_tree.tag_configure("drafted", foreground="#475569")
        self.po_tree.tag_configure("sent", foreground="#d97706")
        self.po_tree.tag_configure("received", foreground="#15803d")
        self.po_tree.tag_configure("cancelled", foreground="#dc2626")

        customer_panel = ttk.Frame(detail, padding=8, style="Panel.TFrame")
        customer_panel.grid(row=1, column=0, columnspan=2, sticky="nsew")
        ttk.Label(customer_panel, text="Top Repeat Customers", font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(0, 6))
        self.customer_tree = ttk.Treeview(
            customer_panel,
            columns=("customer", "sales", "total", "recent"),
            show="headings",
            height=5,
        )
        for col, text, width in [
            ("customer", "Customer", 220),
            ("sales", "Sales", 100),
            ("total", "Total Sales", 130),
            ("recent", "Most Recent Sale", 180),
        ]:
            self.customer_tree.heading(col, text=text, anchor="w")
            self.customer_tree.column(col, anchor="w", width=width)
        self.customer_tree.pack(fill="both", expand=True)

    def _create_card(self, parent, title: str, value: str, row: int, column: int):
        card = ttk.Frame(parent, padding=14, style="Panel.TFrame")
        card.grid(row=row, column=column, sticky="nsew", padx=5, pady=5)
        ttk.Label(card, text=title, style="CardTitle.TLabel").pack(anchor="w")
        value_label = ttk.Label(card, text=value, style="CardValue.TLabel")
        value_label.pack(anchor="w", pady=(8, 0))
        return value_label

    def _status_for_display(self, order) -> str:
        if order.status == "Drafted" and order.sent_date:
            return "Sent"
        return order.status

    def load_dashboard(self) -> None:
        try:
            summary = dashboard_service.get_dashboard_summary(date.today().isoformat())

            self.card_values["today_sales"].config(text=f"${summary['daily_sales_total']:,.2f}")
            self.card_values["mtd_sales"].config(text=f"${summary['month_to_date_sales_total']:,.2f}")
            self.card_values["income"].config(text=f"${summary['income']:,.2f}")
            self.card_values["expenses"].config(text=f"${summary['expenses']:,.2f}")
            self.card_values["net"].config(text=f"${summary['net']:,.2f}")
            self.card_values["open_pos"].config(text=str(summary["open_po_count"]))
            self.card_values["low_stock"].config(text=str(len(summary["low_stock_alerts"])))
            self.card_values["repeat_customers"].config(text=str(summary["repeat_customer_count"]))

            for row in self.low_stock.get_children():
                self.low_stock.delete(row)
            for item in summary["low_stock_alerts"]:
                self.low_stock.insert("", "end", values=(item.location_name, item.product_name, item.quantity, item.reorder_point))

            for row in self.po_tree.get_children():
                self.po_tree.delete(row)
            for order in summary["recent_purchase_orders"]:
                display_status = self._status_for_display(order)
                received_date = order.received_date or "-"
                self.po_tree.insert(
                    "",
                    "end",
                    values=(order.supplier_name, display_status, received_date, f"${order.po_total:,.2f}"),
                    tags=(display_status.lower(),),
                )

            for row in self.customer_tree.get_children():
                self.customer_tree.delete(row)
            for customer in summary["top_repeat_customers"]:
                self.customer_tree.insert(
                    "",
                    "end",
                    values=(
                        customer.customer_name,
                        customer.sales_count,
                        f"${customer.total_sales:,.2f}",
                        customer.most_recent_sale_date or "-",
                    ),
                )
        except Exception:
            messagebox.showerror("Dashboard Error", "Dashboard data could not be loaded. Please try again.")
