import tkinter as tk
from tkinter import messagebox, ttk

from bootstrap import session
from ui.customers.customer_list_frame import CustomerListFrame
from ui.dashboard_frame import DashboardFrame
from ui.employees.employee_list_frame import EmployeeListFrame
from ui.inventory.inventory_frame import InventoryFrame
from ui.ledger.ledger_frame import LedgerFrame
from ui.login_frame import LoginFrame
from ui.payroll.payroll_frame import PayrollFrame
from ui.products.product_list_frame import ProductListFrame
from ui.purchase_orders.po_list_frame import POListFrame
from ui.sales.sale_entry_frame import SaleEntryFrame
from ui.sales.sales_history_frame import SalesHistoryFrame
from ui.simulation_frame import SimulationFrame
from ui.suppliers.supplier_list_frame import SupplierListFrame
from ui.logo_utils import load_logo
from ui.theme import COLORS


class AppWindow:
    ADMIN_ONLY_SCREENS = {
        "products",
        "suppliers",
        "purchase_orders",
        "employees",
        "ledger",
        "simulation",
        "payroll",
    }

    def __init__(self, root: tk.Tk):
        self.root = root
        self.active_screen = None
        self.nav_buttons = {}
        self._logo_image = None
        self.main_frame = ttk.Frame(root)
        self.main_frame.pack(fill="both", expand=True)
        self.nav_frame = None
        self.content_frame = None
        self.show_login()

    def _clear_main(self) -> None:
        for child in self.main_frame.winfo_children():
            child.destroy()

    def show_login(self) -> None:
        self._clear_main()
        login = LoginFrame(self.main_frame, self.on_login_success)
        login.pack(fill="both", expand=True)

    def on_login_success(self, user: dict) -> None:
        session.set_current_user(user)
        self._build_main_window()
        self.show_screen("dashboard")

    def _build_main_window(self) -> None:
        self._clear_main()
        self.nav_buttons = {}
        self.nav_frame = tk.Frame(self.main_frame, bg=COLORS["nav"], width=260)
        self.nav_frame.pack(side="left", fill="y")
        self.nav_frame.pack_propagate(False)
        self.content_frame = ttk.Frame(self.main_frame, padding=20)
        self.content_frame.pack(side="right", fill="both", expand=True)
        self._build_navigation()

    def _make_nav_button(self, label: str, key: str, emoji: str = "") -> None:
        button = tk.Button(
            self.nav_frame,
            text=f"{emoji}  {label}" if emoji else label,
            anchor="w",
            command=lambda screen=key: self.show_screen(screen),
            bg=COLORS["nav"],
            fg="white",
            activebackground=COLORS["primary"],
            activeforeground="white",
            bd=0,
            padx=18,
            pady=11,
            font=("Segoe UI", 10, "bold"),
            cursor="hand2",
        )
        button.pack(fill="x", padx=12, pady=3)
        button.bind(
            "<Enter>",
            lambda _e, b=button: b.configure(bg=COLORS["primary_dark"]),
        )
        button.bind(
            "<Leave>",
            lambda _e, b=button, k=key: b.configure(
                bg=COLORS["primary"] if self.active_screen == k else COLORS["nav"]
            ),
        )
        self.nav_buttons[key] = button

    def _build_navigation(self) -> None:
        user = session.get_current_user() or {}

        logo_frame = tk.Frame(self.nav_frame, bg=COLORS["nav"])
        logo_frame.pack(anchor="w", fill="x", padx=10, pady=(14, 0))

        self._logo_image = load_logo(target_height=160, target_width=180, variant="nav")
        if self._logo_image:
            tk.Label(
                logo_frame,
                image=self._logo_image,
                bg=COLORS["nav"],
                bd=0,
                anchor="w",
            ).pack(anchor="w", pady=(0, 6))
        else:
            tk.Label(
                logo_frame,
                text="SloTrip",
                bg=COLORS["nav"],
                fg="white",
                font=("Segoe UI", 18, "bold"),
                anchor="w",
                justify="left",
            ).pack(anchor="w")

        tk.Label(
            logo_frame,
            text="Business Manager",
            bg=COLORS["nav"],
            fg="#c7d2fe",
            font=("Segoe UI", 9),
            anchor="w",
            justify="left",
        ).pack(anchor="w")

        tk.Label(
            self.nav_frame,
            text=f"{user.get('employee_name', '')}\n{user.get('role', '')}",
            justify="left",
            bg=COLORS["nav"],
            fg="#c7d2fe",
            font=("Segoe UI", 9),
        ).pack(anchor="w", padx=20, pady=(6, 16))

        buttons = [
            ("Dashboard", "dashboard", True, "📊"),
            ("Products", "products", session.is_admin(), "🛍️"),
            ("Inventory", "inventory", True, "📦"),
            ("Sales Entry", "sales", True, "💳"),
            ("Sales History", "sales_history", True, "🧾"),
            ("Customers", "customers", True, "👥"),
            ("Suppliers", "suppliers", session.is_admin(), "🚚"),
            ("Purchase Orders", "purchase_orders", session.is_admin(), "📝"),
            ("Employees", "employees", session.is_admin(), "🧑‍💼"),
            ("Payroll", "payroll", session.is_admin(), "💰"),
            ("Ledger", "ledger", session.is_admin(), "📒"),
            ("Simulation", "simulation", session.is_admin(), "⚡"),
        ]
        for label, key, visible, emoji in buttons:
            if visible:
                self._make_nav_button(label, key, emoji)

        tk.Frame(self.nav_frame, height=1, bg="#334155").pack(fill="x", padx=16, pady=14)
        self._make_nav_button("Logout", "logout", "🚪")
        self.nav_buttons["logout"].configure(command=self.logout)
        self._make_nav_button("Exit", "exit", "❌")
        self.nav_buttons["exit"].configure(command=self.on_closing)

    def _highlight_active_button(self, screen_name: str) -> None:
        self.active_screen = screen_name
        for key, button in self.nav_buttons.items():
            button.configure(bg=COLORS["primary"] if key == screen_name else COLORS["nav"])

    def show_screen(self, screen_name: str) -> None:
        if screen_name in self.ADMIN_ONLY_SCREENS and not session.is_admin():
            messagebox.showerror("Access Denied", "Admin permission is required.")
            return

        frame_map = {
            "dashboard": DashboardFrame,
            "products": ProductListFrame,
            "inventory": InventoryFrame,
            "sales": SaleEntryFrame,
            "sales_history": SalesHistoryFrame,
            "customers": CustomerListFrame,
            "suppliers": SupplierListFrame,
            "purchase_orders": POListFrame,
            "employees": EmployeeListFrame,
            "payroll": PayrollFrame,
            "ledger": LedgerFrame,
            "simulation": SimulationFrame,
        }

        if screen_name not in frame_map:
            messagebox.showerror("Navigation Error", "The requested screen does not exist.")
            return

        for child in self.content_frame.winfo_children():
            child.destroy()

        self._highlight_active_button(screen_name)
        frame = frame_map[screen_name](self.content_frame, self.show_screen)
        frame.pack(fill="both", expand=True)

    def logout(self) -> None:
        session.clear_current_user()
        self.show_login()

    def on_closing(self) -> None:
        if messagebox.askokcancel("Exit", "Close SloTrip Business Manager?"):
            self.root.destroy()
