from tkinter import ttk

COLORS = {
    "nav": "#1f2a44",
    "nav_dark": "#172033",
    "bg": "#f4f7fb",
    "panel": "#ffffff",
    "primary": "#7c3aed",
    "primary_dark": "#5b21b6",
    "accent": "#06b6d4",
    "success": "#22c55e",
    "warning": "#f59e0b",
    "danger": "#ef4444",
    "text": "#111827",
    "muted": "#6b7280",
}


def apply_theme(root):
    """Apply a colorful ttk theme used by the ERP interface."""
    root.configure(bg=COLORS["bg"])
    style = ttk.Style(root)
    style.theme_use("clam")

    style.configure("TFrame", background=COLORS["bg"])
    style.configure("Panel.TFrame", background=COLORS["panel"], relief="flat")
    style.configure("TLabel", background=COLORS["bg"], foreground=COLORS["text"], font=("Segoe UI", 10))
    style.configure("Title.TLabel", background=COLORS["bg"], foreground=COLORS["text"], font=("Segoe UI", 20, "bold"))
    style.configure("Subtitle.TLabel", background=COLORS["bg"], foreground=COLORS["muted"], font=("Segoe UI", 10))
    style.configure("CardTitle.TLabel", background=COLORS["panel"], foreground=COLORS["muted"], font=("Segoe UI", 10, "bold"))
    style.configure("CardValue.TLabel", background=COLORS["panel"], foreground=COLORS["text"], font=("Segoe UI", 22, "bold"))

    style.configure("TButton", font=("Segoe UI", 10, "bold"), padding=(12, 8), borderwidth=0)
    style.map("TButton", background=[("active", "#e0e7ff")])
    style.configure("Primary.TButton", background=COLORS["primary"], foreground="white")
    style.map("Primary.TButton", background=[("active", COLORS["primary_dark"]), ("pressed", COLORS["primary_dark"])])
    style.configure("Accent.TButton", background=COLORS["accent"], foreground="white")
    style.map("Accent.TButton", background=[("active", "#0891b2"), ("pressed", "#0891b2")])
    style.configure("Danger.TButton", background=COLORS["danger"], foreground="white")
    style.map("Danger.TButton", background=[("active", "#b91c1c"), ("pressed", "#b91c1c")])

    style.configure("Treeview", background="white", foreground=COLORS["text"], fieldbackground="white", rowheight=30, font=("Segoe UI", 10))
    style.configure("Treeview.Heading", background="#dbeafe", foreground=COLORS["text"], font=("Segoe UI", 10, "bold"), padding=8)
    style.map("Treeview", background=[("selected", COLORS["primary"])], foreground=[("selected", "white")])

    style.configure("TEntry", padding=7)
    style.configure("TCombobox", padding=7)
