import tkinter as tk
from tkinter import messagebox, ttk

from services import auth_service
from ui.logo_utils import load_logo
from ui.theme import COLORS


class LoginFrame(ttk.Frame):
    def __init__(self, parent, on_login_success):
        super().__init__(parent, padding=40)
        self.on_login_success = on_login_success
        self.username_var = tk.StringVar(value="marcus.webb")
        self.password_var = tk.StringVar(value="changeme123")
        self.logo_image = None
        self._build_layout()

    def _build_layout(self) -> None:
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        box = tk.Frame(
            self,
            bg=COLORS["panel"],
            padx=38,
            pady=34,
            highlightbackground="#e5e7eb",
            highlightthickness=1,
        )
        box.grid(row=0, column=0)
        box.columnconfigure(0, weight=1)
        box.columnconfigure(1, weight=1)

        self.logo_image = load_logo(target_height=300, target_width=320, variant="login")
        if self.logo_image is not None:
            tk.Label(box, image=self.logo_image, bg=COLORS["panel"], bd=0).grid(
                row=0,
                column=0,
                columnspan=2,
                pady=(0, 10),
            )
        else:
            tk.Label(
                box,
                text="SloTrip",
                bg=COLORS["panel"],
                fg=COLORS["primary"],
                font=("Segoe UI", 30, "bold"),
                anchor="center",
                justify="center",
            ).grid(row=0, column=0, columnspan=2, pady=(0, 10))

        tk.Label(
            box,
            text="Business Manager ERP",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=("Segoe UI", 12),
            anchor="center",
            justify="center",
        ).grid(row=1, column=0, columnspan=2, pady=(0, 24))

        tk.Label(
            box,
            text="Username",
            bg=COLORS["panel"],
            fg=COLORS["text"],
            font=("Segoe UI", 10, "bold"),
        ).grid(row=2, column=0, sticky="w", pady=6)
        ttk.Entry(box, textvariable=self.username_var, width=34).grid(row=2, column=1, pady=6)
        tk.Label(
            box,
            text="Password",
            bg=COLORS["panel"],
            fg=COLORS["text"],
            font=("Segoe UI", 10, "bold"),
        ).grid(row=3, column=0, sticky="w", pady=6)
        ttk.Entry(box, textvariable=self.password_var, width=34, show="*").grid(row=3, column=1, pady=6)
        ttk.Button(
            box,
            text="Login to Dashboard",
            style="Primary.TButton",
            command=self._login,
        ).grid(row=4, column=0, columnspan=2, sticky="ew", pady=(20, 4))

    def _login(self) -> None:
        try:
            user = auth_service.login(self.username_var.get(), self.password_var.get())
            self.on_login_success(user)
        except ValueError as error:
            messagebox.showerror("Login Failed", str(error))
        except Exception:
            messagebox.showerror("Login Failed", "Something went wrong while signing in. Please try again.")
