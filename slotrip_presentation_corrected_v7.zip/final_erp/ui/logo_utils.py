import math
import tkinter as tk
from pathlib import Path

_VARIANT_FILENAMES = {
    "login": ("slotrip_logo_login.png", "slotrip_logo.png", "SloTrip_logo.png"),
    "nav": ("slotrip_logo_nav.png", "slotrip_logo.png", "SloTrip_logo.png"),
    "icon": ("slotrip_logo_icon.png", "slotrip_logo_nav.png", "slotrip_logo.png", "SloTrip_logo.png"),
    "default": ("slotrip_logo.png", "SloTrip_logo.png"),
}


def _find_logo_path(variant: str = "default") -> Path | None:
    base_path = Path(__file__).parent
    filenames = _VARIANT_FILENAMES.get(variant, _VARIANT_FILENAMES["default"])
    for filename in filenames:
        path = base_path / filename
        if path.exists():
            return path
    return None


def load_logo(
    target_height: int = 160,
    target_width: int | None = None,
    variant: str = "default",
):
    """Load the SloTrip logo using tkinter only.

    Prefer prepared PNG assets for the login screen and sidebar so the logo stays
    sharper. If the selected file is still larger than the target size, perform a
    light integer downscale using a rounded factor instead of always rounding up.
    That keeps the logo a bit larger and less fuzzy.
    """
    try:
        logo_path = _find_logo_path(variant)
        if logo_path is None:
            return None

        image = tk.PhotoImage(file=str(logo_path))
        scale_ratios = []
        if target_height and image.height() > target_height:
            scale_ratios.append(image.height() / target_height)
        if target_width and image.width() > target_width:
            scale_ratios.append(image.width() / target_width)

        if scale_ratios:
            factor = max(1, round(max(scale_ratios)))
            if factor > 1:
                image = image.subsample(factor, factor)
        return image
    except Exception:
        return None



def apply_window_icon(root: tk.Tk) -> None:
    try:
        icon = load_logo(target_height=64, target_width=64, variant="icon")
        if icon is not None:
            root.iconphoto(True, icon)
            root._slotrip_icon_image = icon
    except Exception:
        pass
