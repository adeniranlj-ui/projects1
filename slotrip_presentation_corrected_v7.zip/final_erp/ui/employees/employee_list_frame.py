from tkinter import messagebox, ttk

from services import employee_service
from ui.employees.employee_form_frame import EmployeeFormFrame


class EmployeeListFrame(ttk.Frame):
    def __init__(self, parent, navigate):
        super().__init__(parent)
        self.employees = []
        ttk.Label(self, text="Employees", font=("Arial", 16, "bold")).pack(anchor="w")
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(body, columns=("name", "username", "role", "location", "wage", "active"), show="headings")
        for col, text in [("name", "Name"), ("username", "Username"), ("role", "Role"), ("location", "Location"), ("wage", "Hourly Wage"), ("active", "Active")]:
            self.tree.heading(col, text=text, anchor="w")
            self.tree.column(col, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True, padx=(0, 8))
        self.form = EmployeeFormFrame(body, self.load_employees)
        self.form.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.load_employees()

    def load_employees(self) -> None:
        try:
            self.employees = employee_service.get_all_employees()
            for row in self.tree.get_children():
                self.tree.delete(row)
            for employee in self.employees:
                self.tree.insert(
                    "",
                    "end",
                    iid=str(employee.employee_id),
                    values=(employee.employee_name, employee.username, employee.role, employee.location_name, f"${employee.hourly_wage:.2f}", employee.active),
                )
        except Exception:
            messagebox.showerror("Employee Error", "Employees could not be loaded. Please try again.")

    def on_select(self, event=None) -> None:
        selection = self.tree.selection()
        if selection:
            employee_id = int(selection[0])
            for employee in self.employees:
                if employee.employee_id == employee_id:
                    self.form.populate_form(employee)
