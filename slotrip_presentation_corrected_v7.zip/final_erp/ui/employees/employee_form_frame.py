import tkinter as tk
from tkinter import messagebox, ttk

from services import employee_service, location_service


class EmployeeFormFrame(ttk.LabelFrame):
    def __init__(self, parent, on_saved):
        super().__init__(parent, text="Employee Form", padding=8)
        self.on_saved = on_saved
        self.employee_id = None
        self.name_var = tk.StringVar()
        self.username_var = tk.StringVar()
        self.password_var = tk.StringVar()
        self.role_var = tk.StringVar(value="Staff")
        self.location_var = tk.StringVar()
        self.hourly_wage_var = tk.StringVar()
        self.active_var = tk.IntVar(value=1)
        self._build_layout()
        self.load_locations()

    def _build_layout(self) -> None:
        fields = [
            ("Name", self.name_var),
            ("Username", self.username_var),
            ("Password", self.password_var),
            ("Hourly Wage", self.hourly_wage_var),
        ]
        for index, (label, var) in enumerate(fields):
            ttk.Label(self, text=label).grid(row=index, column=0, sticky="w", pady=2)
            ttk.Entry(self, textvariable=var, show="*" if label == "Password" else "").grid(row=index, column=1, sticky="ew")
        ttk.Label(self, text="Payroll uses the hourly wage stored here.").grid(row=4, column=1, sticky="w", pady=(0, 5))
        ttk.Label(self, text="Role").grid(row=5, column=0, sticky="w")
        ttk.Combobox(self, textvariable=self.role_var, values=["Admin", "Staff"], state="readonly").grid(row=5, column=1, sticky="ew")
        ttk.Label(self, text="Location").grid(row=6, column=0, sticky="w")
        self.location_combo = ttk.Combobox(self, textvariable=self.location_var, state="readonly")
        self.location_combo.grid(row=6, column=1, sticky="ew")
        ttk.Checkbutton(self, text="Active", variable=self.active_var).grid(row=7, column=1, sticky="w")
        ttk.Button(self, text="New", command=self.clear_form).grid(row=8, column=0, pady=8)
        ttk.Button(self, text="Save", command=self.save).grid(row=8, column=1, pady=8)
        ttk.Button(self, text="Deactivate", command=self.deactivate).grid(row=9, column=0, columnspan=2, sticky="ew")
        self.columnconfigure(1, weight=1)

    def load_locations(self) -> None:
        try:
            self.locations = location_service.get_all_locations()
            self.location_combo["values"] = [f"{location.location_id}: {location.location_name}" for location in self.locations]
        except Exception:
            messagebox.showerror("Employee Error", "Locations could not be loaded. Please try again.")

    def _id_from_combo(self, value: str) -> int:
        if not value or ":" not in value:
            raise ValueError("Location is required.")
        return int(value.split(":")[0])

    def populate_form(self, employee) -> None:
        self.employee_id = employee.employee_id
        self.name_var.set(employee.employee_name)
        self.username_var.set(employee.username)
        self.password_var.set("")
        self.hourly_wage_var.set(f"{employee.hourly_wage:.2f}")
        self.role_var.set(employee.role)
        self.location_var.set(f"{employee.location_id}: {employee.location_name}")
        self.active_var.set(employee.active)

    def clear_form(self) -> None:
        self.employee_id = None
        self.name_var.set("")
        self.username_var.set("")
        self.password_var.set("")
        self.hourly_wage_var.set("")
        self.role_var.set("Staff")
        self.location_var.set("")
        self.active_var.set(1)

    def save(self) -> None:
        try:
            data = {
                "employee_name": self.name_var.get(),
                "username": self.username_var.get(),
                "password": self.password_var.get(),
                "role": self.role_var.get(),
                "location_id": self._id_from_combo(self.location_var.get()),
                "hourly_wage": self.hourly_wage_var.get(),
                "active": self.active_var.get(),
            }
            if self.employee_id:
                employee_service.update_employee(self.employee_id, data)
            else:
                employee_service.create_employee(data)
            self.clear_form()
            self.on_saved()
            messagebox.showinfo("Employee Saved", "Employee saved successfully.")
        except ValueError as error:
            messagebox.showerror("Employee Error", str(error))
        except Exception:
            messagebox.showerror("Employee Error", "The employee could not be saved. Please check the information and try again.")

    def deactivate(self) -> None:
        try:
            if not self.employee_id:
                messagebox.showinfo("Employee", "Select an employee first.")
                return
            employee_service.deactivate_employee(self.employee_id)
            self.clear_form()
            self.on_saved()
            messagebox.showinfo("Employee Deactivated", "Employee deactivated successfully.")
        except ValueError as error:
            messagebox.showerror("Employee Error", str(error))
        except Exception:
            messagebox.showerror("Employee Error", "The employee could not be deactivated. Please try again.")
