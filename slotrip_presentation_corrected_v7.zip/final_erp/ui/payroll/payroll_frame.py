import tkinter as tk
from tkinter import messagebox, ttk

from bootstrap import session
from services import payroll_service
from ui.theme import COLORS


class PayrollFrame(ttk.Frame):
    """
    Payroll screen.

    The admin enters only the pay-period dates. The service layer pulls completed
    shift hours and the current employee hourly wage, then creates a draft run.
    """

    def __init__(self, parent, navigate):
        super().__init__(parent)
        self.navigate = navigate
        self._runs = []
        self._selected_run = None

        self._build_ui()
        self._load_runs()

    def _build_ui(self) -> None:
        ttk.Label(self, text="💰  Payroll", style="Title.TLabel").pack(
            anchor="w", pady=(0, 6)
        )
        ttk.Label(
            self,
            text=(
                "Enter a pay-period start and end date. Payroll is generated from "
                "completed shifts and each employee's stored hourly wage."
            ),
            style="Subtitle.TLabel",
            wraplength=850,
            justify="left",
        ).pack(anchor="w", pady=(0, 14))

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)

        left = ttk.Frame(body, style="Panel.TFrame")
        left.pack(side="left", fill="y", padx=(0, 16))
        left.pack_propagate(False)
        left.configure(width=540)

        ttk.Label(left, text="Payroll Runs", style="CardTitle.TLabel").pack(
            anchor="w", padx=12, pady=(10, 4)
        )

        tree_frame = ttk.Frame(left)
        tree_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        self._tree = ttk.Treeview(
            tree_frame,
            columns=("period", "run_date", "total", "status"),
            show="headings",
            selectmode="browse",
        )
        for col, text, width in [
            ("period", "Period", 220),
            ("run_date", "Run Date", 105),
            ("total", "Total ($)", 100),
            ("status", "Status", 85),
        ]:
            self._tree.heading(col, text=text, anchor="w")
            self._tree.column(col, width=width, minwidth=width, anchor="w", stretch=False)

        sb = ttk.Scrollbar(tree_frame, orient="vertical", command=self._tree.yview)
        xsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=self._tree.xview)
        self._tree.configure(yscrollcommand=sb.set, xscrollcommand=xsb.set)
        self._tree.pack(side="top", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        xsb.pack(side="bottom", fill="x")
        self._tree.bind("<<TreeviewSelect>>", self._on_run_select)

        new_btn = tk.Button(
            left,
            text="＋  Generate Payroll From Dates",
            bg=COLORS["primary"],
            fg="white",
            activebackground=COLORS["primary_dark"],
            activeforeground="white",
            font=("Segoe UI", 10, "bold"),
            bd=0,
            padx=12,
            pady=8,
            cursor="hand2",
            command=self._show_new_run_form,
            anchor="w",
        )
        new_btn.pack(fill="x", padx=8, pady=8)

        self._detail_frame = ttk.Frame(body, style="Panel.TFrame")
        self._detail_frame.pack(side="right", fill="both", expand=True)

        self._show_placeholder()

    def _load_runs(self) -> None:
        try:
            self._runs = payroll_service.get_all_runs()
        except Exception:
            messagebox.showerror(
                "Payroll Error",
                "Payroll information could not be loaded. Please try again.",
            )
            self._runs = []

        for row in self._tree.get_children():
            self._tree.delete(row)

        for run in self._runs:
            self._tree.insert(
                "",
                "end",
                iid=str(run.run_id),
                values=(
                    f"{run.period_start}  →  {run.period_end}",
                    run.run_date,
                    f"{run.total_amount:,.2f}",
                    run.status,
                ),
                tags=(run.status.lower(),),
            )

        self._tree.tag_configure("finalized", foreground=COLORS["success"])
        self._tree.tag_configure("draft", foreground=COLORS["warning"])

    def _on_run_select(self, _event=None) -> None:
        selection = self._tree.selection()
        if not selection:
            return
        run_id = int(selection[0])
        try:
            run = payroll_service.get_run_by_id(run_id)
        except Exception:
            messagebox.showerror(
                "Payroll Error",
                "Payroll run could not be loaded. Please try again.",
            )
            return
        self._selected_run = run
        self._show_run_detail(run)

    def _clear_detail(self) -> None:
        for widget in self._detail_frame.winfo_children():
            widget.destroy()

    def _show_placeholder(self) -> None:
        self._clear_detail()
        wrapper = ttk.Frame(self._detail_frame)
        wrapper.pack(fill="both", expand=True, padx=28, pady=28, anchor="nw")
        ttk.Label(
            wrapper,
            text="Select a run from the list or generate a new payroll run.",
            style="Subtitle.TLabel",
            justify="left",
        ).pack(anchor="w")
        ttk.Label(
            wrapper,
            text=(
                "Best payroll workflow: record shifts first, then enter only the "
                "pay-period dates here. The app totals completed shifts automatically."
            ),
            wraplength=600,
            justify="left",
        ).pack(anchor="w", pady=(10, 0))

    def _show_new_run_form(self) -> None:
        self._clear_detail()
        self._tree.selection_remove(self._tree.selection())
        self._selected_run = None

        frm = ttk.Frame(self._detail_frame)
        frm.pack(padx=28, pady=28, anchor="nw", fill="x")

        ttk.Label(frm, text="Generate Payroll From Shifts", font=("Segoe UI", 14, "bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 8)
        )
        ttk.Label(
            frm,
            text=(
                "Only enter the pay-period dates. The system pulls completed shifts "
                "inside the date range and each employee's hourly wage from Employee records."
            ),
            wraplength=620,
            justify="left",
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(0, 16))

        ttk.Label(frm, text="Period Start (YYYY-MM-DD)").grid(
            row=2, column=0, sticky="w", pady=6
        )
        start_var = tk.StringVar()
        ttk.Entry(frm, textvariable=start_var, width=22).grid(
            row=2, column=1, sticky="w", padx=(12, 0)
        )

        ttk.Label(frm, text="Period End   (YYYY-MM-DD)").grid(
            row=3, column=0, sticky="w", pady=6
        )
        end_var = tk.StringVar()
        ttk.Entry(frm, textvariable=end_var, width=22).grid(
            row=3, column=1, sticky="w", padx=(12, 0)
        )

        msg_var = tk.StringVar()
        ttk.Label(frm, textvariable=msg_var, foreground=COLORS["danger"], justify="left").grid(
            row=4, column=0, columnspan=2, sticky="w", pady=(8, 0)
        )

        def _create():
            try:
                user = session.get_current_user() or {}
                run_id = payroll_service.create_run(
                    start_var.get(),
                    end_var.get(),
                    user.get("employee_id", 1),
                )
                self._load_runs()
                self._tree.selection_set(str(run_id))
                self._tree.see(str(run_id))
                run = payroll_service.get_run_by_id(run_id)
                self._selected_run = run
                self._show_run_detail(run)
            except ValueError as exc:
                msg_var.set(str(exc))
            except Exception:
                messagebox.showerror(
                    "Payroll Error",
                    "Payroll run could not be generated. Please check the dates and shift data, then try again.",
                )

        tk.Button(
            frm,
            text="Generate Payroll",
            bg=COLORS["primary"],
            fg="white",
            activebackground=COLORS["primary_dark"],
            activeforeground="white",
            font=("Segoe UI", 10, "bold"),
            bd=0,
            padx=14,
            pady=7,
            cursor="hand2",
            command=_create,
            anchor="w",
        ).grid(row=5, column=0, columnspan=2, sticky="w", pady=(16, 0))

    def _show_run_detail(self, run) -> None:
        self._clear_detail()

        wrapper = ttk.Frame(self._detail_frame)
        wrapper.pack(fill="both", expand=True, padx=20, pady=16, anchor="nw")

        hdr = ttk.Frame(wrapper)
        hdr.pack(fill="x", pady=(0, 10), anchor="w")

        status_color = COLORS["success"] if run.status == "Finalized" else COLORS["warning"]
        ttk.Label(
            hdr,
            text=f"{run.period_start}  →  {run.period_end}",
            font=("Segoe UI", 13, "bold"),
        ).pack(side="left")
        ttk.Label(
            hdr,
            text=f"  [{run.status}]",
            font=("Segoe UI", 11, "bold"),
            foreground=status_color,
        ).pack(side="left")

        ttk.Label(
            wrapper,
            text=f"Run date: {run.run_date}   |   Created by: {run.created_by_name}",
            style="Subtitle.TLabel",
        ).pack(anchor="w", pady=(0, 6))
        ttk.Label(
            wrapper,
            text="Hours are calculated from completed shifts. Rates come from Employee records.",
            justify="left",
        ).pack(anchor="w", pady=(0, 10))

        tbl_frame = ttk.Frame(wrapper)
        tbl_frame.pack(fill="both", expand=True)

        columns = ("employee", "location", "hours", "rate", "gross")
        tbl = ttk.Treeview(
            tbl_frame,
            columns=columns,
            show="headings",
            selectmode="browse",
        )
        for col, text, width in [
            ("employee", "Employee", 180),
            ("location", "Location", 120),
            ("hours", "Shift Hours", 105),
            ("rate", "Rate ($/hr)", 105),
            ("gross", "Gross Pay", 115),
        ]:
            tbl.heading(col, text=text, anchor="w")
            tbl.column(col, width=width, anchor="w")

        sb2 = ttk.Scrollbar(tbl_frame, orient="vertical", command=tbl.yview)
        tbl.configure(yscrollcommand=sb2.set)
        tbl.pack(side="left", fill="both", expand=True)
        sb2.pack(side="right", fill="y")

        for entry in run.entries:
            tbl.insert(
                "",
                "end",
                iid=str(entry.entry_id),
                values=(
                    entry.employee_name,
                    entry.location_name,
                    f"{entry.hours_worked:.2f}",
                    f"{entry.hourly_rate:.2f}",
                    f"{entry.gross_pay:,.2f}",
                ),
            )

        total = sum(entry.gross_pay for entry in run.entries)
        ttk.Label(
            wrapper,
            text=f"Total Gross Payroll:  ${total:,.2f}",
            font=("Segoe UI", 12, "bold"),
        ).pack(anchor="w", pady=(10, 0))

        if run.status == "Draft":
            edit_hint = ttk.Label(
                wrapper,
                text="Select an entry below and click 'Edit Hours' to adjust a specific employee's hours before finalizing.",
                style="Subtitle.TLabel",
                justify="left",
            )
            edit_hint.pack(anchor="w", pady=(4, 0))

            edit_row = ttk.Frame(wrapper)
            edit_row.pack(anchor="w", pady=(6, 0), fill="x")

            hours_var = tk.StringVar()
            ttk.Label(edit_row, text="Hours:").pack(side="left")
            ttk.Entry(edit_row, textvariable=hours_var, width=10).pack(side="left", padx=(4, 8))

            def _edit_hours():
                selection = tbl.selection()
                if not selection:
                    messagebox.showinfo("Edit Hours", "Select an entry row first.")
                    return
                entry_id = int(selection[0])
                try:
                    payroll_service.update_entry(entry_id, hours_var.get())
                    refreshed = payroll_service.get_run_by_id(run.run_id)
                    self._selected_run = refreshed
                    self._show_run_detail(refreshed)
                    self._tree.selection_set(str(run.run_id))
                    messagebox.showinfo("Hours Updated", "Entry hours updated successfully.")
                except ValueError as exc:
                    messagebox.showerror("Edit Error", str(exc))
                except Exception:
                    messagebox.showerror("Edit Error", "Hours could not be updated. Please try again.")

            tk.Button(
                edit_row,
                text="Edit Hours",
                bg=COLORS["primary"],
                fg="white",
                activebackground=COLORS["primary_dark"],
                activeforeground="white",
                font=("Segoe UI", 9, "bold"),
                bd=0,
                padx=10,
                pady=5,
                cursor="hand2",
                command=_edit_hours,
            ).pack(side="left")

        if run.status == "Draft":
            action_row = ttk.Frame(wrapper)
            action_row.pack(anchor="w", pady=(10, 0))

            def _finalize():
                if not messagebox.askyesno(
                    "Finalize Payroll",
                    "Finalize this payroll run? This will post the payroll expense to the ledger and cannot be undone.",
                ):
                    return
                try:
                    final_total = payroll_service.finalize_run(run.run_id)
                    messagebox.showinfo(
                        "Payroll Finalized",
                        f"Run finalized.\nTotal: ${final_total:,.2f}",
                    )
                    self._load_runs()
                    refreshed = payroll_service.get_run_by_id(run.run_id)
                    self._selected_run = refreshed
                    self._show_run_detail(refreshed)
                    self._tree.selection_set(str(run.run_id))
                except ValueError as exc:
                    messagebox.showerror("Payroll Error", str(exc))
                except Exception:
                    messagebox.showerror(
                        "Payroll Error",
                        "Payroll run could not be finalized. Please try again.",
                    )

            def _delete():
                if not messagebox.askyesno(
                    "Delete Draft",
                    "Delete this draft payroll run and its generated entries?",
                ):
                    return
                try:
                    payroll_service.delete_run(run.run_id)
                    self._load_runs()
                    self._show_placeholder()
                except ValueError as exc:
                    messagebox.showerror("Payroll Error", str(exc))
                except Exception:
                    messagebox.showerror(
                        "Payroll Error",
                        "Payroll draft could not be deleted. Please try again.",
                    )

            tk.Button(
                action_row,
                text="✔  Finalize",
                bg=COLORS["success"],
                fg="white",
                activebackground="#16a34a",
                activeforeground="white",
                font=("Segoe UI", 10, "bold"),
                bd=0,
                padx=14,
                pady=7,
                cursor="hand2",
                command=_finalize,
                anchor="w",
            ).pack(side="left", padx=(0, 10))

            tk.Button(
                action_row,
                text="🗑  Delete Draft",
                bg=COLORS["danger"],
                fg="white",
                activebackground="#b91c1c",
                activeforeground="white",
                font=("Segoe UI", 10, "bold"),
                bd=0,
                padx=14,
                pady=7,
                cursor="hand2",
                command=_delete,
                anchor="w",
            ).pack(side="left")
