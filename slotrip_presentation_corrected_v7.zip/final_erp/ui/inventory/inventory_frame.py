from tkinter import messagebox, ttk

from services import inventory_service
from ui.inventory.transfer_frame import TransferFrame


class InventoryFrame(ttk.Frame):
    def __init__(self, parent, navigate):
        super().__init__(parent)
        self._build_layout()
        self.load_inventory()

    def _build_layout(self) -> None:
        ttk.Label(self, text="Inventory", font=("Arial", 16, "bold")).pack(anchor="w")
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(body, columns=("location", "product", "qty", "reorder"), show="headings")
        for col, text in [("location", "Location"), ("product", "Product"), ("qty", "Qty"), ("reorder", "Reorder")]:
            self.tree.heading(col, text=text, anchor="w")
            self.tree.column(col, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True, padx=(0, 8))
        self.transfer_frame = TransferFrame(body, self.load_inventory)
        self.transfer_frame.pack(side="right", fill="y")

    def load_inventory(self) -> None:
        try:
            for row in self.tree.get_children():
                self.tree.delete(row)
            for item in inventory_service.get_inventory({}):
                self.tree.insert("", "end", values=(item.location_name, item.product_name, item.quantity, item.reorder_point))
        except Exception:
            messagebox.showerror("Inventory Error", "Inventory could not be loaded. Please try again.")
