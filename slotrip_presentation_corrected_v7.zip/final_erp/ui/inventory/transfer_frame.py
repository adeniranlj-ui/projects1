import tkinter as tk
from tkinter import messagebox, ttk

from services import inventory_service, location_service, product_service


class TransferFrame(ttk.LabelFrame):
    def __init__(self, parent, on_saved):
        super().__init__(parent, text="Transfer Stock", padding=8)
        self.on_saved = on_saved
        self.from_var = tk.StringVar()
        self.to_var = tk.StringVar()
        self.product_var = tk.StringVar()
        self.quantity_var = tk.StringVar()
        self._build_layout()
        self.load_dropdowns()

    def _build_layout(self) -> None:
        labels = ["From", "To", "Product", "Quantity"]
        vars_ = [self.from_var, self.to_var, self.product_var, self.quantity_var]
        self.combos = []
        for i, label in enumerate(labels):
            ttk.Label(self, text=label).grid(row=i, column=0, sticky="w", pady=2)
            if label == "Quantity":
                ttk.Entry(self, textvariable=vars_[i]).grid(row=i, column=1, sticky="ew", pady=2)
            else:
                combo = ttk.Combobox(self, textvariable=vars_[i], state="readonly")
                combo.grid(row=i, column=1, sticky="ew", pady=2)
                self.combos.append(combo)
        ttk.Button(self, text="Transfer", command=self.transfer).grid(row=4, column=0, columnspan=2, pady=8, sticky="ew")
        self.columnconfigure(1, weight=1)

    def load_dropdowns(self) -> None:
        try:
            self.locations = location_service.get_all_locations()
            self.products = product_service.get_active_products()
            location_values = [f"{loc.location_id}: {loc.location_name}" for loc in self.locations]
            product_values = [f"{prod.product_id}: {prod.product_name}" for prod in self.products]
            self.combos[0]["values"] = location_values
            self.combos[1]["values"] = location_values
            self.combos[2]["values"] = product_values
        except Exception:
            messagebox.showerror("Transfer Error", "Transfer dropdowns could not be loaded. Please try again.")

    def _id_from_combo(self, value: str) -> int:
        if not value or ":" not in value:
            raise ValueError("All dropdown fields are required.")
        try:
            return int(value.split(":")[0])
        except ValueError:
            raise ValueError("Please select a valid dropdown value.") from None

    def _quantity_value(self) -> int:
        try:
            quantity = int(self.quantity_var.get().strip())
        except ValueError:
            raise ValueError("Please enter a valid whole number for quantity.") from None
        if quantity <= 0:
            raise ValueError("Quantity must be greater than zero.")
        return quantity

    def transfer(self) -> None:
        try:
            inventory_service.transfer_stock(
                self._id_from_combo(self.product_var.get()),
                self._id_from_combo(self.from_var.get()),
                self._id_from_combo(self.to_var.get()),
                self._quantity_value(),
            )
            self.quantity_var.set("")
            self.on_saved()
            messagebox.showinfo("Transfer Complete", "Stock transfer completed successfully.")
        except ValueError as error:
            messagebox.showerror("Transfer Error", str(error))
        except Exception:
            messagebox.showerror("Transfer Error", "The stock transfer could not be completed.")
