import tkinter as tk
from tkinter import messagebox, ttk

from services import customer_service, employee_service, location_service, product_service, sale_service
from ui.sales.receipt_frame import ReceiptFrame


class SaleEntryFrame(ttk.Frame):
    def __init__(self, parent, navigate):
        super().__init__(parent)
        self.line_items = []
        self._build_layout()
        self.load_dropdowns()

    def _build_layout(self) -> None:
        ttk.Label(self, text="Sales Entry", font=("Arial", 16, "bold")).pack(anchor="w")
        form = ttk.Frame(self)
        form.pack(fill="x", pady=8)
        self.location_var = tk.StringVar()
        self.employee_var = tk.StringVar()
        self.customer_var = tk.StringVar()
        self.product_var = tk.StringVar()
        self.quantity_var = tk.StringVar()
        self.total_var = tk.StringVar(value="Total: $0.00")
        labels = ["Location", "Employee", "Customer", "Product", "Quantity"]
        vars_ = [self.location_var, self.employee_var, self.customer_var, self.product_var, self.quantity_var]
        self.combos = []
        for i, label in enumerate(labels):
            ttk.Label(form, text=label).grid(row=i, column=0, sticky="w", pady=2)
            if label == "Quantity":
                ttk.Entry(form, textvariable=vars_[i]).grid(row=i, column=1, sticky="ew")
            else:
                combo = ttk.Combobox(form, textvariable=vars_[i], state="readonly")
                combo.grid(row=i, column=1, sticky="ew")
                self.combos.append(combo)
        form.columnconfigure(1, weight=1)
        ttk.Button(form, text="Add Line Item", command=self.add_line_item).grid(row=5, column=0, pady=6)
        ttk.Button(form, text="Complete Sale", command=self.complete_sale).grid(row=5, column=1, pady=6)
        self.tree = ttk.Treeview(self, columns=("product", "qty", "price", "line_total"), show="headings", height=10)
        for col, text in [("product", "Product"), ("qty", "Qty"), ("price", "Price"), ("line_total", "Line Total")]:
            self.tree.heading(col, text=text, anchor="w")
            self.tree.column(col, anchor="w")
        self.tree.pack(fill="both", expand=True)
        ttk.Label(self, textvariable=self.total_var).pack(anchor="w", pady=8)

    def load_dropdowns(self) -> None:
        try:
            self.locations = location_service.get_all_locations()
            self.employees = employee_service.get_active_employees()
            self.customers = customer_service.get_active_customers()
            self.products = product_service.get_active_products()
            self.combos[0]["values"] = [f"{loc.location_id}: {loc.location_name}" for loc in self.locations]
            self.combos[1]["values"] = [f"{emp.employee_id}: {emp.employee_name}" for emp in self.employees]
            self.combos[2]["values"] = [f"{cust.customer_id}: {cust.customer_name}" for cust in self.customers]
            self.combos[3]["values"] = [f"{prod.product_id}: {prod.product_name}" for prod in self.products]
            walk_in = customer_service.get_walk_in_customer()
            self.customer_var.set(f"{walk_in.customer_id}: {walk_in.customer_name}")
        except Exception:
            messagebox.showerror("Sales Error", "Sales dropdowns could not be loaded. Please try again.")

    def _id_from_combo(self, value: str, field_name: str) -> int:
        if not value or ":" not in value:
            raise ValueError(f"Please select a {field_name}.")
        try:
            return int(value.split(":")[0])
        except ValueError:
            raise ValueError(f"Please select a valid {field_name}.") from None

    def add_line_item(self) -> None:
        try:
            product_id = self._id_from_combo(self.product_var.get(), "product")
            try:
                quantity = int(self.quantity_var.get().strip())
            except ValueError:
                raise ValueError("Please enter a valid whole number for quantity.") from None
            if quantity <= 0:
                raise ValueError("Quantity must be greater than zero.")
            product = next(prod for prod in self.products if prod.product_id == product_id)
            line_total = round(quantity * product.unit_price, 2)
            self.line_items.append({"product_id": product_id, "quantity": quantity})
            self.tree.insert("", "end", values=(product.product_name, quantity, f"${product.unit_price:.2f}", f"${line_total:.2f}"))
            total = sum(item["quantity"] * next(prod.unit_price for prod in self.products if prod.product_id == item["product_id"]) for item in self.line_items)
            self.total_var.set(f"Total: ${total:.2f}")
            self.quantity_var.set("")
        except ValueError as error:
            messagebox.showerror("Line Item Error", str(error))
        except Exception:
            messagebox.showerror("Line Item Error", "The line item could not be added. Please check the information and try again.")

    def complete_sale(self) -> None:
        try:
            sale = sale_service.complete_sale(
                self._id_from_combo(self.location_var.get(), "location"),
                self._id_from_combo(self.customer_var.get(), "customer"),
                self._id_from_combo(self.employee_var.get(), "employee"),
                self.line_items,
            )
            ReceiptFrame(self, sale)
            self.line_items.clear()
            for row in self.tree.get_children():
                self.tree.delete(row)
            self.total_var.set("Total: $0.00")
        except ValueError as error:
            messagebox.showerror("Sale Error", str(error))
        except Exception:
            messagebox.showerror("Sale Error", "The sale could not be completed. Please check the information and try again.")
