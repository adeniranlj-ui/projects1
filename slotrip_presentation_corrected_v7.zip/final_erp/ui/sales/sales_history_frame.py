import tkinter as tk
from tkinter import messagebox, ttk

from services import customer_service, employee_service, location_service, sale_service


class SalesHistoryFrame(ttk.Frame):
    def __init__(self, parent, navigate):
        super().__init__(parent)
        self.sales = []
        self.locations = []
        self.customers = []
        self.employees = []
        self._build_layout()
        self.load_filter_dropdowns()
        self.load_sales_history()

    def _build_layout(self) -> None:
        ttk.Label(self, text="Sales History", font=("Arial", 16, "bold")).pack(anchor="w")

        filters = ttk.LabelFrame(self, text="Filters", padding=8)
        filters.pack(fill="x", pady=8)

        self.date_from_var = tk.StringVar()
        self.date_to_var = tk.StringVar()
        self.location_var = tk.StringVar(value="All")
        self.customer_var = tk.StringVar(value="All")
        self.employee_var = tk.StringVar(value="All")

        ttk.Label(filters, text="Date From").grid(row=0, column=0, sticky="w", padx=3, pady=2)
        ttk.Entry(filters, textvariable=self.date_from_var, width=14).grid(row=0, column=1, sticky="w", padx=3, pady=2)
        ttk.Label(filters, text="Date To").grid(row=0, column=2, sticky="w", padx=3, pady=2)
        ttk.Entry(filters, textvariable=self.date_to_var, width=14).grid(row=0, column=3, sticky="w", padx=3, pady=2)

        ttk.Label(filters, text="Location").grid(row=1, column=0, sticky="w", padx=3, pady=2)
        self.location_combo = ttk.Combobox(filters, textvariable=self.location_var, state="readonly", width=24)
        self.location_combo.grid(row=1, column=1, sticky="w", padx=3, pady=2)

        ttk.Label(filters, text="Customer").grid(row=1, column=2, sticky="w", padx=3, pady=2)
        self.customer_combo = ttk.Combobox(filters, textvariable=self.customer_var, state="readonly", width=24)
        self.customer_combo.grid(row=1, column=3, sticky="w", padx=3, pady=2)

        ttk.Label(filters, text="Employee").grid(row=2, column=0, sticky="w", padx=3, pady=2)
        self.employee_combo = ttk.Combobox(filters, textvariable=self.employee_var, state="readonly", width=24)
        self.employee_combo.grid(row=2, column=1, sticky="w", padx=3, pady=2)

        ttk.Button(filters, text="Search", command=self.load_sales_history).grid(row=2, column=2, sticky="ew", padx=3, pady=2)
        ttk.Button(filters, text="Clear Filters", command=self.clear_filters).grid(row=2, column=3, sticky="ew", padx=3, pady=2)

        self.tree = ttk.Treeview(self, columns=("date", "location", "customer", "employee", "total"), show="headings")
        for col, text in [
            ("date", "Date"),
            ("location", "Location"),
            ("customer", "Customer"),
            ("employee", "Employee"),
            ("total", "Total"),
        ]:
            self.tree.heading(col, text=text, anchor="w")
            self.tree.column(col, anchor="w")
        self.tree.pack(fill="both", expand=True)

        self.details = ttk.Label(self, justify="left")
        self.details.pack(fill="x", pady=8)
        self.tree.bind("<<TreeviewSelect>>", self.show_details)

    def load_filter_dropdowns(self) -> None:
        try:
            self.locations = location_service.get_all_locations()
            self.customers = customer_service.get_all_customers()
            self.employees = employee_service.get_all_employees()

            self.location_combo["values"] = ["All"] + [
                f"{item.location_id}: {item.location_name}" for item in self.locations
            ]
            self.customer_combo["values"] = ["All", "Walk-In"] + [
                f"{item.customer_id}: {item.customer_name}" for item in self.customers
            ]
            self.employee_combo["values"] = ["All"] + [
                f"{item.employee_id}: {item.employee_name}" for item in self.employees
            ]
        except Exception as error:
            messagebox.showerror("Sales History Error", "Sales history could not be loaded. Please check the filters and try again.")

    def _id_from_combo(self, value: str) -> int | None:
        if not value or value in ("All", "Walk-In"):
            return None
        return int(value.split(":")[0])

    def _build_filters(self) -> dict:
        filters = {}
        if self.date_from_var.get().strip():
            filters["date_from"] = self.date_from_var.get().strip()
        if self.date_to_var.get().strip():
            filters["date_to"] = self.date_to_var.get().strip()

        location_id = self._id_from_combo(self.location_var.get())
        if location_id is not None:
            filters["location_id"] = location_id

        customer_value = self.customer_var.get()
        if customer_value == "Walk-In":
            filters["walk_in"] = True
        else:
            customer_id = self._id_from_combo(customer_value)
            if customer_id is not None:
                filters["customer_id"] = customer_id

        employee_id = self._id_from_combo(self.employee_var.get())
        if employee_id is not None:
            filters["employee_id"] = employee_id

        return filters

    def load_sales_history(self) -> None:
        try:
            self.sales = sale_service.get_sales_history(self._build_filters())
            for row in self.tree.get_children():
                self.tree.delete(row)
            for sale in self.sales:
                self.tree.insert(
                    "",
                    "end",
                    iid=str(sale.sale_id),
                    values=(
                        sale.sale_date,
                        sale.location_name,
                        sale.customer_name,
                        sale.employee_name,
                        f"${sale.grand_total:.2f}",
                    ),
                )
        except Exception as error:
            messagebox.showerror("Sales History Error", "Sales history could not be loaded. Please check the filters and try again.")

    def clear_filters(self) -> None:
        self.date_from_var.set("")
        self.date_to_var.set("")
        self.location_var.set("All")
        self.customer_var.set("All")
        self.employee_var.set("All")
        self.load_sales_history()

    def show_details(self, event=None) -> None:
        selection = self.tree.selection()
        if not selection:
            return
        try:
            sale = sale_service.get_sale_details(int(selection[0]))
            lines = [f"Sale #{sale.sale_id}"]
            for item in sale.line_items:
                lines.append(f"{item.product_name}: {item.quantity} × ${item.unit_price:.2f} = ${item.line_total:.2f}")
            self.details.config(text="\n".join(lines))
        except Exception as error:
            messagebox.showerror("Sale Detail Error", "Sale details could not be loaded. Please try again.")
