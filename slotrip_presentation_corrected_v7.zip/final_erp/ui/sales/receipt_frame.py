import tkinter as tk
from tkinter import ttk


class ReceiptFrame(tk.Toplevel):
    def __init__(self, parent, sale):
        super().__init__(parent)
        self.title("Receipt")
        self.geometry("420x420")
        self.sale = sale
        self._build_layout()

    def _build_layout(self) -> None:
        text = tk.Text(self, width=50, height=22)
        text.pack(fill="both", expand=True, padx=10, pady=10)
        text.insert("end", self._build_receipt_text())
        text.config(state="disabled")
        ttk.Button(self, text="Close", command=self.destroy).pack(pady=5)

    def _build_receipt_text(self) -> str:
        lines = [
            "SloTrip Business Manager",
            "=" * 30,
            f"Sale ID: {self.sale.sale_id}",
            f"Date: {self.sale.sale_date}",
            f"Location: {self.sale.location_name}",
            f"Employee: {self.sale.employee_name}",
            f"Customer: {self.sale.customer_name}",
            "-" * 30,
        ]
        for item in self.sale.line_items:
            lines.append(f"{item.product_name} x{item.quantity} @ ${item.unit_price:.2f} = ${item.line_total:.2f}")
        lines.append("-" * 30)
        if getattr(self.sale, "discount_amount", 0) and self.sale.discount_amount > 0:
            lines.append(f"Subtotal: ${self.sale.subtotal:.2f}")
            lines.append(f"Discount: -${self.sale.discount_amount:.2f}")
        lines.append(f"TOTAL: ${self.sale.grand_total:.2f}")
        return "\n".join(lines)
