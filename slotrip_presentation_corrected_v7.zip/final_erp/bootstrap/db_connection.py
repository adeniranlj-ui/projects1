import sqlite3
from contextlib import contextmanager
from pathlib import Path

DATABASE_PATH = Path(__file__).resolve().parents[1] / "slotrip_business_manager.db"
_active_connection = None


def get_connection() -> sqlite3.Connection:
    global _active_connection
    if _active_connection is not None:
        return _active_connection

    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON;")
    return connection


def commit(connection: sqlite3.Connection) -> None:
    if _active_connection is None:
        connection.commit()


def close(connection: sqlite3.Connection) -> None:
    if _active_connection is None:
        connection.close()


@contextmanager
def transaction():
    global _active_connection

    if _active_connection is not None:
        yield _active_connection
        return

    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON;")
    _active_connection = connection

    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        _active_connection = None
        connection.close()
