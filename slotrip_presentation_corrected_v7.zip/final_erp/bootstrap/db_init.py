import hashlib
import sqlite3
from pathlib import Path

from . import db_connection


def _column_exists(cursor, table_name: str, column_name: str) -> bool:
    columns = cursor.execute(f"PRAGMA table_info({table_name});").fetchall()
    return any(column[1] == column_name for column in columns)


def _add_column_if_missing(cursor, table_name: str, column_name: str, definition: str) -> None:
    if not _column_exists(cursor, table_name, column_name):
        cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition};")


def _ensure_active_column(cursor, table_name: str) -> None:
    had_active_column = _column_exists(cursor, table_name, "active")
    _add_column_if_missing(cursor, table_name, "active", "INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1))")
    legacy_column = "is" + "_" + "active"
    if not had_active_column and _column_exists(cursor, table_name, legacy_column):
        cursor.execute(f"UPDATE {table_name} SET active = {legacy_column};")


def _run_safe_migrations(cursor) -> None:
    for table_name in ("employees", "suppliers", "customers", "products"):
        _ensure_active_column(cursor, table_name)

    _add_column_if_missing(cursor, "employees", "hourly_wage", "REAL NOT NULL DEFAULT 15.00 CHECK (hourly_wage > 0)")

    _add_column_if_missing(cursor, "suppliers", "ban_reason", "TEXT")
    _add_column_if_missing(cursor, "suppliers", "banned_at", "TEXT")
    _add_column_if_missing(cursor, "suppliers", "reactivated_at", "TEXT")

    _add_column_if_missing(cursor, "purchase_orders", "sent_date", "TEXT")

    _add_column_if_missing(cursor, "ledger_entries", "source_type", "TEXT NOT NULL DEFAULT 'manual'")
    _add_column_if_missing(cursor, "ledger_entries", "source_record_id", "INTEGER")

    _add_column_if_missing(cursor, "customers", "reward_points", "INTEGER NOT NULL DEFAULT 0")
    _add_column_if_missing(cursor, "customers", "is_discount_eligible", "INTEGER NOT NULL DEFAULT 0 CHECK (is_discount_eligible IN (0, 1))")

    _add_column_if_missing(cursor, "sales", "subtotal", "REAL NOT NULL DEFAULT 0")
    _add_column_if_missing(cursor, "sales", "discount_amount", "REAL NOT NULL DEFAULT 0")
    _add_column_if_missing(cursor, "sales", "final_total", "REAL NOT NULL DEFAULT 0")

    # Correct older ledger rows from previous builds where received purchase orders
    # may have been posted as Income. A received PO is a business expense because
    # it represents money spent to buy inventory.
    cursor.execute(
        """
        UPDATE ledger_entries
        SET entry_type = 'Expense',
            source_type = 'purchase_order',
            source_record_id = COALESCE(source_record_id, related_po_id),
            description = CASE
                WHEN lower(description) LIKE '%income%'
                    THEN replace(description, 'Income', 'Expense')
                WHEN description IS NULL OR trim(description) = ''
                    THEN 'Expense from purchase order'
                ELSE description
            END
        WHERE related_po_id IS NOT NULL
           OR lower(source_type) IN ('purchase_order', 'purchase order', 'po')
           OR lower(description) LIKE '%purchase order%'
           OR lower(description) LIKE '%po #%';
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS shifts (
            shift_id INTEGER PRIMARY KEY,
            employee_id INTEGER NOT NULL,
            location_id INTEGER NOT NULL,
            shift_date TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT,
            source TEXT NOT NULL DEFAULT 'manual',
            UNIQUE (employee_id, shift_date, source),
            FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
            FOREIGN KEY (location_id) REFERENCES locations(location_id)
        );
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS simulation_runs (
            simulation_run_id INTEGER PRIMARY KEY,
            simulation_date TEXT NOT NULL UNIQUE,
            created_at TEXT NOT NULL,
            sales_posted INTEGER NOT NULL DEFAULT 0,
            purchase_orders_created INTEGER NOT NULL DEFAULT 0,
            shifts_logged INTEGER NOT NULL DEFAULT 0
        );
        """
    )


def _seed_base_data(cursor, password_hash: str) -> None:
    cursor.executemany(
        "INSERT OR IGNORE INTO locations (location_id, location_name) VALUES (?, ?);",
        [(1, "SnailPace"), (2, "LazyTrek")],
    )
    cursor.execute("UPDATE locations SET location_name = 'SnailPace' WHERE location_id = 1;")
    cursor.execute("UPDATE locations SET location_name = 'LazyTrek' WHERE location_id = 2;")

    cursor.executemany(
        """
        INSERT OR IGNORE INTO suppliers (supplier_id, supplier_name, category, active)
        VALUES (?, ?, ?, ?);
        """,
        [
            (1, "Red Bull", "Energy Drink", 1),
            (2, "Monster Energy", "Energy Drink", 1),
            (3, "FritoLays", "Chips", 1),
            (4, "A&W Restaurants", "Soda", 1),
            (5, "Ozarka", "Water", 1),
        ],
    )

    cursor.executemany(
        """
        INSERT OR IGNORE INTO employees (
            employee_id, employee_name, username, password_hash, role, location_id, hourly_wage, active
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """,
        [
            (1, "Marcus Webb", "marcus.webb", password_hash, "Admin", 1, 25.00, 1),
            (2, "Dani Ortega", "dani.ortega", password_hash, "Staff", 1, 16.50, 1),
            (3, "Keisha Ford", "keisha.ford", password_hash, "Staff", 1, 16.75, 1),
            (4, "Troy Baines", "troy.baines", password_hash, "Staff", 2, 16.25, 1),
            (5, "Priya Nair", "priya.nair", password_hash, "Staff", 2, 17.00, 1),
        ],
    )

    cursor.executemany(
        "INSERT OR IGNORE INTO customers (customer_id, customer_name, active) VALUES (?, ?, ?);",
        [
            (1, "Alex Rivera", 1),
            (2, "Jamie Chen", 1),
            (3, "Sam Okafor", 1),
        ],
    )
    cursor.executemany(
        "INSERT OR IGNORE INTO customers (customer_name, active) VALUES (?, 1);",
        [
            ("Taylor Brooks",),
            ("Morgan Ellis",),
            ("Jordan Price",),
            ("Casey Bennett",),
            ("Riley Hughes",),
            ("Avery Collins",),
            ("Cameron Reed",),
            ("Nina Patel",),
            ("Owen Martinez",),
            ("Maya Johnson",),
            ("Ethan Walker",),
            ("Sofia Ramirez",),
            ("Logan Carter",),
            ("Grace Kim",),
            ("Daniel Harris",),
            ("Brianna Lee",),
            ("Noah Thompson",),
            ("Walk-In",),
        ],
    )
    cursor.execute("UPDATE customers SET active = 1 WHERE customer_name = 'Walk-In';")
    walk_in_row = cursor.execute("SELECT customer_id FROM customers WHERE customer_name = 'Walk-In';").fetchone()
    if walk_in_row is not None:
        cursor.execute("UPDATE sales SET customer_id = ? WHERE customer_id IS NULL;", (walk_in_row[0],))

    cursor.executemany(
        """
        INSERT OR IGNORE INTO products (
            product_id, product_name, sku, category, unit_cost, unit_price,
            reorder_point, default_supplier_id, active
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
        """,
        [
            (1, "Red Bull Coconut", "RB-COCO-001", "Energy Drink", 1.80, 3.49, 15, 1, 1),
            (2, "Monster Java Juice", "MN-JAVA-001", "Energy Drink", 1.90, 3.79, 15, 2, 1),
            (3, "Lays", "FL-LAYS-001", "Chips", 0.75, 1.99, 15, 3, 1),
            (4, "Root Beer", "AW-ROOT-001", "Soda", 0.60, 1.49, 15, 4, 1),
            (5, "Water", "OZ-WATR-001", "Water", 0.35, 1.29, 15, 5, 1),
        ],
    )

    cursor.executemany(
        """
        INSERT OR IGNORE INTO inventory (inventory_id, product_id, location_id, quantity)
        VALUES (?, ?, ?, ?);
        """,
        [
            (1, 1, 1, 50), (2, 2, 1, 50), (3, 3, 1, 50), (4, 4, 1, 50), (5, 5, 1, 50),
            (6, 1, 2, 50), (7, 2, 2, 50), (8, 3, 2, 50), (9, 4, 2, 50), (10, 5, 2, 50),
        ],
    )


def init_database() -> None:
    connection = None

    try:
        connection = db_connection.get_connection()
        cursor = connection.cursor()

        schema_path = Path(__file__).resolve().parents[1] / "schema.sql"
        cursor.executescript(schema_path.read_text(encoding="utf-8"))
        _run_safe_migrations(cursor)

        password_hash = hashlib.sha256("changeme123".encode("utf-8")).hexdigest()
        _seed_base_data(cursor, password_hash)

        connection.commit()

    except sqlite3.Error:
        if connection is not None:
            connection.rollback()
        raise Exception("Database initialization failed.") from None
    except OSError:
        if connection is not None:
            connection.rollback()
        raise Exception("Database initialization failed.") from None
    finally:
        if connection is not None:
            connection.close()
