current_user = None


def set_current_user(user: dict) -> None:
    global current_user
    current_user = user


def get_current_user() -> dict | None:
    return current_user


def clear_current_user() -> None:
    global current_user
    current_user = None


def is_admin() -> bool:
    return bool(current_user and current_user.get("role") == "Admin")
