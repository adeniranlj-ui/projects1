import sqlite3

from bootstrap import db_connection
from models.payroll import PayrollEntry, PayrollRun


def _row_to_run(row) -> PayrollRun:
    return PayrollRun(
        run_id=row["run_id"],
        period_start=row["period_start"],
        period_end=row["period_end"],
        run_date=row["run_date"],
        total_amount=row["total_amount"],
        status=row["status"],
        created_by=row["created_by"],
        created_by_name=row["created_by_name"] if "created_by_name" in row.keys() else "",
        entries=[],
    )


def _row_to_entry(row) -> PayrollEntry:
    return PayrollEntry(
        entry_id=row["entry_id"],
        run_id=row["run_id"],
        employee_id=row["employee_id"],
        employee_name=row["employee_name"],
        location_id=row["location_id"],
        location_name=row["location_name"],
        hours_worked=row["hours_worked"],
        hourly_rate=row["hourly_rate"],
        gross_pay=row["gross_pay"],
    )


def get_all_runs() -> list[PayrollRun]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT pr.*, e.employee_name AS created_by_name
            FROM payroll_runs pr
            JOIN employees e ON pr.created_by = e.employee_id
            ORDER BY pr.run_date DESC, pr.run_id DESC;
            """
        ).fetchall()
        return [_row_to_run(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get payroll runs.") from error
    finally:
        db_connection.close(connection)


def get_run_by_id(run_id: int) -> PayrollRun | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT pr.*, e.employee_name AS created_by_name
            FROM payroll_runs pr
            JOIN employees e ON pr.created_by = e.employee_id
            WHERE pr.run_id = ?;
            """,
            (run_id,),
        ).fetchone()
        if row is None:
            return None
        run = _row_to_run(row)
        run.entries = get_entries_for_run(run_id)
        return run
    except sqlite3.Error as error:
        raise Exception("Failed to get payroll run.") from error
    finally:
        db_connection.close(connection)


def get_entry_by_id(entry_id: int) -> PayrollEntry | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT pe.*, e.employee_name, l.location_name
            FROM payroll_entries pe
            JOIN employees e ON pe.employee_id = e.employee_id
            JOIN locations l ON pe.location_id = l.location_id
            WHERE pe.entry_id = ?;
            """,
            (entry_id,),
        ).fetchone()
        return _row_to_entry(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get payroll entry.") from error
    finally:
        db_connection.close(connection)


def get_entries_for_run(run_id: int) -> list[PayrollEntry]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT pe.*, e.employee_name, l.location_name
            FROM payroll_entries pe
            JOIN employees e ON pe.employee_id = e.employee_id
            JOIN locations l ON pe.location_id = l.location_id
            WHERE pe.run_id = ?
            ORDER BY e.employee_name ASC;
            """,
            (run_id,),
        ).fetchall()
        return [_row_to_entry(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get payroll entries.") from error
    finally:
        db_connection.close(connection)


def insert_run(run: PayrollRun) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO payroll_runs (period_start, period_end, run_date, total_amount, status, created_by)
            VALUES (?, ?, ?, ?, ?, ?);
            """,
            (run.period_start, run.period_end, run.run_date, run.total_amount, run.status, run.created_by),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.Error as error:
        raise Exception("Failed to insert payroll run.") from error
    finally:
        db_connection.close(connection)


def insert_entry(entry: PayrollEntry) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO payroll_entries (run_id, employee_id, location_id, hours_worked, hourly_rate)
            VALUES (?, ?, ?, ?, ?);
            """,
            (entry.run_id, entry.employee_id, entry.location_id, entry.hours_worked, entry.hourly_rate),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.Error as error:
        raise Exception("Failed to insert payroll entry.") from error
    finally:
        db_connection.close(connection)


def update_entry(entry: PayrollEntry) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            "UPDATE payroll_entries SET hours_worked = ?, hourly_rate = ? WHERE entry_id = ?;",
            (entry.hours_worked, entry.hourly_rate, entry.entry_id),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to update payroll entry.") from error
    finally:
        db_connection.close(connection)


def finalize_run(run_id: int, total_amount: float) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            "UPDATE payroll_runs SET status = 'Finalized', total_amount = ? WHERE run_id = ?;",
            (total_amount, run_id),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to finalize payroll run.") from error
    finally:
        db_connection.close(connection)


def delete_run(run_id: int) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute("DELETE FROM payroll_entries WHERE run_id = ?;", (run_id,))
        connection.execute("DELETE FROM payroll_runs WHERE run_id = ?;", (run_id,))
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to delete payroll run.") from error
    finally:
        db_connection.close(connection)


def overlapping_finalized_run_exists(period_start: str, period_end: str) -> bool:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT COUNT(*) AS cnt
            FROM payroll_runs
            WHERE status = 'Finalized'
              AND period_start <= ?
              AND period_end >= ?;
            """,
            (period_end, period_start),
        ).fetchone()
        return int(row["cnt"]) > 0
    except sqlite3.Error as error:
        raise Exception("Failed to check payroll overlap.") from error
    finally:
        db_connection.close(connection)
