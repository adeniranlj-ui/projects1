import sqlite3

from bootstrap import db_connection
from models.sale import Sale, SaleLineItem


def insert_sale(
    location_id: int,
    customer_id: int | None,
    employee_id: int,
    sale_date: str,
    subtotal: float = 0.0,
    discount_amount: float = 0.0,
    final_total: float = 0.0,
) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO sales (sale_date, location_id, employee_id, customer_id, subtotal, discount_amount, final_total)
            VALUES (?, ?, ?, ?, ?, ?, ?);
            """,
            (sale_date, location_id, employee_id, customer_id, subtotal, discount_amount, final_total),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.Error as error:
        raise Exception("Failed to insert sale.") from error
    finally:
        db_connection.close(connection)


def insert_sale_line_item(sale_id: int, product_id: int, quantity: int, unit_price: float) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO sale_line_items (sale_id, product_id, quantity, unit_price)
            VALUES (?, ?, ?, ?);
            """,
            (sale_id, product_id, quantity, unit_price),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.Error as error:
        raise Exception("Failed to insert sale line item.") from error
    finally:
        db_connection.close(connection)


def get_sales_history(filters: dict | None = None) -> list[Sale]:
    connection = db_connection.get_connection()
    try:
        where_clauses = []
        params = []

        if filters:
            if filters.get("date_from"):
                date_from = filters["date_from"]
                if isinstance(date_from, str) and len(date_from) == 10:
                    date_from = f"{date_from}T00:00:00"
                where_clauses.append("s.sale_date >= ?")
                params.append(date_from)
            if filters.get("date_to"):
                date_to = filters["date_to"]
                if isinstance(date_to, str) and len(date_to) == 10:
                    date_to = f"{date_to}T23:59:59"
                where_clauses.append("s.sale_date <= ?")
                params.append(date_to)
            if filters.get("location_id"):
                where_clauses.append("s.location_id = ?")
                params.append(filters["location_id"])
            if filters.get("walk_in"):
                where_clauses.append("(s.customer_id IS NULL OR c.customer_name = 'Walk-In')")
            elif filters.get("customer_id") is not None and filters.get("customer_id") != "":
                where_clauses.append("s.customer_id = ?")
                params.append(filters["customer_id"])
            if filters.get("employee_id"):
                where_clauses.append("s.employee_id = ?")
                params.append(filters["employee_id"])

        where_sql = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
        rows = connection.execute(
            f"""
            SELECT
                s.sale_id,
                s.sale_date,
                s.location_id,
                l.location_name,
                s.customer_id,
                COALESCE(c.customer_name, 'Walk-In') AS customer_name,
                s.employee_id,
                e.employee_name,
                COALESCE(SUM(sli.quantity * sli.unit_price), 0) AS grand_total
            FROM sales s
            JOIN locations l ON s.location_id = l.location_id
            JOIN employees e ON s.employee_id = e.employee_id
            LEFT JOIN customers c ON s.customer_id = c.customer_id
            LEFT JOIN sale_line_items sli ON s.sale_id = sli.sale_id
            {where_sql}
            GROUP BY s.sale_id, s.sale_date, s.location_id, l.location_name,
                     s.customer_id, c.customer_name, s.employee_id, e.employee_name
            ORDER BY s.sale_date DESC, s.sale_id DESC;
            """,
            params,
        ).fetchall()

        return [
            Sale(
                sale_id=row["sale_id"],
                sale_date=row["sale_date"],
                location_id=row["location_id"],
                location_name=row["location_name"],
                customer_id=row["customer_id"],
                customer_name=row["customer_name"],
                employee_id=row["employee_id"],
                employee_name=row["employee_name"],
                grand_total=row["grand_total"],
                line_items=[],
            )
            for row in rows
        ]
    except sqlite3.Error as error:
        raise Exception("Failed to get sales history.") from error
    finally:
        db_connection.close(connection)


def get_sale_by_id(sale_id: int) -> Sale | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT
                s.sale_id,
                s.sale_date,
                s.location_id,
                l.location_name,
                s.customer_id,
                COALESCE(c.customer_name, 'Walk-In') AS customer_name,
                s.employee_id,
                e.employee_name,
                COALESCE(SUM(sli.quantity * sli.unit_price), 0) AS grand_total
            FROM sales s
            JOIN locations l ON s.location_id = l.location_id
            JOIN employees e ON s.employee_id = e.employee_id
            LEFT JOIN customers c ON s.customer_id = c.customer_id
            LEFT JOIN sale_line_items sli ON s.sale_id = sli.sale_id
            WHERE s.sale_id = ?
            GROUP BY s.sale_id, s.sale_date, s.location_id, l.location_name,
                     s.customer_id, c.customer_name, s.employee_id, e.employee_name;
            """,
            (sale_id,),
        ).fetchone()
        if row is None:
            return None
        return Sale(
            sale_id=row["sale_id"],
            sale_date=row["sale_date"],
            location_id=row["location_id"],
            location_name=row["location_name"],
            customer_id=row["customer_id"],
            customer_name=row["customer_name"],
            employee_id=row["employee_id"],
            employee_name=row["employee_name"],
            grand_total=row["grand_total"],
            line_items=[],
        )
    except sqlite3.Error as error:
        raise Exception("Failed to get sale.") from error
    finally:
        db_connection.close(connection)


def get_sale_line_items(sale_id: int) -> list[SaleLineItem]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT
                sli.sale_line_item_id,
                sli.sale_id,
                sli.product_id,
                p.product_name,
                sli.quantity,
                sli.unit_price,
                sli.quantity * sli.unit_price AS line_total
            FROM sale_line_items sli
            JOIN products p ON sli.product_id = p.product_id
            WHERE sli.sale_id = ?
            ORDER BY sli.sale_line_item_id ASC;
            """,
            (sale_id,),
        ).fetchall()
        return [
            SaleLineItem(
                sale_line_item_id=row["sale_line_item_id"],
                sale_id=row["sale_id"],
                product_id=row["product_id"],
                product_name=row["product_name"],
                quantity=row["quantity"],
                unit_price=row["unit_price"],
                line_total=row["line_total"],
            )
            for row in rows
        ]
    except sqlite3.Error as error:
        raise Exception("Failed to get sale line items.") from error
    finally:
        db_connection.close(connection)
