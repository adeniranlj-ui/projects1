import sqlite3

from bootstrap import db_connection
from models.ledger import LedgerEntry


def _row_to_ledger_entry(row) -> LedgerEntry:
    return LedgerEntry(
        ledger_entry_id=row["ledger_entry_id"],
        entry_date=row["entry_date"],
        entry_type=row["entry_type"],
        source_type=row["source_type"],
        source_record_id=row["source_record_id"],
        amount=row["amount"],
        description=row["description"],
        related_sale_id=row["related_sale_id"],
        related_po_id=row["related_po_id"],
        running_balance=0.0,
    )


def insert_ledger_entry(entry_data: dict) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO ledger_entries (
                entry_date, entry_type, source_type, source_record_id, amount,
                description, related_sale_id, related_po_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?);
            """,
            (
                entry_data["entry_date"],
                entry_data["entry_type"],
                entry_data.get("source_type", "manual"),
                entry_data.get("source_record_id"),
                entry_data["amount"],
                entry_data["description"],
                entry_data.get("related_sale_id"),
                entry_data.get("related_po_id"),
            ),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.Error as error:
        raise Exception("Failed to insert ledger entry.") from error
    finally:
        db_connection.close(connection)


def get_ledger_entries(filters: dict | None = None) -> list[LedgerEntry]:
    connection = db_connection.get_connection()
    try:
        where_parts = []
        params = []
        if filters:
            if filters.get("entry_date"):
                where_parts.append("entry_date LIKE ?")
                params.append(f"{filters['entry_date']}%")
            if filters.get("entry_type") and filters.get("entry_type") != "All":
                where_parts.append("entry_type = ?")
                params.append(filters["entry_type"])
            if filters.get("source_type") and filters.get("source_type") != "All":
                where_parts.append("source_type = ?")
                params.append(filters["source_type"])
        where_sql = "WHERE " + " AND ".join(where_parts) if where_parts else ""
        rows = connection.execute(
            f"""
            SELECT ledger_entry_id, entry_date, entry_type, source_type, source_record_id,
                   amount, description, related_sale_id, related_po_id
            FROM ledger_entries
            {where_sql}
            ORDER BY entry_date ASC, ledger_entry_id ASC;
            """,
            params,
        ).fetchall()
        return [_row_to_ledger_entry(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get ledger entries.") from error
    finally:
        db_connection.close(connection)


def get_ledger_entry_by_id(ledger_entry_id: int) -> LedgerEntry | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT ledger_entry_id, entry_date, entry_type, source_type, source_record_id,
                   amount, description, related_sale_id, related_po_id
            FROM ledger_entries
            WHERE ledger_entry_id = ?;
            """,
            (ledger_entry_id,),
        ).fetchone()
        return _row_to_ledger_entry(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get ledger entry.") from error
    finally:
        db_connection.close(connection)
