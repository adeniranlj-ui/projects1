from bootstrap import db_connection


def transaction():
    return db_connection.transaction()
