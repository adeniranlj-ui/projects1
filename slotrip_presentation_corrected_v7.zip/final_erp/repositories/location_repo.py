import sqlite3

from bootstrap import db_connection
from models.location import Location


def _row_to_location(row) -> Location:
    return Location(location_id=row["location_id"], location_name=row["location_name"])


def get_all_locations() -> list[Location]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            "SELECT location_id, location_name FROM locations ORDER BY location_id ASC;"
        ).fetchall()
        return [_row_to_location(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get locations.") from error
    finally:
        db_connection.close(connection)


def get_location_by_id(location_id: int) -> Location | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            "SELECT location_id, location_name FROM locations WHERE location_id = ?;",
            (location_id,),
        ).fetchone()
        return _row_to_location(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get location.") from error
    finally:
        db_connection.close(connection)


def get_location_by_name(location_name: str) -> Location | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            "SELECT location_id, location_name FROM locations WHERE location_name = ?;",
            (location_name,),
        ).fetchone()
        return _row_to_location(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get location.") from error
    finally:
        db_connection.close(connection)
