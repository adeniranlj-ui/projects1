import sqlite3

from bootstrap import db_connection
from models.purchase_order import POLineItem, PurchaseOrder


def _row_to_po(row) -> PurchaseOrder:
    return PurchaseOrder(
        po_id=row["po_id"],
        supplier_id=row["supplier_id"],
        supplier_name=row["supplier_name"],
        location_id=row["location_id"],
        location_name=row["location_name"],
        status=row["status"],
        created_date=row["created_date"],
        sent_date=row["sent_date"] if "sent_date" in row.keys() else None,
        received_date=row["received_date"],
        po_total=row["po_total"] if "po_total" in row.keys() else 0.0,
        line_items=[],
    )


def insert_purchase_order(po_data: dict) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO purchase_orders (
                supplier_id, location_id, status, created_date, sent_date, received_date
            )
            VALUES (?, ?, ?, ?, ?, ?);
            """,
            (
                po_data["supplier_id"],
                po_data["location_id"],
                po_data["status"],
                po_data["created_date"],
                po_data.get("sent_date"),
                po_data.get("received_date"),
            ),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.Error as error:
        raise Exception("Failed to insert purchase order.") from error
    finally:
        db_connection.close(connection)


def insert_po_line_item(line_item_data: dict) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO po_line_items (po_id, product_id, quantity, unit_cost)
            VALUES (?, ?, ?, ?);
            """,
            (
                line_item_data["po_id"],
                line_item_data["product_id"],
                line_item_data["quantity"],
                line_item_data["unit_cost"],
            ),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.Error as error:
        raise Exception("Failed to insert purchase order line item.") from error
    finally:
        db_connection.close(connection)


def get_purchase_orders(filters: dict | None = None) -> list[PurchaseOrder]:
    connection = db_connection.get_connection()
    try:
        where_parts = []
        params = []
        if filters:
            if filters.get("status"):
                where_parts.append("po.status = ?")
                params.append(filters["status"])
            if filters.get("location_id"):
                where_parts.append("po.location_id = ?")
                params.append(filters["location_id"])
        where_sql = "WHERE " + " AND ".join(where_parts) if where_parts else ""
        rows = connection.execute(
            f"""
            SELECT po.*, s.supplier_name, l.location_name,
                   COALESCE(SUM(poli.quantity * poli.unit_cost), 0) AS po_total
            FROM purchase_orders po
            JOIN suppliers s ON po.supplier_id = s.supplier_id
            JOIN locations l ON po.location_id = l.location_id
            LEFT JOIN po_line_items poli ON po.po_id = poli.po_id
            {where_sql}
            GROUP BY po.po_id
            ORDER BY po.created_date DESC, po.po_id DESC;
            """,
            params,
        ).fetchall()
        return [_row_to_po(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get purchase orders.") from error
    finally:
        db_connection.close(connection)


def get_purchase_order_by_id(po_id: int) -> PurchaseOrder | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT po.*, s.supplier_name, l.location_name,
                   COALESCE(SUM(poli.quantity * poli.unit_cost), 0) AS po_total
            FROM purchase_orders po
            JOIN suppliers s ON po.supplier_id = s.supplier_id
            JOIN locations l ON po.location_id = l.location_id
            LEFT JOIN po_line_items poli ON po.po_id = poli.po_id
            WHERE po.po_id = ?
            GROUP BY po.po_id;
            """,
            (po_id,),
        ).fetchone()
        return _row_to_po(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get purchase order.") from error
    finally:
        db_connection.close(connection)


def get_po_line_items(po_id: int) -> list[POLineItem]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT poli.po_line_item_id, poli.po_id, poli.product_id, p.product_name,
                   poli.quantity, poli.unit_cost,
                   poli.quantity * poli.unit_cost AS line_total
            FROM po_line_items poli
            JOIN products p ON poli.product_id = p.product_id
            WHERE poli.po_id = ?
            ORDER BY poli.po_line_item_id ASC;
            """,
            (po_id,),
        ).fetchall()
        return [
            POLineItem(
                po_line_item_id=row["po_line_item_id"],
                po_id=row["po_id"],
                product_id=row["product_id"],
                product_name=row["product_name"],
                quantity=row["quantity"],
                unit_cost=row["unit_cost"],
                line_total=row["line_total"],
            )
            for row in rows
        ]
    except sqlite3.Error as error:
        raise Exception("Failed to get purchase order line items.") from error
    finally:
        db_connection.close(connection)


def update_purchase_order_status(
    po_id: int,
    status: str,
    sent_date: str | None = None,
    received_date: str | None = None,
) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            """
            UPDATE purchase_orders
            SET status = ?,
                sent_date = COALESCE(?, sent_date),
                received_date = ?
            WHERE po_id = ?;
            """,
            (status, sent_date, received_date, po_id),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to update purchase order status.") from error
    finally:
        db_connection.close(connection)


def mark_purchase_order_sent(po_id: int, sent_date: str) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            "UPDATE purchase_orders SET status = 'Sent', sent_date = ? WHERE po_id = ?;",
            (sent_date, po_id),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to mark purchase order as sent.") from error
    finally:
        db_connection.close(connection)


def mark_purchase_order_sent_date_only(po_id: int, sent_date: str) -> None:
    """Fallback for older databases whose status CHECK does not yet allow Sent."""
    connection = db_connection.get_connection()
    try:
        connection.execute(
            "UPDATE purchase_orders SET sent_date = ? WHERE po_id = ?;",
            (sent_date, po_id),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to record purchase order sent date.") from error
    finally:
        db_connection.close(connection)


def find_drafted_po_for_product_location(product_id: int, location_id: int) -> PurchaseOrder | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT po.*, s.supplier_name, l.location_name, 0 AS po_total
            FROM purchase_orders po
            JOIN po_line_items poli ON po.po_id = poli.po_id
            JOIN suppliers s ON po.supplier_id = s.supplier_id
            JOIN locations l ON po.location_id = l.location_id
            WHERE po.status IN ('Drafted', 'Sent')
              AND po.location_id = ?
              AND poli.product_id = ?
            LIMIT 1;
            """,
            (location_id, product_id),
        ).fetchone()
        return _row_to_po(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to find drafted purchase order.") from error
    finally:
        db_connection.close(connection)
