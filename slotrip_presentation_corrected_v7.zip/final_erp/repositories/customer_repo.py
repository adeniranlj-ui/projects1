import sqlite3

from bootstrap import db_connection
from models.customer import Customer, CustomerSalesSummary

WALK_IN_CUSTOMER_NAME = "Walk-In"


def _row_to_customer(row) -> Customer:
    return Customer(
        customer_id=row["customer_id"],
        customer_name=row["customer_name"],
        reward_points=row["reward_points"] if "reward_points" in row.keys() else 0,
        is_discount_eligible=row["is_discount_eligible"] if "is_discount_eligible" in row.keys() else 0,
        active=row["active"],
    )


def get_all_customers() -> list[Customer]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            "SELECT customer_id, customer_name, reward_points, is_discount_eligible, active FROM customers ORDER BY customer_name ASC;"
        ).fetchall()
        return [_row_to_customer(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get customers.") from error
    finally:
        db_connection.close(connection)


def get_active_customers() -> list[Customer]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            "SELECT customer_id, customer_name, reward_points, is_discount_eligible, active FROM customers WHERE active = 1 ORDER BY customer_name ASC;"
        ).fetchall()
        return [_row_to_customer(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get active customers.") from error
    finally:
        db_connection.close(connection)


def get_customer_by_id(customer_id: int) -> Customer | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            "SELECT customer_id, customer_name, reward_points, is_discount_eligible, active FROM customers WHERE customer_id = ?;",
            (customer_id,),
        ).fetchone()
        return _row_to_customer(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get customer.") from error
    finally:
        db_connection.close(connection)


def get_customer_by_name(customer_name: str) -> Customer | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            "SELECT customer_id, customer_name, reward_points, is_discount_eligible, active FROM customers WHERE customer_name = ?;",
            (customer_name,),
        ).fetchone()
        return _row_to_customer(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get customer.") from error
    finally:
        db_connection.close(connection)


def get_walk_in_customer() -> Customer | None:
    return get_customer_by_name(WALK_IN_CUSTOMER_NAME)


def insert_customer(customer: Customer) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            "INSERT INTO customers (customer_name, reward_points, is_discount_eligible, active) VALUES (?, ?, ?, ?);",
            (customer.customer_name, customer.reward_points, customer.is_discount_eligible, customer.active),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.IntegrityError as error:
        raise ValueError("That customer already exists. Please check the name and try again.") from error
    except sqlite3.Error as error:
        raise Exception("Failed to insert customer.") from error
    finally:
        db_connection.close(connection)


def update_customer(customer: Customer) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            "UPDATE customers SET customer_name = ?, reward_points = ?, is_discount_eligible = ?, active = ? WHERE customer_id = ?;",
            (customer.customer_name, customer.reward_points, customer.is_discount_eligible, customer.active, customer.customer_id),
        )
        db_connection.commit(connection)
    except sqlite3.IntegrityError as error:
        raise ValueError("That customer already exists. Please check the name and try again.") from error
    except sqlite3.Error as error:
        raise Exception("Failed to update customer.") from error
    finally:
        db_connection.close(connection)


def set_customer_active(customer_id: int, active: int) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute("UPDATE customers SET active = ? WHERE customer_id = ?;", (active, customer_id))
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to update customer status.") from error
    finally:
        db_connection.close(connection)


def add_reward_point(customer_id: int) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            "UPDATE customers SET reward_points = reward_points + 1 WHERE customer_id = ?;",
            (customer_id,),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to add reward point.") from error
    finally:
        db_connection.close(connection)


def get_customer_sales_summary(repeat_only: bool = False) -> list[CustomerSalesSummary]:
    connection = db_connection.get_connection()
    try:
        having_sql = "HAVING COUNT(DISTINCT s.sale_id) >= 2" if repeat_only else ""
        rows = connection.execute(
            f"""
            SELECT
                c.customer_id,
                c.customer_name,
                COUNT(DISTINCT s.sale_id) AS sales_count,
                COALESCE(SUM(sli.quantity * sli.unit_price), 0) AS total_sales,
                MAX(s.sale_date) AS most_recent_sale_date
            FROM customers c
            LEFT JOIN sales s ON c.customer_id = s.customer_id
            LEFT JOIN sale_line_items sli ON s.sale_id = sli.sale_id
            WHERE c.customer_name <> ?
            GROUP BY c.customer_id, c.customer_name
            {having_sql}
            ORDER BY total_sales DESC, c.customer_name ASC;
            """,
            (WALK_IN_CUSTOMER_NAME,),
        ).fetchall()
        return [
            CustomerSalesSummary(
                customer_id=row["customer_id"],
                customer_name=row["customer_name"],
                sales_count=int(row["sales_count"]),
                total_sales=round(float(row["total_sales"]), 2),
                most_recent_sale_date=row["most_recent_sale_date"],
            )
            for row in rows
        ]
    except sqlite3.Error as error:
        raise Exception("Failed to get customer sales summary.") from error
    finally:
        db_connection.close(connection)
