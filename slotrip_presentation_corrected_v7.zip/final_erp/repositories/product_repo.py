import sqlite3

from bootstrap import db_connection
from models.product import Product


def _row_to_product(row) -> Product:
    return Product(
        product_id=row["product_id"],
        product_name=row["product_name"],
        sku=row["sku"],
        category=row["category"],
        unit_cost=row["unit_cost"],
        unit_price=row["unit_price"],
        reorder_point=row["reorder_point"],
        default_supplier_id=row["default_supplier_id"],
        supplier_name=row["supplier_name"] if "supplier_name" in row.keys() else "",
        active=row["active"],
    )


def get_all_products() -> list[Product]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT p.*, s.supplier_name
            FROM products p
            JOIN suppliers s ON p.default_supplier_id = s.supplier_id
            ORDER BY p.product_name ASC;
            """
        ).fetchall()
        return [_row_to_product(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get products.") from error
    finally:
        db_connection.close(connection)


def get_active_products() -> list[Product]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT p.*, s.supplier_name
            FROM products p
            JOIN suppliers s ON p.default_supplier_id = s.supplier_id
            WHERE p.active = 1
            ORDER BY p.product_name ASC;
            """
        ).fetchall()
        return [_row_to_product(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get active products.") from error
    finally:
        db_connection.close(connection)


def get_product_by_id(product_id: int) -> Product | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT p.*, s.supplier_name
            FROM products p
            JOIN suppliers s ON p.default_supplier_id = s.supplier_id
            WHERE p.product_id = ?;
            """,
            (product_id,),
        ).fetchone()
        return _row_to_product(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get product.") from error
    finally:
        db_connection.close(connection)


def get_product_by_sku(sku: str) -> Product | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT p.*, s.supplier_name
            FROM products p
            JOIN suppliers s ON p.default_supplier_id = s.supplier_id
            WHERE p.sku = ?;
            """,
            (sku,),
        ).fetchone()
        return _row_to_product(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get product by SKU.") from error
    finally:
        db_connection.close(connection)


def insert_product(product: Product) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO products (
                product_name, sku, category, unit_cost, unit_price,
                reorder_point, default_supplier_id, active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?);
            """,
            (
                product.product_name,
                product.sku,
                product.category,
                product.unit_cost,
                product.unit_price,
                product.reorder_point,
                product.default_supplier_id,
                product.active,
            ),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.IntegrityError as error:
        raise ValueError("That SKU already exists. Please use a different SKU.") from error
    except sqlite3.Error as error:
        raise Exception("Failed to insert product.") from error
    finally:
        db_connection.close(connection)


def insert_inventory_row(product_id: int, location_id: int) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            """
            INSERT OR IGNORE INTO inventory (product_id, location_id, quantity)
            VALUES (?, ?, 0);
            """,
            (product_id, location_id),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to insert inventory row.") from error
    finally:
        db_connection.close(connection)


def update_product(product: Product) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            """
            UPDATE products
            SET product_name = ?, category = ?, unit_price = ?, reorder_point = ?
            WHERE product_id = ?;
            """,
            (
                product.product_name,
                product.category,
                product.unit_price,
                product.reorder_point,
                product.product_id,
            ),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to update product.") from error
    finally:
        db_connection.close(connection)


def set_product_active(product_id: int, active: int) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            "UPDATE products SET active = ? WHERE product_id = ?;",
            (active, product_id),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to update product active status.") from error
    finally:
        db_connection.close(connection)
