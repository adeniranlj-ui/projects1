import sqlite3

from bootstrap import db_connection
from models.employee import Employee


def _row_to_employee(row) -> Employee:
    return Employee(
        employee_id=row["employee_id"],
        employee_name=row["employee_name"],
        username=row["username"],
        password_hash=row["password_hash"],
        role=row["role"],
        location_id=row["location_id"],
        location_name=row["location_name"] if "location_name" in row.keys() else "",
        hourly_wage=float(row["hourly_wage"]),
        active=row["active"],
    )


def get_all_employees() -> list[Employee]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT e.*, l.location_name
            FROM employees e
            JOIN locations l ON e.location_id = l.location_id
            ORDER BY e.employee_name ASC;
            """
        ).fetchall()
        return [_row_to_employee(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get employees.") from error
    finally:
        db_connection.close(connection)


def get_active_employees() -> list[Employee]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT e.*, l.location_name
            FROM employees e
            JOIN locations l ON e.location_id = l.location_id
            WHERE e.active = 1
            ORDER BY e.employee_name ASC;
            """
        ).fetchall()
        return [_row_to_employee(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get active employees.") from error
    finally:
        db_connection.close(connection)


def get_employee_by_id(employee_id: int) -> Employee | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT e.*, l.location_name
            FROM employees e
            JOIN locations l ON e.location_id = l.location_id
            WHERE e.employee_id = ?;
            """,
            (employee_id,),
        ).fetchone()
        return _row_to_employee(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get employee.") from error
    finally:
        db_connection.close(connection)


def get_employee_by_username(username: str) -> Employee | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT e.*, l.location_name
            FROM employees e
            JOIN locations l ON e.location_id = l.location_id
            WHERE e.username = ?;
            """,
            (username,),
        ).fetchone()
        return _row_to_employee(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get employee by username.") from error
    finally:
        db_connection.close(connection)


def count_active_admins() -> int:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            "SELECT COUNT(*) AS admin_count FROM employees WHERE role = 'Admin' AND active = 1;"
        ).fetchone()
        return int(row["admin_count"])
    except sqlite3.Error as error:
        raise Exception("Failed to count active admins.") from error
    finally:
        db_connection.close(connection)


def insert_employee(employee: Employee) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO employees (employee_name, username, password_hash, role, location_id, hourly_wage, active)
            VALUES (?, ?, ?, ?, ?, ?, ?);
            """,
            (
                employee.employee_name,
                employee.username,
                employee.password_hash,
                employee.role,
                employee.location_id,
                employee.hourly_wage,
                employee.active,
            ),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.IntegrityError as error:
        raise ValueError("That username already exists. Please choose another username.") from error
    except sqlite3.Error as error:
        raise Exception("Failed to insert employee.") from error
    finally:
        db_connection.close(connection)


def update_employee(employee: Employee) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            """
            UPDATE employees
            SET employee_name = ?, username = ?, password_hash = ?, role = ?, location_id = ?, hourly_wage = ?, active = ?
            WHERE employee_id = ?;
            """,
            (
                employee.employee_name,
                employee.username,
                employee.password_hash,
                employee.role,
                employee.location_id,
                employee.hourly_wage,
                employee.active,
                employee.employee_id,
            ),
        )
        db_connection.commit(connection)
    except sqlite3.IntegrityError as error:
        raise ValueError("That username already exists. Please choose another username.") from error
    except sqlite3.Error as error:
        raise Exception("Failed to update employee.") from error
    finally:
        db_connection.close(connection)


def deactivate_employee(employee_id: int) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute("UPDATE employees SET active = 0 WHERE employee_id = ?;", (employee_id,))
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to deactivate employee.") from error
    finally:
        db_connection.close(connection)
