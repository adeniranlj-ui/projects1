import sqlite3

from bootstrap import db_connection
from models.inventory import Inventory


def _row_to_inventory(row) -> Inventory:
    return Inventory(
        inventory_id=row["inventory_id"],
        product_id=row["product_id"],
        product_name=row["product_name"],
        location_id=row["location_id"],
        location_name=row["location_name"],
        quantity=row["quantity"],
        reorder_point=row["reorder_point"],
    )


def get_inventory(filters: dict | None = None) -> list[Inventory]:
    connection = db_connection.get_connection()
    try:
        where_parts = []
        params = []
        if filters:
            if filters.get("product_id") is not None:
                where_parts.append("i.product_id = ?")
                params.append(filters["product_id"])
            if filters.get("location_id") is not None:
                where_parts.append("i.location_id = ?")
                params.append(filters["location_id"])
        where_sql = "WHERE " + " AND ".join(where_parts) if where_parts else ""
        rows = connection.execute(
            f"""
            SELECT i.inventory_id, i.product_id, p.product_name, i.location_id,
                   l.location_name, i.quantity, p.reorder_point
            FROM inventory i
            JOIN products p ON i.product_id = p.product_id
            JOIN locations l ON i.location_id = l.location_id
            {where_sql}
            ORDER BY l.location_name ASC, p.product_name ASC;
            """,
            params,
        ).fetchall()
        return [_row_to_inventory(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get inventory.") from error
    finally:
        db_connection.close(connection)


def get_stock(product_id: int, location_id: int) -> int:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            "SELECT quantity FROM inventory WHERE product_id = ? AND location_id = ?;",
            (product_id, location_id),
        ).fetchone()
        if row is None:
            return 0
        return int(row["quantity"])
    except sqlite3.Error as error:
        raise Exception("Failed to get stock.") from error
    finally:
        db_connection.close(connection)


def increment_stock(product_id: int, location_id: int, quantity: int) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            """
            UPDATE inventory
            SET quantity = quantity + ?
            WHERE product_id = ? AND location_id = ?;
            """,
            (quantity, product_id, location_id),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to increment stock.") from error
    finally:
        db_connection.close(connection)


def decrement_stock(product_id: int, location_id: int, quantity: int) -> None:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            UPDATE inventory
            SET quantity = quantity - ?
            WHERE product_id = ? AND location_id = ? AND quantity >= ?;
            """,
            (quantity, product_id, location_id, quantity),
        )
        if cursor.rowcount == 0:
            raise sqlite3.IntegrityError("Stock would go below zero.")
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to decrement stock.") from error
    finally:
        db_connection.close(connection)


def get_low_stock_items() -> list[Inventory]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT i.inventory_id, i.product_id, p.product_name, i.location_id,
                   l.location_name, i.quantity, p.reorder_point
            FROM inventory i
            JOIN products p ON i.product_id = p.product_id
            JOIN locations l ON i.location_id = l.location_id
            WHERE i.quantity <= p.reorder_point
            ORDER BY l.location_name ASC, p.product_name ASC;
            """
        ).fetchall()
        return [_row_to_inventory(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get low stock items.") from error
    finally:
        db_connection.close(connection)


def insert_stock_transfer(transfer_date: str, from_location_id: int, to_location_id: int, product_id: int, quantity: int) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO stock_transfers (transfer_date, from_location_id, to_location_id, product_id, quantity)
            VALUES (?, ?, ?, ?, ?);
            """,
            (transfer_date, from_location_id, to_location_id, product_id, quantity),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.Error as error:
        raise Exception("Failed to insert stock transfer.") from error
    finally:
        db_connection.close(connection)
