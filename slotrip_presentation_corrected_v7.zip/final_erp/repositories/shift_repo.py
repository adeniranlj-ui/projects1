import sqlite3

from bootstrap import db_connection


def insert_shift(employee_id: int, location_id: int, shift_date: str, start_time: str, end_time: str | None, source: str) -> int | None:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT OR IGNORE INTO shifts (employee_id, location_id, shift_date, start_time, end_time, source)
            VALUES (?, ?, ?, ?, ?, ?);
            """,
            (employee_id, location_id, shift_date, start_time, end_time, source),
        )
        db_connection.commit(connection)
        if cursor.rowcount == 0:
            return None
        return int(cursor.lastrowid)
    except sqlite3.Error as error:
        raise Exception("Failed to insert shift.") from error
    finally:
        db_connection.close(connection)


def get_completed_shifts_for_period(period_start: str, period_end: str) -> list[dict]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT shift_id, employee_id, location_id, shift_date, start_time, end_time, source
            FROM shifts
            WHERE shift_date >= ?
              AND shift_date <= ?
              AND end_time IS NOT NULL
              AND TRIM(end_time) <> ''
            ORDER BY employee_id ASC, shift_date ASC, start_time ASC;
            """,
            (period_start, period_end),
        ).fetchall()
        return [dict(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get completed shifts for payroll.") from error
    finally:
        db_connection.close(connection)
