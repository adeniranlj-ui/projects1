import sqlite3

from bootstrap import db_connection
from models.supplier import Supplier


def _row_to_supplier(row) -> Supplier:
    return Supplier(
        supplier_id=row["supplier_id"],
        supplier_name=row["supplier_name"],
        category=row["category"],
        active=row["active"],
        ban_reason=row["ban_reason"] if "ban_reason" in row.keys() else None,
        banned_at=row["banned_at"] if "banned_at" in row.keys() else None,
        reactivated_at=row["reactivated_at"] if "reactivated_at" in row.keys() else None,
    )


def get_all_suppliers() -> list[Supplier]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT supplier_id, supplier_name, category, active, ban_reason, banned_at, reactivated_at
            FROM suppliers
            ORDER BY supplier_name ASC;
            """
        ).fetchall()
        return [_row_to_supplier(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get suppliers.") from error
    finally:
        db_connection.close(connection)


def get_active_suppliers() -> list[Supplier]:
    connection = db_connection.get_connection()
    try:
        rows = connection.execute(
            """
            SELECT supplier_id, supplier_name, category, active, ban_reason, banned_at, reactivated_at
            FROM suppliers
            WHERE active = 1
            ORDER BY supplier_name ASC;
            """
        ).fetchall()
        return [_row_to_supplier(row) for row in rows]
    except sqlite3.Error as error:
        raise Exception("Failed to get active suppliers.") from error
    finally:
        db_connection.close(connection)


def get_supplier_by_id(supplier_id: int) -> Supplier | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT supplier_id, supplier_name, category, active, ban_reason, banned_at, reactivated_at
            FROM suppliers
            WHERE supplier_id = ?;
            """,
            (supplier_id,),
        ).fetchone()
        return _row_to_supplier(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get supplier.") from error
    finally:
        db_connection.close(connection)


def get_default_supplier_for_product(product_id: int) -> Supplier | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            """
            SELECT s.supplier_id, s.supplier_name, s.category, s.active,
                   s.ban_reason, s.banned_at, s.reactivated_at
            FROM products p
            JOIN suppliers s ON p.default_supplier_id = s.supplier_id
            WHERE p.product_id = ?;
            """,
            (product_id,),
        ).fetchone()
        return _row_to_supplier(row) if row else None
    except sqlite3.Error as error:
        raise Exception("Failed to get default supplier.") from error
    finally:
        db_connection.close(connection)


def insert_supplier(supplier: Supplier) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            "INSERT INTO suppliers (supplier_name, category, active) VALUES (?, ?, ?);",
            (supplier.supplier_name, supplier.category, supplier.active),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.IntegrityError as error:
        raise ValueError("That supplier already exists. Please check the name and try again.") from error
    except sqlite3.Error as error:
        raise Exception("Failed to insert supplier.") from error
    finally:
        db_connection.close(connection)


def update_supplier(supplier: Supplier) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            "UPDATE suppliers SET supplier_name = ?, category = ? WHERE supplier_id = ?;",
            (supplier.supplier_name, supplier.category, supplier.supplier_id),
        )
        db_connection.commit(connection)
    except sqlite3.IntegrityError as error:
        raise ValueError("That supplier already exists. Please check the name and try again.") from error
    except sqlite3.Error as error:
        raise Exception("Failed to update supplier.") from error
    finally:
        db_connection.close(connection)


def ban_supplier(supplier_id: int, reason: str, banned_at: str) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            """
            UPDATE suppliers
            SET active = 0, ban_reason = ?, banned_at = ?, reactivated_at = NULL
            WHERE supplier_id = ?;
            """,
            (reason, banned_at, supplier_id),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to ban supplier.") from error
    finally:
        db_connection.close(connection)


def reactivate_supplier(supplier_id: int, reactivated_at: str) -> None:
    connection = db_connection.get_connection()
    try:
        connection.execute(
            "UPDATE suppliers SET active = 1, reactivated_at = ? WHERE supplier_id = ?;",
            (reactivated_at, supplier_id),
        )
        db_connection.commit(connection)
    except sqlite3.Error as error:
        raise Exception("Failed to reactivate supplier.") from error
    finally:
        db_connection.close(connection)
