import sqlite3

from bootstrap import db_connection


def simulation_date_exists(simulation_date: str) -> bool:
    connection = db_connection.get_connection()
    try:
        row = connection.execute(
            "SELECT COUNT(*) AS count_value FROM simulation_runs WHERE simulation_date = ?;",
            (simulation_date,),
        ).fetchone()
        return int(row["count_value"]) > 0
    except sqlite3.Error as error:
        raise Exception("Failed to check simulation date.") from error
    finally:
        db_connection.close(connection)


def get_latest_simulation_date() -> str | None:
    connection = db_connection.get_connection()
    try:
        row = connection.execute("SELECT MAX(simulation_date) AS latest_date FROM simulation_runs;").fetchone()
        return row["latest_date"] if row and row["latest_date"] else None
    except sqlite3.Error as error:
        raise Exception("Failed to get latest simulation date.") from error
    finally:
        db_connection.close(connection)


def insert_simulation_run(simulation_date: str, created_at: str, sales_posted: int, purchase_orders_created: int, shifts_logged: int) -> int:
    connection = db_connection.get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO simulation_runs (
                simulation_date, created_at, sales_posted, purchase_orders_created, shifts_logged
            ) VALUES (?, ?, ?, ?, ?);
            """,
            (simulation_date, created_at, sales_posted, purchase_orders_created, shifts_logged),
        )
        db_connection.commit(connection)
        return int(cursor.lastrowid)
    except sqlite3.IntegrityError as error:
        raise ValueError("That simulation date has already been run.") from error
    except sqlite3.Error as error:
        raise Exception("Failed to insert simulation run.") from error
    finally:
        db_connection.close(connection)
