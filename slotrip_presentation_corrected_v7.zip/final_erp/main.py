import tkinter as tk
from tkinter import messagebox

from bootstrap.db_init import init_database
from ui.app_window import AppWindow
from ui.logo_utils import apply_window_icon
from ui.theme import apply_theme


def launch_app() -> None:
    try:
        init_database()
    except Exception:
        messagebox.showerror(
            "Startup Error",
            "Database initialization failed. The application will now close.",
        )
        return None

    root = tk.Tk()
    root.title("SloTrip Business Manager")
    root.minsize(1180, 760)
    root.geometry("1280x820")
    apply_theme(root)
    apply_window_icon(root)

    app_window = AppWindow(root)
    root.protocol("WM_DELETE_WINDOW", app_window.on_closing)

    root.mainloop()


if __name__ == "__main__":
    launch_app()
