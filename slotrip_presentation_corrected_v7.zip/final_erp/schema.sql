PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS locations (
    location_id INTEGER PRIMARY KEY,
    location_name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS employees (
    employee_id INTEGER PRIMARY KEY,
    employee_name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('Admin', 'Staff')),
    location_id INTEGER NOT NULL,
    hourly_wage REAL NOT NULL DEFAULT 15.00 CHECK (hourly_wage > 0),
    active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
    FOREIGN KEY (location_id) REFERENCES locations(location_id)
);

CREATE TABLE IF NOT EXISTS suppliers (
    supplier_id INTEGER PRIMARY KEY,
    supplier_name TEXT NOT NULL UNIQUE,
    category TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
    ban_reason TEXT,
    banned_at TEXT,
    reactivated_at TEXT
);

CREATE TABLE IF NOT EXISTS customers (
    customer_id INTEGER PRIMARY KEY,
    customer_name TEXT NOT NULL UNIQUE,
    active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1))
);

CREATE TABLE IF NOT EXISTS products (
    product_id INTEGER PRIMARY KEY,
    product_name TEXT NOT NULL,
    sku TEXT NOT NULL UNIQUE,
    category TEXT NOT NULL,
    unit_cost REAL NOT NULL CHECK (unit_cost >= 0),
    unit_price REAL NOT NULL CHECK (unit_price >= 0),
    reorder_point INTEGER NOT NULL CHECK (reorder_point >= 0),
    default_supplier_id INTEGER NOT NULL,
    active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
    FOREIGN KEY (default_supplier_id) REFERENCES suppliers(supplier_id)
);

CREATE TABLE IF NOT EXISTS inventory (
    inventory_id INTEGER PRIMARY KEY,
    product_id INTEGER NOT NULL,
    location_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity >= 0),
    UNIQUE (product_id, location_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (location_id) REFERENCES locations(location_id)
);

CREATE TABLE IF NOT EXISTS stock_transfers (
    transfer_id INTEGER PRIMARY KEY,
    transfer_date TEXT NOT NULL,
    from_location_id INTEGER NOT NULL,
    to_location_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    FOREIGN KEY (from_location_id) REFERENCES locations(location_id),
    FOREIGN KEY (to_location_id) REFERENCES locations(location_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    CHECK (from_location_id <> to_location_id)
);

CREATE TABLE IF NOT EXISTS sales (
    sale_id INTEGER PRIMARY KEY,
    sale_date TEXT NOT NULL,
    location_id INTEGER NOT NULL,
    employee_id INTEGER NOT NULL,
    customer_id INTEGER,
    subtotal REAL NOT NULL DEFAULT 0,
    discount_amount REAL NOT NULL DEFAULT 0,
    final_total REAL NOT NULL DEFAULT 0,
    FOREIGN KEY (location_id) REFERENCES locations(location_id),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE IF NOT EXISTS sale_line_items (
    sale_line_item_id INTEGER PRIMARY KEY,
    sale_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price REAL NOT NULL CHECK (unit_price >= 0),
    FOREIGN KEY (sale_id) REFERENCES sales(sale_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE IF NOT EXISTS purchase_orders (
    po_id INTEGER PRIMARY KEY,
    supplier_id INTEGER NOT NULL,
    location_id INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('Drafted', 'Sent', 'Received', 'Cancelled')),
    created_date TEXT NOT NULL,
    sent_date TEXT,
    received_date TEXT,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (location_id) REFERENCES locations(location_id)
);

CREATE TABLE IF NOT EXISTS po_line_items (
    po_line_item_id INTEGER PRIMARY KEY,
    po_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_cost REAL NOT NULL CHECK (unit_cost >= 0),
    FOREIGN KEY (po_id) REFERENCES purchase_orders(po_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE IF NOT EXISTS ledger_entries (
    ledger_entry_id INTEGER PRIMARY KEY,
    entry_date TEXT NOT NULL,
    entry_type TEXT NOT NULL CHECK (entry_type IN ('Income', 'Expense')),
    source_type TEXT NOT NULL DEFAULT 'manual',
    source_record_id INTEGER,
    amount REAL NOT NULL CHECK (amount >= 0),
    description TEXT NOT NULL,
    related_sale_id INTEGER,
    related_po_id INTEGER,
    FOREIGN KEY (related_sale_id) REFERENCES sales(sale_id),
    FOREIGN KEY (related_po_id) REFERENCES purchase_orders(po_id)
);

CREATE TABLE IF NOT EXISTS payroll_runs (
    run_id        INTEGER PRIMARY KEY,
    period_start  TEXT    NOT NULL,
    period_end    TEXT    NOT NULL,
    run_date      TEXT    NOT NULL,
    total_amount  REAL    NOT NULL DEFAULT 0,
    status        TEXT    NOT NULL DEFAULT 'Draft'
                          CHECK (status IN ('Draft', 'Finalized')),
    created_by    INTEGER NOT NULL,
    FOREIGN KEY (created_by) REFERENCES employees(employee_id)
);

CREATE TABLE IF NOT EXISTS payroll_entries (
    entry_id      INTEGER PRIMARY KEY,
    run_id        INTEGER NOT NULL,
    employee_id   INTEGER NOT NULL,
    location_id   INTEGER NOT NULL,
    hours_worked  REAL    NOT NULL DEFAULT 0 CHECK (hours_worked >= 0),
    hourly_rate   REAL    NOT NULL DEFAULT 0 CHECK (hourly_rate >= 0),
    gross_pay     REAL    NOT NULL GENERATED ALWAYS AS (hours_worked * hourly_rate) STORED,
    FOREIGN KEY (run_id)      REFERENCES payroll_runs(run_id),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    FOREIGN KEY (location_id) REFERENCES locations(location_id)
);

CREATE TABLE IF NOT EXISTS shifts (
    shift_id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL,
    location_id INTEGER NOT NULL,
    shift_date TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT,
    source TEXT NOT NULL DEFAULT 'manual',
    UNIQUE (employee_id, shift_date, source),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    FOREIGN KEY (location_id) REFERENCES locations(location_id)
);

CREATE TABLE IF NOT EXISTS simulation_runs (
    simulation_run_id INTEGER PRIMARY KEY,
    simulation_date TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL,
    sales_posted INTEGER NOT NULL DEFAULT 0,
    purchase_orders_created INTEGER NOT NULL DEFAULT 0,
    shifts_logged INTEGER NOT NULL DEFAULT 0
);
