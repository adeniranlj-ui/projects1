from datetime import datetime

from models.supplier import Supplier
from repositories import supplier_repo
from services.validation import require_text, to_int


def get_all_suppliers() -> list[Supplier]:
    return supplier_repo.get_all_suppliers()


def get_active_suppliers() -> list[Supplier]:
    return supplier_repo.get_active_suppliers()


def get_supplier_by_id(supplier_id: int) -> Supplier | None:
    return supplier_repo.get_supplier_by_id(supplier_id)


def get_default_supplier_for_product(product_id: int) -> Supplier:
    supplier = supplier_repo.get_default_supplier_for_product(product_id)
    if supplier is None:
        raise ValueError("Default supplier not found for product.")
    return supplier


def create_supplier(supplier_data: dict) -> int:
    supplier_name = require_text(supplier_data.get("supplier_name"), "Supplier name")
    category = require_text(supplier_data.get("category"), "Supplier category")
    return supplier_repo.insert_supplier(Supplier(supplier_name=supplier_name, category=category, active=1))


def update_supplier(supplier_id: int, supplier_data: dict) -> None:
    supplier_id = to_int(supplier_id, "Supplier")
    existing = supplier_repo.get_supplier_by_id(supplier_id)
    if existing is None:
        raise ValueError("Supplier not found.")
    supplier_name = require_text(supplier_data.get("supplier_name"), "Supplier name")
    category = require_text(supplier_data.get("category"), "Supplier category")
    existing.supplier_name = supplier_name
    existing.category = category
    supplier_repo.update_supplier(existing)


def ban_supplier(supplier_id: int, reason: str) -> None:
    supplier_id = to_int(supplier_id, "Supplier")
    existing = supplier_repo.get_supplier_by_id(supplier_id)
    if existing is None:
        raise ValueError("Supplier not found.")
    if existing.active != 1:
        raise ValueError("This supplier is already banned or inactive.")
    reason = require_text(reason, "Ban reason")
    supplier_repo.ban_supplier(supplier_id, reason, datetime.now().isoformat(timespec="seconds"))


def reactivate_supplier(supplier_id: int) -> None:
    supplier_id = to_int(supplier_id, "Supplier")
    existing = supplier_repo.get_supplier_by_id(supplier_id)
    if existing is None:
        raise ValueError("Supplier not found.")
    if existing.active == 1:
        raise ValueError("This supplier is already active.")
    supplier_repo.reactivate_supplier(supplier_id, datetime.now().isoformat(timespec="seconds"))


def validate_supplier_not_banned(supplier_id: int) -> None:
    supplier = supplier_repo.get_supplier_by_id(supplier_id)
    if supplier is None:
        raise ValueError("Supplier not found.")
    if supplier.active != 1:
        reason = f" Reason: {supplier.ban_reason}" if supplier.ban_reason else ""
        raise ValueError(
            f"This supplier is banned or inactive and cannot be used for new purchase orders.{reason}"
        )
