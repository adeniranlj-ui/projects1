from datetime import date, datetime, time

from models.payroll import PayrollEntry, PayrollRun
from repositories import employee_repo, payroll_repo, shift_repo
from repositories import unit_of_work
from services import ledger_service
from services.validation import parse_date, to_float, to_int


def get_all_runs() -> list[PayrollRun]:
    return payroll_repo.get_all_runs()


def get_run_by_id(run_id: int) -> PayrollRun | None:
    return payroll_repo.get_run_by_id(run_id)


def _parse_shift_datetime(value: str, shift_date: str, field_name: str) -> datetime:
    value = (value or "").strip()
    if not value:
        raise ValueError(f"{field_name} is missing for a shift on {shift_date}.")

    try:
        return datetime.fromisoformat(value)
    except ValueError:
        pass

    try:
        return datetime.combine(date.fromisoformat(shift_date), time.fromisoformat(value))
    except ValueError:
        raise ValueError(
            "Shift times must use a valid time format before payroll can be generated."
        ) from None


def _calculate_completed_shift_hours(period_start: str, period_end: str) -> dict[tuple[int, int], float]:
    shifts = shift_repo.get_completed_shifts_for_period(period_start, period_end)
    hours_by_employee_location: dict[tuple[int, int], float] = {}

    for shift in shifts:
        start_time = _parse_shift_datetime(shift["start_time"], shift["shift_date"], "Shift start time")
        end_time = _parse_shift_datetime(shift["end_time"], shift["shift_date"], "Shift end time")
        if end_time <= start_time:
            raise ValueError(
                "A completed shift has an end time that is not after the start time. Please correct shift data before running payroll."
            )

        hours = (end_time - start_time).total_seconds() / 3600
        key = (int(shift["employee_id"]), int(shift["location_id"]))
        hours_by_employee_location[key] = hours_by_employee_location.get(key, 0.0) + hours

    return hours_by_employee_location


def run_payroll(employee_id: int, hourly_wage: float, pay_period_start: str, pay_period_end: str) -> PayrollEntry:
    employee_id = to_int(employee_id, "Employee")
    hourly_wage = to_float(hourly_wage, "Hourly wage")
    start = parse_date(pay_period_start, "Pay period start")
    end = parse_date(pay_period_end, "Pay period end")

    if end < start:
        raise ValueError("Pay period end cannot be before pay period start.")
    if hourly_wage <= 0:
        raise ValueError("Hourly wage must be greater than zero.")

    employee = employee_repo.get_employee_by_id(employee_id)
    if employee is None or employee.active != 1:
        raise ValueError("Employee not found or inactive.")
    if abs(float(employee.hourly_wage) - hourly_wage) > 0.001:
        raise ValueError("Payroll wage must match the hourly wage stored on the employee record.")

    return PayrollEntry(
        employee_id=employee.employee_id,
        employee_name=employee.employee_name,
        location_id=employee.location_id,
        location_name=employee.location_name,
        hourly_rate=hourly_wage,
        hours_worked=0.0,
        gross_pay=0.0,
    )


def create_run(period_start: str, period_end: str, created_by: int) -> int:
    start = parse_date(period_start, "Period start")
    end = parse_date(period_end, "Period end")

    if end < start:
        raise ValueError("Period end cannot be before period start.")

    if payroll_repo.overlapping_finalized_run_exists(start.isoformat(), end.isoformat()):
        raise ValueError("A finalized payroll run already exists that overlaps this period.")

    shift_hours = _calculate_completed_shift_hours(start.isoformat(), end.isoformat())
    if not shift_hours:
        raise ValueError(
            "No completed shifts were found for this pay period. Record or simulate shifts first, then run payroll again."
        )

    active_employees = {employee.employee_id: employee for employee in employee_repo.get_active_employees()}
    prepared_entries: list[PayrollEntry] = []

    for (employee_id, location_id), hours_worked in sorted(shift_hours.items()):
        employee = active_employees.get(employee_id)
        if employee is None:
            continue
        if hours_worked <= 0:
            continue

        prepared = run_payroll(employee.employee_id, employee.hourly_wage, start.isoformat(), end.isoformat())
        prepared_entries.append(
            PayrollEntry(
                employee_id=prepared.employee_id,
                location_id=location_id,
                hours_worked=round(hours_worked, 2),
                hourly_rate=prepared.hourly_rate,
            )
        )

    if not prepared_entries:
        raise ValueError(
            "No active employees had completed shifts for this pay period. Check the shift data and try again."
        )

    draft_total = round(sum(entry.hours_worked * entry.hourly_rate for entry in prepared_entries), 2)

    run = PayrollRun(
        period_start=start.isoformat(),
        period_end=end.isoformat(),
        run_date=date.today().isoformat(),
        total_amount=draft_total,
        status="Draft",
        created_by=to_int(created_by, "Created by employee"),
    )

    try:
        with unit_of_work.transaction():
            run_id = payroll_repo.insert_run(run)
            for entry in prepared_entries:
                entry.run_id = run_id
                payroll_repo.insert_entry(entry)
        return run_id
    except ValueError:
        raise
    except Exception as error:
        raise ValueError("Payroll run could not be created. Please check the dates and try again.") from error


def update_entry(entry_id: int, hours_worked: str) -> None:
    hours = to_float(hours_worked, "Hours worked")
    if hours < 0:
        raise ValueError("Hours worked cannot be negative.")

    entry_id = to_int(entry_id, "Payroll entry")
    current_entry = payroll_repo.get_entry_by_id(entry_id)
    if current_entry is None:
        raise ValueError("Payroll entry not found.")

    run = payroll_repo.get_run_by_id(current_entry.run_id)
    if run is None:
        raise ValueError("Payroll run not found.")
    if run.status == "Finalized":
        raise ValueError("Finalized payroll entries cannot be edited.")

    employee = employee_repo.get_employee_by_id(current_entry.employee_id)
    if employee is None:
        raise ValueError("Employee not found.")
    entry = PayrollEntry(entry_id=entry_id, hours_worked=hours, hourly_rate=employee.hourly_wage)
    payroll_repo.update_entry(entry)


def finalize_run(run_id: int) -> float:
    run_id = to_int(run_id, "Payroll run")
    run = payroll_repo.get_run_by_id(run_id)
    if run is None:
        raise ValueError("Payroll run not found.")
    if run.status == "Finalized":
        raise ValueError("This payroll run is already finalized.")
    if payroll_repo.overlapping_finalized_run_exists(run.period_start, run.period_end):
        raise ValueError("A finalized payroll run already exists that overlaps this period.")

    total = round(sum(entry.hours_worked * entry.hourly_rate for entry in run.entries), 2)
    if total <= 0:
        raise ValueError("Payroll total must be greater than zero before finalizing.")

    try:
        with unit_of_work.transaction():
            payroll_repo.finalize_run(run_id, total)
            ledger_service.post_expense_entry(total, "payroll", run_id)
        return total
    except ValueError:
        raise
    except Exception as error:
        raise ValueError("Payroll run could not be finalized. Please try again.") from error


def delete_run(run_id: int) -> None:
    run_id = to_int(run_id, "Payroll run")
    run = payroll_repo.get_run_by_id(run_id)
    if run is None:
        raise ValueError("Payroll run not found.")
    if run.status == "Finalized":
        raise ValueError("Finalized payroll runs cannot be deleted.")
    payroll_repo.delete_run(run_id)
