from repositories import location_repo


def get_all_locations():
    return location_repo.get_all_locations()


def get_location_by_id(location_id: int):
    return location_repo.get_location_by_id(location_id)
