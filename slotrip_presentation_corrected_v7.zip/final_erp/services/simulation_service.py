from datetime import date, datetime, timedelta
import random

from repositories import customer_repo, employee_repo, simulation_repo
from repositories import unit_of_work
from services import inventory_service, product_service, purchase_order_service, sale_service, shift_service
from services.validation import to_int



def _next_simulation_start_date() -> date:
    latest = simulation_repo.get_latest_simulation_date()
    if latest:
        return datetime.strptime(latest, "%Y-%m-%d").date() + timedelta(days=1)
    return date.today()



def _customer_cycle() -> list[int]:
    customers = customer_repo.get_active_customers()
    walk_in = customer_repo.get_walk_in_customer()
    walk_in_id = walk_in.customer_id if walk_in else None
    repeat_ids = [customer.customer_id for customer in customers if customer.customer_name != customer_repo.WALK_IN_CUSTOMER_NAME]
    cycle = []
    if walk_in_id is not None:
        cycle.extend([walk_in_id, walk_in_id])
    cycle.extend(repeat_ids)
    return cycle or ([walk_in_id] if walk_in_id is not None else [])



def _staff_by_location() -> dict[int, list[int]]:
    result: dict[int, list[int]] = {}
    for employee in employee_repo.get_active_employees():
        if employee.role == "Staff":
            result.setdefault(employee.location_id, []).append(employee.employee_id)
    return result



def _replenish_low_stock(
    location_id: int,
    simulation_date: str,
    processed_po_keys: set[tuple[int, int]],
    warnings: list[str],
) -> int:
    """Automatically create and receive reorders when stock is low.

    The simulation runs under an admin workflow, so it can safely auto-receive
    purchase orders to keep stock available for the rest of the day.
    """
    created_count = 0
    inventory_rows = inventory_service.get_inventory({"location_id": location_id})
    for row in inventory_rows:
        po_key = (row.product_id, row.location_id)
        if row.quantity <= row.reorder_point and po_key not in processed_po_keys:
            try:
                purchase_order_service.auto_replenish_product(
                    row.product_id,
                    row.location_id,
                    order_date=f"{simulation_date}T06:00:00",
                    received_date=f"{simulation_date}T06:15:00",
                )
                processed_po_keys.add(po_key)
                created_count += 1
            except ValueError as error:
                warnings.append(str(error))
    return created_count



def _run_single_day(simulation_day: date) -> dict:
    simulation_date = simulation_day.isoformat()
    if simulation_repo.simulation_date_exists(simulation_date):
        return {"skipped": True, "sales_posted": 0, "revenue_total": 0.0, "pos_processed": 0, "shifts_logged": 0, "warnings": []}

    rng = random.Random(simulation_date)
    products = product_service.get_active_products()
    product_ids = [product.product_id for product in products]
    customers = _customer_cycle()
    employees_by_location = _staff_by_location()

    sales_posted = 0
    revenue_total = 0.0
    pos_processed = 0
    warnings: list[str] = []
    processed_po_keys: set[tuple[int, int]] = set()
    shifts_logged = 0

    if not product_ids:
        raise ValueError("Simulation cannot run because there are no active products.")
    if not customers:
        raise ValueError("Simulation cannot run because there are no active customers.")
    if not employees_by_location:
        raise ValueError("Simulation cannot run because there are no active staff employees.")

    try:
        with unit_of_work.transaction():
            shifts_logged = shift_service.log_simulation_shifts(simulation_date)

            for location_id, employee_ids in employees_by_location.items():
                pos_processed += _replenish_low_stock(location_id, simulation_date, processed_po_keys, warnings)

                base_sales = rng.randint(6, 12)
                if simulation_day.weekday() in (4, 5):
                    base_sales += rng.randint(3, 6)
                if simulation_day.weekday() == 6:
                    base_sales = max(3, base_sales - rng.randint(2, 5))

                for sale_number in range(base_sales):
                    employee_id = rng.choice(employee_ids)
                    customer_id = rng.choice(customers)
                    line_count = rng.randint(1, min(3, len(product_ids)))
                    chosen_products = rng.sample(product_ids, line_count)
                    line_items = [
                        {"product_id": product_id, "quantity": rng.randint(1, 3)}
                        for product_id in chosen_products
                    ]
                    hour = 8 + (sale_number % 10)
                    minute = rng.choice([0, 10, 20, 30, 40, 50])
                    try:
                        completed_sale = sale_service.complete_sale(
                            location_id,
                            customer_id,
                            employee_id,
                            line_items,
                            sale_date=f"{simulation_date}T{hour:02d}:{minute:02d}:00",
                        )
                        sales_posted += 1
                        revenue_total += completed_sale.grand_total
                    except ValueError as error:
                        warnings.append(str(error))

                    pos_processed += _replenish_low_stock(location_id, simulation_date, processed_po_keys, warnings)

            simulation_repo.insert_simulation_run(
                simulation_date,
                datetime.now().isoformat(timespec="seconds"),
                sales_posted,
                pos_processed,
                shifts_logged,
            )
    except ValueError:
        raise
    except Exception as error:
        raise ValueError("Simulation could not be completed. Please try again.") from error

    return {
        "skipped": False,
        "sales_posted": sales_posted,
        "revenue_total": round(revenue_total, 2),
        "pos_processed": pos_processed,
        "shifts_logged": shifts_logged,
        "warnings": warnings,
    }



def run_simulation_days(day_count: int) -> dict:
    day_count = to_int(day_count, "Number of days")
    if day_count <= 0:
        raise ValueError("Number of days must be a positive whole number.")

    start_date = _next_simulation_start_date()
    result = {
        "days_requested": day_count,
        "days_added": 0,
        "days_skipped": 0,
        "sales_posted": 0,
        "revenue_total": 0.0,
        "pos_processed": 0,
        "shifts_logged": 0,
        "warnings": [],
    }

    for offset in range(day_count):
        day_result = _run_single_day(start_date + timedelta(days=offset))
        if day_result["skipped"]:
            result["days_skipped"] += 1
            continue
        result["days_added"] += 1
        result["sales_posted"] += day_result["sales_posted"]
        result["revenue_total"] += day_result["revenue_total"]
        result["pos_processed"] += day_result["pos_processed"]
        result["shifts_logged"] += day_result["shifts_logged"]
        result["warnings"].extend(day_result["warnings"])

    result["revenue_total"] = round(result["revenue_total"], 2)
    return result



def run_day_simulation() -> dict:
    return run_simulation_days(1)
