import re
from datetime import datetime

IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z0-9._-]+$")
UNSAFE_TEXT_PATTERN = re.compile(r"[<>;{}]")


def require_text(value, field_name: str) -> str:
    text = str(value or "").strip()
    if not text:
        raise ValueError(f"{field_name} is required.")
    if UNSAFE_TEXT_PATTERN.search(text):
        raise ValueError(f"{field_name} contains characters that are not allowed.")
    return text


def require_identifier(value, field_name: str) -> str:
    text = require_text(value, field_name)
    if not IDENTIFIER_PATTERN.fullmatch(text):
        raise ValueError(f"{field_name} may only use letters, numbers, periods, hyphens, or underscores.")
    return text


def to_int(value, field_name: str) -> int:
    try:
        text = str(value).strip()
        if not text:
            raise ValueError()
        return int(text)
    except (TypeError, ValueError):
        raise ValueError(f"{field_name} must be a valid whole number.") from None


def to_float(value, field_name: str) -> float:
    try:
        text = str(value).strip()
        if not text:
            raise ValueError()
        return float(text)
    except (TypeError, ValueError):
        raise ValueError(f"{field_name} must be a valid number.") from None


def parse_date(value: str, field_name: str):
    try:
        return datetime.strptime(str(value).strip(), "%Y-%m-%d").date()
    except (TypeError, ValueError):
        raise ValueError(f"{field_name} must be in YYYY-MM-DD format.") from None
