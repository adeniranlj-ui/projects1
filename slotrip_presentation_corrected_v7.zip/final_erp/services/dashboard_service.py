from datetime import date

from repositories import customer_repo, ledger_repo, payroll_repo, purchase_order_repo, sale_repo
from services import inventory_service


def _month_start(current_date: str) -> str:
    return f"{current_date[:7]}-01"


def get_low_stock_alerts():
    return inventory_service.get_low_stock_items()


def get_open_po_count() -> int:
    orders = purchase_order_repo.get_purchase_orders({})
    return sum(1 for order in orders if order.status in ("Drafted", "Sent"))


def get_sent_po_count() -> int:
    orders = purchase_order_repo.get_purchase_orders({})
    return sum(1 for order in orders if order.status == "Sent" or (order.status == "Drafted" and order.sent_date))


def get_received_po_count_for_month(current_date: str) -> int:
    month = current_date[:7]
    orders = purchase_order_repo.get_purchase_orders({})
    return sum(1 for order in orders if order.status == "Received" and order.received_date and order.received_date.startswith(month))


def get_daily_sales_total(current_date: str) -> float:
    sales = sale_repo.get_sales_history({"date_from": current_date, "date_to": current_date})
    return round(sum(sale.grand_total for sale in sales), 2)


def get_daily_sales_count(current_date: str) -> int:
    return len(sale_repo.get_sales_history({"date_from": current_date, "date_to": current_date}))


def get_month_to_date_sales_total(current_date: str) -> float:
    sales = sale_repo.get_sales_history({"date_from": _month_start(current_date), "date_to": current_date})
    return round(sum(sale.grand_total for sale in sales), 2)


def get_average_sale_amount(current_date: str) -> float:
    sales = sale_repo.get_sales_history({"date_from": current_date, "date_to": current_date})
    if not sales:
        return 0.0
    return round(sum(sale.grand_total for sale in sales) / len(sales), 2)


def get_month_ledger_totals(current_date: str) -> dict:
    month = current_date[:7]
    entries = ledger_repo.get_ledger_entries({})
    income = sum(entry.amount for entry in entries if entry.entry_type == "Income" and entry.entry_date.startswith(month))
    expenses = sum(entry.amount for entry in entries if entry.entry_type == "Expense" and entry.entry_date.startswith(month))
    po_expenses = sum(
        entry.amount
        for entry in entries
        if entry.entry_type == "Expense"
        and entry.source_type == "purchase_order"
        and entry.entry_date.startswith(month)
    )
    payroll_expenses = sum(
        entry.amount
        for entry in entries
        if entry.entry_type == "Expense"
        and entry.source_type == "payroll"
        and entry.entry_date.startswith(month)
    )
    return {
        "income": round(income, 2),
        "expenses": round(expenses, 2),
        "net": round(income - expenses, 2),
        "po_expenses": round(po_expenses, 2),
        "payroll_expenses": round(payroll_expenses, 2),
    }


def get_draft_payroll_count() -> int:
    return sum(1 for run in payroll_repo.get_all_runs() if run.status == "Draft")


def get_last_payroll_total() -> float:
    finalized = [run for run in payroll_repo.get_all_runs() if run.status == "Finalized"]
    if not finalized:
        return 0.0
    return round(finalized[0].total_amount, 2)


def get_customer_summary() -> dict:
    active_customers = [customer for customer in customer_repo.get_active_customers() if customer.customer_name != customer_repo.WALK_IN_CUSTOMER_NAME]
    repeat_customers = customer_repo.get_customer_sales_summary(repeat_only=True)
    top_repeat = repeat_customers[0].customer_name if repeat_customers else "None yet"
    return {
        "active_customer_count": len(active_customers),
        "repeat_customer_count": len(repeat_customers),
        "top_repeat_customer": top_repeat,
    }


def get_recent_purchase_orders(limit: int = 8):
    return purchase_order_repo.get_purchase_orders({})[:limit]


def get_top_repeat_customers(limit: int = 5):
    return customer_repo.get_customer_sales_summary(repeat_only=True)[:limit]


def get_dashboard_summary(current_date: str | None = None) -> dict:
    if current_date is None:
        current_date = date.today().isoformat()

    ledger_totals = get_month_ledger_totals(current_date)
    customer_summary = get_customer_summary()

    return {
        "low_stock_alerts": get_low_stock_alerts(),
        "daily_sales_total": get_daily_sales_total(current_date),
        "daily_sales_count": get_daily_sales_count(current_date),
        "month_to_date_sales_total": get_month_to_date_sales_total(current_date),
        "average_sale_amount": get_average_sale_amount(current_date),
        "open_po_count": get_open_po_count(),
        "sent_po_count": get_sent_po_count(),
        "received_po_month_count": get_received_po_count_for_month(current_date),
        "draft_payroll_count": get_draft_payroll_count(),
        "last_payroll_total": get_last_payroll_total(),
        "recent_purchase_orders": get_recent_purchase_orders(),
        "top_repeat_customers": get_top_repeat_customers(),
        **ledger_totals,
        **customer_summary,
    }
