from repositories import employee_repo, shift_repo


def log_simulation_shifts(shift_date: str) -> int:
    employees = [employee for employee in employee_repo.get_active_employees() if employee.role == "Staff"]
    shifts_logged = 0
    for employee in employees:
        shift_id = shift_repo.insert_shift(
            employee.employee_id,
            employee.location_id,
            shift_date,
            f"{shift_date}T09:00:00",
            f"{shift_date}T17:00:00",
            "simulation",
        )
        if shift_id is not None:
            shifts_logged += 1
    return shifts_logged
