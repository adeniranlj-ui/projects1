from models.customer import Customer, CustomerSalesSummary
from repositories import customer_repo
from services.validation import require_text, to_int

DISCOUNT_THRESHOLD = 5
DISCOUNT_RATE = 0.10


def get_all_customers() -> list[Customer]:
    return customer_repo.get_all_customers()


def get_active_customers() -> list[Customer]:
    return customer_repo.get_active_customers()


def get_customer_by_id(customer_id: int) -> Customer | None:
    return customer_repo.get_customer_by_id(customer_id)


def get_walk_in_customer() -> Customer:
    customer = customer_repo.get_walk_in_customer()
    if customer is None:
        raise ValueError("Walk-In customer was not found. Restart the application to seed base data.")
    return customer


def get_customer_sales_summary(repeat_only: bool = False) -> list[CustomerSalesSummary]:
    return customer_repo.get_customer_sales_summary(repeat_only=repeat_only)


def create_customer(customer_data: dict) -> int:
    customer_name = require_text(customer_data.get("customer_name"), "Customer name")
    if customer_name.lower() == customer_repo.WALK_IN_CUSTOMER_NAME.lower():
        raise ValueError("Walk-In is a protected customer record and already exists.")
    return customer_repo.insert_customer(Customer(customer_name=customer_name, active=1))


def update_customer(customer_id: int, customer_data: dict) -> None:
    customer_id = to_int(customer_id, "Customer")
    existing = customer_repo.get_customer_by_id(customer_id)
    if existing is None:
        raise ValueError("Customer not found.")
    if existing.customer_name == customer_repo.WALK_IN_CUSTOMER_NAME:
        raise ValueError("Walk-In is a protected customer record and cannot be edited.")

    customer_name = require_text(customer_data.get("customer_name"), "Customer name")
    if customer_name.lower() == customer_repo.WALK_IN_CUSTOMER_NAME.lower():
        raise ValueError("That name is reserved for the protected Walk-In customer.")

    active = to_int(customer_data.get("active", existing.active), "Active status")
    if active not in (0, 1):
        raise ValueError("Active status must be 0 or 1.")

    existing.customer_name = customer_name
    existing.active = active
    existing.reward_points = to_int(customer_data.get("reward_points", existing.reward_points), "Reward points")
    existing.is_discount_eligible = to_int(
        customer_data.get("is_discount_eligible", existing.is_discount_eligible), "Discount eligible"
    )
    customer_repo.update_customer(existing)


def deactivate_customer(customer_id: int) -> None:
    customer_id = to_int(customer_id, "Customer")
    existing = customer_repo.get_customer_by_id(customer_id)
    if existing is None:
        raise ValueError("Customer not found.")
    if existing.customer_name == customer_repo.WALK_IN_CUSTOMER_NAME:
        raise ValueError("Walk-In cannot be deactivated.")
    customer_repo.set_customer_active(customer_id, 0)


def add_reward_point(customer_id: int) -> None:
    customer = customer_repo.get_customer_by_id(customer_id)
    if customer is None:
        raise ValueError("Customer not found.")
    customer_repo.add_reward_point(customer_id)


def apply_customer_discount(customer_id: int | None, subtotal: float) -> tuple[float, float]:
    walk_in = customer_repo.get_walk_in_customer()
    if customer_id is None or (walk_in is not None and customer_id == walk_in.customer_id):
        return 0.0, round(subtotal, 2)

    customer = customer_repo.get_customer_by_id(customer_id)
    if customer is None or customer.active != 1:
        raise ValueError("Customer not found or inactive.")

    if customer.is_discount_eligible:
        discount = round(subtotal * DISCOUNT_RATE, 2)
        return discount, round(subtotal - discount, 2)

    return 0.0, round(subtotal, 2)
