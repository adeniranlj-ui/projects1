from datetime import datetime

from repositories import inventory_repo, location_repo, product_repo
from repositories import unit_of_work


def get_inventory(filters: dict | None = None):
    return inventory_repo.get_inventory(filters)


def get_inventory_summary():
    return inventory_repo.get_inventory({})


def get_low_stock_items():
    return inventory_repo.get_low_stock_items()


def check_stock_available(product_id: int, location_id: int, quantity: int) -> bool:
    return inventory_repo.get_stock(product_id, location_id) >= quantity


def require_stock_available(product_id: int, location_id: int, quantity: int) -> None:
    available = inventory_repo.get_stock(product_id, location_id)
    if available < quantity:
        product = product_repo.get_product_by_id(product_id)
        product_name = product.product_name if product else "selected product"
        raise ValueError(f"Insufficient stock for {product_name}. Available: {available}.")


def reduce_stock(product_id: int, location_id: int, quantity: int) -> None:
    require_stock_available(product_id, location_id, quantity)
    inventory_repo.decrement_stock(product_id, location_id, quantity)


def increase_stock(product_id: int, location_id: int, quantity: int) -> None:
    if quantity <= 0:
        raise ValueError("Quantity must be greater than zero.")
    inventory_repo.increment_stock(product_id, location_id, quantity)


def transfer_stock(product_id: int, from_location_id: int, to_location_id: int, quantity: int) -> None:
    if from_location_id == to_location_id:
        raise ValueError("Source and destination locations must be different.")
    if quantity <= 0:
        raise ValueError("Quantity must be greater than zero.")
    if product_repo.get_product_by_id(product_id) is None:
        raise ValueError("Product not found.")
    if location_repo.get_location_by_id(from_location_id) is None:
        raise ValueError("Source location not found.")
    if location_repo.get_location_by_id(to_location_id) is None:
        raise ValueError("Destination location not found.")

    available = inventory_repo.get_stock(product_id, from_location_id)
    if quantity > available:
        raise ValueError(f"Insufficient stock at source. Available: {available}.")

    try:
        with unit_of_work.transaction():
            inventory_repo.decrement_stock(product_id, from_location_id, quantity)
            inventory_repo.increment_stock(product_id, to_location_id, quantity)
            inventory_repo.insert_stock_transfer(
                datetime.now().isoformat(timespec="seconds"),
                from_location_id,
                to_location_id,
                product_id,
                quantity,
            )
    except Exception as error:
        raise ValueError("A database error occurred.") from error
