from datetime import datetime

from models.sale import Sale, SaleLineItem
from repositories import customer_repo, employee_repo, inventory_repo, location_repo, product_repo, sale_repo
from repositories import unit_of_work
from services import customer_service, ledger_service
from services.validation import to_int


def _get_attr(item, name: str):
    if isinstance(item, dict):
        return item.get(name)
    return getattr(item, name)


def complete_sale(
    location_id: int,
    customer_id: int | None,
    employee_id: int,
    line_items: list,
    sale_date: str | None = None,
) -> Sale:
    if location_id is None or str(location_id).strip() == "":
        raise ValueError("Location must be selected.")

    location_id = to_int(location_id, "Location")
    employee_id = to_int(employee_id, "Employee")

    if customer_id in (None, ""):
        walk_in = customer_repo.get_walk_in_customer()
        if walk_in is None:
            raise ValueError("Walk-In customer was not found. Restart the application to seed base data.")
        customer_id = walk_in.customer_id
    else:
        customer_id = to_int(customer_id, "Customer")

    if location_repo.get_location_by_id(location_id) is None:
        raise ValueError("Location not found.")

    employee = employee_repo.get_employee_by_id(employee_id)
    if employee is None or employee.active != 1:
        raise ValueError("Employee not found or inactive.")

    customer = customer_repo.get_customer_by_id(customer_id)
    if customer is None or customer.active != 1:
        raise ValueError("Customer not found or inactive.")

    if not line_items:
        raise ValueError("At least one line item is required.")

    validated_items = []
    required_by_product: dict[int, int] = {}
    product_lookup = {}

    for item in line_items:
        product_id = to_int(_get_attr(item, "product_id"), "Product")
        quantity = to_int(_get_attr(item, "quantity"), "Quantity")

        if quantity <= 0:
            raise ValueError("Line item quantity must be greater than zero.")

        product = product_repo.get_product_by_id(product_id)
        if product is None or product.active != 1:
            raise ValueError("Product not found or inactive.")

        product_lookup[product_id] = product
        required_by_product[product_id] = required_by_product.get(product_id, 0) + quantity

        line_total = round(quantity * product.unit_price, 2)
        validated_items.append({
            "product_id": product_id,
            "product_name": product.product_name,
            "quantity": quantity,
            "unit_price": product.unit_price,
            "line_total": line_total,
        })

    for product_id, required_quantity in required_by_product.items():
        available = inventory_repo.get_stock(product_id, location_id)
        if required_quantity > available:
            product = product_lookup[product_id]
            raise ValueError(f"Insufficient stock for {product.product_name}. Available: {available}.")

    grand_total = round(sum(item["line_total"] for item in validated_items), 2)
    discount_amount, final_total = customer_service.apply_customer_discount(customer_id, grand_total)
    if sale_date is None:
        sale_date = datetime.now().isoformat(timespec="seconds")

    try:
        with unit_of_work.transaction():
            sale_id = sale_repo.insert_sale(
                location_id, customer_id, employee_id, sale_date,
                subtotal=grand_total, discount_amount=discount_amount, final_total=final_total,
            )
            completed_line_items = []

            for item in validated_items:
                inventory_repo.decrement_stock(item["product_id"], location_id, item["quantity"])
                line_id = sale_repo.insert_sale_line_item(
                    sale_id,
                    item["product_id"],
                    item["quantity"],
                    item["unit_price"],
                )
                completed_line_items.append(
                    SaleLineItem(
                        sale_line_item_id=line_id,
                        sale_id=sale_id,
                        product_id=item["product_id"],
                        product_name=item["product_name"],
                        quantity=item["quantity"],
                        unit_price=item["unit_price"],
                        line_total=item["line_total"],
                    )
                )

            walk_in = customer_repo.get_walk_in_customer()
            is_walk_in = walk_in is not None and customer_id == walk_in.customer_id
            if not is_walk_in:
                customer_service.add_reward_point(customer_id)

            ledger_service.post_income_entry(final_total, sale_id, entry_date=sale_date)

        sale = sale_repo.get_sale_by_id(sale_id)
        if sale is None:
            sale = Sale(
                sale_id=sale_id,
                sale_date=sale_date,
                location_id=location_id,
                customer_id=customer_id,
                employee_id=employee_id,
            )
        sale.subtotal = grand_total
        sale.discount_amount = discount_amount
        sale.grand_total = final_total
        sale.line_items = completed_line_items
        return sale

    except ValueError:
        raise
    except Exception as error:
        raise ValueError("Sale could not be completed. Please check the information and try again.") from error


def get_sales_history(filters: dict | None = None):
    return sale_repo.get_sales_history(filters)


def get_sale_details(sale_id: int):
    sale = sale_repo.get_sale_by_id(sale_id)
    if sale is None:
        raise ValueError("Sale not found.")
    sale.line_items = sale_repo.get_sale_line_items(sale_id)
    sale.grand_total = round(sum(item.line_total for item in sale.line_items), 2)
    return sale
