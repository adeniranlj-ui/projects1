import hashlib

from models.employee import Employee
from repositories import employee_repo, location_repo
from services.validation import require_identifier, require_text, to_float, to_int


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def get_all_employees() -> list[Employee]:
    return employee_repo.get_all_employees()


def get_active_employees() -> list[Employee]:
    return employee_repo.get_active_employees()


def create_employee(employee_data: dict) -> int:
    employee_name = require_text(employee_data.get("employee_name"), "Employee name")
    username = require_identifier(employee_data.get("username"), "Username")
    password = str(employee_data.get("password", ""))
    role = str(employee_data.get("role", "Staff")).strip()
    location_id = to_int(employee_data.get("location_id"), "Location")
    hourly_wage = to_float(employee_data.get("hourly_wage"), "Hourly wage")

    if not password:
        raise ValueError("Password is required.")
    if role not in ("Admin", "Staff"):
        raise ValueError("Role must be Admin or Staff.")
    if hourly_wage <= 0:
        raise ValueError("Hourly wage must be greater than zero.")
    if location_repo.get_location_by_id(location_id) is None:
        raise ValueError("Assigned location not found.")
    if employee_repo.get_employee_by_username(username) is not None:
        raise ValueError("Username already exists.")

    employee = Employee(
        employee_name=employee_name,
        username=username,
        password_hash=hash_password(password),
        role=role,
        location_id=location_id,
        hourly_wage=hourly_wage,
        active=1,
    )
    return employee_repo.insert_employee(employee)


def update_employee(employee_id: int, employee_data: dict) -> None:
    employee_id = to_int(employee_id, "Employee")
    existing = employee_repo.get_employee_by_id(employee_id)
    if existing is None:
        raise ValueError("Employee not found.")

    employee_name = require_text(employee_data.get("employee_name"), "Employee name")
    username = require_identifier(employee_data.get("username"), "Username")
    password = str(employee_data.get("password", ""))
    role = str(employee_data.get("role", existing.role)).strip()
    location_id = to_int(employee_data.get("location_id", existing.location_id), "Location")
    active = to_int(employee_data.get("active", existing.active), "Active status")
    hourly_wage = to_float(employee_data.get("hourly_wage", existing.hourly_wage), "Hourly wage")

    if role not in ("Admin", "Staff"):
        raise ValueError("Role must be Admin or Staff.")
    if active not in (0, 1):
        raise ValueError("Active status must be 0 or 1.")
    if hourly_wage <= 0:
        raise ValueError("Hourly wage must be greater than zero.")
    if location_repo.get_location_by_id(location_id) is None:
        raise ValueError("Assigned location not found.")

    username_owner = employee_repo.get_employee_by_username(username)
    if username_owner and username_owner.employee_id != employee_id:
        raise ValueError("Username already exists.")

    if existing.role == "Admin" and active == 0 and employee_repo.count_active_admins() <= 1:
        raise ValueError("The last active Admin employee cannot be deactivated.")

    existing.employee_name = employee_name
    existing.username = username
    existing.role = role
    existing.location_id = location_id
    existing.hourly_wage = hourly_wage
    existing.active = active
    if password:
        existing.password_hash = hash_password(password)
    employee_repo.update_employee(existing)


def deactivate_employee(employee_id: int) -> None:
    employee_id = to_int(employee_id, "Employee")
    existing = employee_repo.get_employee_by_id(employee_id)
    if existing is None:
        raise ValueError("Employee not found.")
    if existing.role == "Admin" and employee_repo.count_active_admins() <= 1:
        raise ValueError("The last active Admin employee cannot be deactivated.")
    employee_repo.deactivate_employee(employee_id)
