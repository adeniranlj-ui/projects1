import hashlib

from repositories import employee_repo


def login(username: str, password: str) -> dict:
    if not username.strip():
        raise ValueError("Username is required.")
    if not password:
        raise ValueError("Password is required.")

    employee = employee_repo.get_employee_by_username(username.strip())
    if employee is None:
        raise ValueError("Invalid username or password.")

    password_hash = hashlib.sha256(password.encode("utf-8")).hexdigest()
    if employee.password_hash != password_hash:
        raise ValueError("Invalid username or password.")

    if employee.active != 1:
        raise ValueError("This employee account is inactive.")

    return {
        "employee_id": employee.employee_id,
        "employee_name": employee.employee_name,
        "username": employee.username,
        "role": employee.role,
        "location_id": employee.location_id,
        "location_name": employee.location_name,
    }


def require_admin(session: dict) -> None:
    if not session or session.get("role") != "Admin":
        raise ValueError("Access denied. Admin permission is required.")
