from datetime import datetime

from repositories import inventory_repo, location_repo, product_repo, purchase_order_repo, supplier_repo
from repositories import unit_of_work
from services import ledger_service, supplier_service
from services.validation import to_float, to_int


def _get_attr(item, name: str):
    if isinstance(item, dict):
        return item.get(name)
    return getattr(item, name)


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def create_purchase_order(
    supplier_id: int,
    location_id: int,
    line_items: list,
    created_date: str | None = None,
) -> int:
    supplier_id = to_int(supplier_id, "Supplier")
    location_id = to_int(location_id, "Location")

    supplier = supplier_repo.get_supplier_by_id(supplier_id)
    if supplier is None:
        raise ValueError("Supplier not found.")
    if supplier.active != 1:
        raise ValueError("Supplier not found or inactive.")
    supplier_service.validate_supplier_not_banned(supplier_id)
    if location_repo.get_location_by_id(location_id) is None:
        raise ValueError("Location not found.")
    if not line_items:
        raise ValueError("At least one purchase order line item is required.")

    validated_line_items = []
    for item in line_items:
        product_id = to_int(_get_attr(item, "product_id"), "Product")
        quantity = to_int(_get_attr(item, "quantity"), "Quantity")
        if quantity <= 0:
            raise ValueError("Purchase order quantity must be greater than zero.")

        product = product_repo.get_product_by_id(product_id)
        if product is None or product.active != 1:
            raise ValueError("Product not found or inactive.")

        raw_unit_cost = _get_attr(item, "unit_cost")
        unit_cost = product.unit_cost if raw_unit_cost in (None, "") else to_float(raw_unit_cost, "Unit cost")
        if unit_cost < 0:
            raise ValueError("Unit cost cannot be negative.")

        validated_line_items.append({
            "product_id": product_id,
            "quantity": quantity,
            "unit_cost": unit_cost,
        })

    if created_date is None:
        created_date = _now_iso()

    try:
        with unit_of_work.transaction():
            po_id = purchase_order_repo.insert_purchase_order({
                "supplier_id": supplier_id,
                "location_id": location_id,
                "status": "Drafted",
                "created_date": created_date,
                "sent_date": None,
                "received_date": None,
            })
            for item in validated_line_items:
                purchase_order_repo.insert_po_line_item({
                    "po_id": po_id,
                    "product_id": item["product_id"],
                    "quantity": item["quantity"],
                    "unit_cost": item["unit_cost"],
                })
        return po_id
    except ValueError:
        raise
    except Exception as error:
        raise ValueError("Purchase order could not be saved. Please check the information and try again.") from error


def draft_reorder_po(product_id: int, location_id: int, created_date: str | None = None) -> int | None:
    product_id = to_int(product_id, "Product")
    location_id = to_int(location_id, "Location")

    existing = purchase_order_repo.find_drafted_po_for_product_location(product_id, location_id)
    if existing is not None:
        return None

    product = product_repo.get_product_by_id(product_id)
    if product is None:
        raise ValueError("Product not found.")

    supplier = supplier_repo.get_supplier_by_id(product.default_supplier_id)
    if supplier is None or supplier.active != 1:
        raise ValueError(f"Cannot create reorder PO for {product.product_name} because its default supplier is banned or inactive.")

    return create_purchase_order(
        product.default_supplier_id,
        location_id,
        [{"product_id": product_id, "quantity": 50, "unit_cost": product.unit_cost}],
        created_date=created_date,
    )


def mark_purchase_order_sent(po_id: int, sent_date: str | None = None) -> None:
    po_id = to_int(po_id, "Purchase order")
    purchase_order = purchase_order_repo.get_purchase_order_by_id(po_id)
    if purchase_order is None:
        raise ValueError("Purchase order not found.")
    if purchase_order.status == "Received":
        raise ValueError("Received purchase orders are already complete.")
    if purchase_order.status == "Cancelled":
        raise ValueError("Cancelled purchase orders cannot be sent.")
    if purchase_order.status == "Sent" or purchase_order.sent_date:
        raise ValueError("This purchase order has already been sent.")

    if sent_date is None:
        sent_date = _now_iso()

    try:
        purchase_order_repo.mark_purchase_order_sent(po_id, sent_date)
    except Exception:
        # Older existing databases may still have a CHECK constraint that does
        # not allow the Sent status. Preserve the sent date so the UI can still
        # show this PO as sent without destroying existing data.
        purchase_order_repo.mark_purchase_order_sent_date_only(po_id, sent_date)


def auto_replenish_product(
    product_id: int,
    location_id: int,
    order_date: str | None = None,
    received_date: str | None = None,
) -> int:
    """Create, mark sent, and receive a reorder PO for simulation/admin workflows."""
    product_id = to_int(product_id, "Product")
    location_id = to_int(location_id, "Location")

    existing = purchase_order_repo.find_drafted_po_for_product_location(product_id, location_id)
    if existing is not None:
        po_id = existing.po_id
    else:
        po_id = draft_reorder_po(product_id, location_id, created_date=order_date)
        if po_id is None:
            existing = purchase_order_repo.find_drafted_po_for_product_location(product_id, location_id)
            if existing is None:
                raise ValueError("A reorder purchase order could not be prepared.")
            po_id = existing.po_id

    purchase_order = purchase_order_repo.get_purchase_order_by_id(po_id)
    if purchase_order is not None and purchase_order.status == "Drafted" and not purchase_order.sent_date:
        mark_purchase_order_sent(po_id, sent_date=order_date or _now_iso())
    receive_purchase_order(po_id, received_date=received_date)
    return po_id


def receive_purchase_order(po_id: int, received_date: str | None = None) -> None:
    po_id = to_int(po_id, "Purchase order")
    purchase_order = purchase_order_repo.get_purchase_order_by_id(po_id)
    if purchase_order is None:
        raise ValueError("Purchase order not found.")
    if purchase_order.status == "Received":
        raise ValueError("Purchase order has already been received.")
    if purchase_order.status == "Cancelled":
        raise ValueError("Cancelled purchase orders cannot be received.")

    line_items = purchase_order_repo.get_po_line_items(po_id)
    if not line_items:
        raise ValueError("Purchase order has no line items.")

    po_total = round(sum(item.quantity * item.unit_cost for item in line_items), 2)
    if received_date is None:
        received_date = _now_iso()
    sent_date = purchase_order.sent_date or received_date

    try:
        with unit_of_work.transaction():
            for item in line_items:
                inventory_repo.increment_stock(item.product_id, purchase_order.location_id, item.quantity)
            ledger_service.post_expense_entry(po_total, "purchase_order", po_id, entry_date=received_date)
            purchase_order_repo.update_purchase_order_status(po_id, "Received", sent_date, received_date)
    except ValueError:
        raise
    except Exception as error:
        raise ValueError("Purchase order could not be received. Please try again.") from error


def cancel_purchase_order(po_id: int) -> None:
    po_id = to_int(po_id, "Purchase order")
    purchase_order = purchase_order_repo.get_purchase_order_by_id(po_id)
    if purchase_order is None:
        raise ValueError("Purchase order not found.")
    if purchase_order.status == "Received":
        raise ValueError("Received purchase orders cannot be cancelled.")
    if purchase_order.status == "Cancelled":
        raise ValueError("Purchase order is already cancelled.")
    purchase_order_repo.update_purchase_order_status(po_id, "Cancelled", purchase_order.sent_date, None)


def get_purchase_orders(filters: dict | None = None):
    return purchase_order_repo.get_purchase_orders(filters)


def get_purchase_order_details(po_id: int):
    po = purchase_order_repo.get_purchase_order_by_id(po_id)
    if po is None:
        raise ValueError("Purchase order not found.")
    po.line_items = purchase_order_repo.get_po_line_items(po_id)
    po.po_total = round(sum(item.line_total for item in po.line_items), 2)
    return po
