from datetime import datetime

from repositories import ledger_repo


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def post_income_entry(amount: float, sale_id: int, entry_date: str | None = None) -> None:
    if amount < 0:
        raise ValueError("Income amount cannot be negative.")
    try:
        ledger_repo.insert_ledger_entry({
            "entry_date": entry_date or _now_iso(),
            "entry_type": "Income",
            "source_type": "sale",
            "source_record_id": sale_id,
            "amount": amount,
            "description": f"Income from sale #{sale_id}",
            "related_sale_id": sale_id,
            "related_po_id": None,
        })
    except Exception as error:
        raise ValueError("Ledger entry could not be posted.") from error


def post_expense_entry(amount: float, source_type: str, source_record_id: int, entry_date: str | None = None) -> None:
    if amount < 0:
        raise ValueError("Expense amount cannot be negative.")
    if source_type not in ("purchase_order", "payroll"):
        raise ValueError("Expense source type is not valid.")

    related_po_id = source_record_id if source_type == "purchase_order" else None
    if source_type == "purchase_order":
        description = f"Expense from purchase order #{source_record_id}"
    else:
        description = f"Payroll expense from payroll run #{source_record_id}"

    try:
        ledger_repo.insert_ledger_entry({
            "entry_date": entry_date or _now_iso(),
            "entry_type": "Expense",
            "source_type": source_type,
            "source_record_id": source_record_id,
            "amount": amount,
            "description": description,
            "related_sale_id": None,
            "related_po_id": related_po_id,
        })
    except Exception as error:
        raise ValueError("Ledger entry could not be posted.") from error


def _apply_running_balance(entries):
    running_balance = 0.0
    balance_by_entry_id = {}

    for entry in entries:
        if entry.entry_type == "Income":
            running_balance += entry.amount
        elif entry.entry_type == "Expense":
            running_balance -= entry.amount
        balance_by_entry_id[entry.ledger_entry_id] = round(running_balance, 2)

    return balance_by_entry_id


def get_ledger_entries(filters: dict | None = None):
    all_entries = ledger_repo.get_ledger_entries({})
    balance_by_entry_id = _apply_running_balance(all_entries)

    filtered_entries = ledger_repo.get_ledger_entries(filters or {})
    for entry in filtered_entries:
        entry.running_balance = balance_by_entry_id.get(entry.ledger_entry_id, 0.0)

    return list(reversed(filtered_entries))


def get_ledger_summary(filters: dict | None = None) -> dict:
    entries = ledger_repo.get_ledger_entries(filters or {})
    total_income = round(sum(entry.amount for entry in entries if entry.entry_type == "Income"), 2)
    total_expense = round(sum(entry.amount for entry in entries if entry.entry_type == "Expense"), 2)
    net_total = round(total_income - total_expense, 2)
    return {
        "total_income": total_income,
        "total_expense": total_expense,
        "net_total": net_total,
        "entry_count": len(entries),
    }


def get_ledger_entry_details(ledger_entry_id: int):
    entry = ledger_repo.get_ledger_entry_by_id(ledger_entry_id)
    if entry is None:
        raise ValueError("Ledger entry not found.")
    return entry
