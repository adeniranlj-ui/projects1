from models.product import Product
from repositories import location_repo, product_repo, supplier_repo
from repositories import unit_of_work
from services.validation import require_identifier, require_text, to_float, to_int


def get_all_products() -> list[Product]:
    return product_repo.get_all_products()


def get_active_products() -> list[Product]:
    return product_repo.get_active_products()


def get_product_by_id(product_id: int) -> Product | None:
    return product_repo.get_product_by_id(product_id)


def create_product(product_data: dict) -> int:
    product_name = require_text(product_data.get("product_name"), "Product name")
    sku = require_identifier(product_data.get("sku"), "SKU")
    category = require_text(product_data.get("category"), "Category")
    unit_cost = to_float(product_data.get("unit_cost"), "Unit cost")
    unit_price = to_float(product_data.get("unit_price"), "Unit price")
    reorder_point = to_int(product_data.get("reorder_point"), "Reorder point")
    default_supplier_id = to_int(product_data.get("default_supplier_id"), "Default supplier")

    if unit_cost < 0:
        raise ValueError("Unit cost cannot be negative.")
    if unit_price < 0:
        raise ValueError("Unit price cannot be negative.")
    if reorder_point < 0:
        raise ValueError("Reorder point cannot be negative.")
    supplier = supplier_repo.get_supplier_by_id(default_supplier_id)
    if supplier is None or supplier.active != 1:
        raise ValueError("Default supplier must be active.")
    if product_repo.get_product_by_sku(sku) is not None:
        raise ValueError("SKU already exists.")

    product = Product(
        product_name=product_name,
        sku=sku,
        category=category,
        unit_cost=unit_cost,
        unit_price=unit_price,
        reorder_point=reorder_point,
        default_supplier_id=default_supplier_id,
        active=1,
    )

    try:
        with unit_of_work.transaction():
            product_id = product_repo.insert_product(product)
            for location in location_repo.get_all_locations():
                product_repo.insert_inventory_row(product_id, location.location_id)
        return product_id
    except ValueError:
        raise
    except Exception as error:
        raise ValueError("Product could not be saved. Please check the information and try again.") from error


def update_product(product_id: int, product_data: dict) -> None:
    existing = product_repo.get_product_by_id(product_id)
    if existing is None:
        raise ValueError("Product not found.")

    product_name = require_text(product_data.get("product_name"), "Product name")
    category = require_text(product_data.get("category"), "Category")
    unit_price = to_float(product_data.get("unit_price"), "Unit price")
    reorder_point = to_int(product_data.get("reorder_point"), "Reorder point")

    if unit_price < 0:
        raise ValueError("Unit price cannot be negative.")
    if reorder_point < 0:
        raise ValueError("Reorder point cannot be negative.")

    existing.product_name = product_name
    existing.category = category
    existing.unit_price = unit_price
    existing.reorder_point = reorder_point

    try:
        product_repo.update_product(existing)
    except Exception as error:
        raise ValueError("Product could not be updated. Please check the information and try again.") from error


def deactivate_product(product_id: int) -> None:
    if product_repo.get_product_by_id(product_id) is None:
        raise ValueError("Product not found.")
    product_repo.set_product_active(product_id, 0)
